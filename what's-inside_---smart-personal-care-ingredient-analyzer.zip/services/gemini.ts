import { GoogleGenAI, Type } from "@google/genai";

const PRODUCT_ANALYSIS_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    name: { type: Type.STRING },
    brand: { type: Type.STRING },
    manufacturer: { type: Type.STRING },
    category: { type: Type.STRING },
    toxicity_score: { type: Type.NUMBER },
    safety_level: { type: Type.STRING, description: "Risk level: Low, Moderate, or High" },
    summary: { type: Type.STRING },
    product_history: { type: Type.STRING },
    usage_instructions: { type: Type.STRING },
    database_description: { type: Type.STRING },
    expert_rating: { type: Type.NUMBER, description: "Expert safety rating from 1 to 5 stars" },
    expert_comment: { type: Type.STRING, description: "A concise expert verdict on the product safety" },
    lifestyle: {
      type: Type.OBJECT,
      properties: {
        is_vegan: { type: Type.BOOLEAN },
        is_cruelty_free: { type: Type.BOOLEAN },
        is_fragrance_free: { type: Type.BOOLEAN },
        is_pregnancy_safe: { type: Type.BOOLEAN }
      }
    },
    ingredients: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          purpose: { type: Type.STRING },
          toxicity_level: { type: Type.STRING },
          risk_flags: { type: Type.STRING }
        }
      }
    },
    score_breakdown: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          factor: { type: Type.STRING },
          contribution: { type: Type.NUMBER }
        }
      }
    },
    health_insights: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          type: { type: Type.STRING },
          text: { type: Type.STRING }
        }
      }
    },
    alternatives: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          reason: { type: Type.STRING }
        }
      }
    }
  },
  required: [
    "name", "brand", "manufacturer", "category", "toxicity_score", "safety_level", 
    "summary", "ingredients", "score_breakdown", "health_insights", "lifestyle", 
    "alternatives", "product_history", "usage_instructions", "database_description"
  ]
};

export const analyzeProductWithSearch = async (query: string) => {
  let apiKey = process.env.GEMINI_API_KEY || process.env.API_KEY;
  
  if (!apiKey && typeof window !== 'undefined' && (window as any).aistudio) {
    try {
      const hasKey = await (window as any).aistudio.hasSelectedApiKey();
      if (!hasKey) {
        await (window as any).aistudio.openSelectKey();
      }
      apiKey = process.env.API_KEY || (window as any).process?.env?.API_KEY;
    } catch (err) {
      console.warn("Key selection error:", err);
    }
  }

  if (!apiKey) {
    throw new Error("Gemini API Key is missing. Please check your environment configuration.");
  }
  
  const ai = new GoogleGenAI({ apiKey });
  
  try {
    // Step 1: Research with Search Grounding
    const searchResponse = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Research the following product in detail: "${query}". 
      Focus on finding:
      1. Full list of ingredients (INCI names if possible).
      2. Brand and manufacturer information.
      3. Safety hazards, toxicity reports, or health concerns associated with its ingredients.
      4. Lifestyle attributes: Is it vegan, cruelty-free, fragrance-free, and pregnancy-safe?
      5. Better, cleaner alternatives if this product has high-risk ingredients.
      
      If you cannot find specific details for this exact product, provide a general analysis based on common ingredients and safety profiles for this category of product.`,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    let rawResearch = searchResponse.text;
    
    // Fallback: If search grounding returned no text (e.g. tool call failed or blocked), 
    // try once more without tools to use internal knowledge.
    if (!rawResearch) {
      console.warn("Search grounding returned no text, falling back to internal knowledge for:", query);
      try {
        const fallbackResponse = await ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: `Analyze the following product based on your internal knowledge: "${query}". 
          Provide a detailed safety and ingredient analysis. If the product is unknown, 
          provide a generic analysis for a typical product in its category.`,
        });
        rawResearch = fallbackResponse.text;
      } catch (fallbackErr) {
        console.error("Internal knowledge fallback failed:", fallbackErr);
      }
    }

    if (!rawResearch) {
      // Final Super Fallback: Create a generic research string
      rawResearch = `The product "${query}" is a consumer item. Based on its name, it likely belongs to a general consumer category. 
      Typical ingredients for such products are generally considered safe under normal use, but specific forensic data is limited. 
      We recommend a cautious approach and checking for specific allergens.`;
    }

    const groundingChunks = searchResponse.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

    // Step 2: Format into structured JSON
    const formatResponse = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a forensic toxicologist and product safety expert. 
      Based on the research provided below, extract the data into a structured JSON format.
      
      Research Data:
      ${rawResearch}
      
      Instructions:
      - toxicity_score should be 0 (safest) to 100 (most toxic).
      - safety_level should be 'Low', 'Moderate', or 'High' based on the score.
      - CRITICAL: You MUST provide at least 3 items in the 'ingredients' array. If exact ingredients are unknown, infer the most common ingredients for this product category.
      - CRITICAL: You MUST provide at least 2 items in the 'health_insights' array, explaining potential health impacts.
      - CRITICAL: You MUST provide at least 2 items in the 'alternatives' array, suggesting cleaner or safer alternatives.
      - Ensure all boolean lifestyle flags are accurate based on the research.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: PRODUCT_ANALYSIS_SCHEMA,
      },
    });

    const text = formatResponse.text;
    if (!text) {
      throw new Error("Failed to generate structured analysis report.");
    }

    let data;
    try {
      data = JSON.parse(text);
    } catch (parseErr) {
      console.error("JSON Parse Error:", parseErr);
      data = {
        name: query,
        brand: "Unknown",
        manufacturer: "Unknown",
        category: "General Consumer Product",
        toxicity_score: 50,
        safety_level: "Moderate",
        summary: "Detailed forensic analysis is currently limited for this specific item. We recommend reviewing the physical label for the most accurate ingredient list.",
        product_history: "No historical data in registry.",
        usage_instructions: "Follow standard safety protocols.",
        database_description: "Generic analysis generated due to data constraints.",
        expert_rating: 3,
        expert_comment: "Data is insufficient for a definitive safety verdict.",
        lifestyle: {
          is_vegan: false,
          is_cruelty_free: false,
          is_fragrance_free: false,
          is_pregnancy_safe: false
        },
        ingredients: [],
        score_breakdown: [],
        health_insights: [],
        alternatives: []
      };
    }
    
    return { 
      data, 
      sources: groundingChunks 
    };
  } catch (error: any) {
    console.error("AI Analysis Error:", error);
    if (error.message?.includes("API key")) {
      throw new Error("Invalid or missing API key. Please ensure your Gemini API key is correctly set.");
    }
    if (error.message?.includes("429") || error.message?.includes("quota") || error.message?.includes("RESOURCE_EXHAUSTED")) {
      throw new Error("You have exceeded your Gemini API quota. Please check your billing details or try again later.");
    }
    throw new Error(error.message || "Failed to analyze product. Please try again.");
  }
};