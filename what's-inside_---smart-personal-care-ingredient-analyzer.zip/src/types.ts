
export enum ToxicityLevel {
  SAFE = 'SAFE',
  LOW = 'LOW',
  MODERATE = 'MODERATE',
  HIGH = 'HIGH',
  TOXIC = 'TOXIC'
}

export interface Ingredient {
  name: string;
  purpose: string;
  toxicity_level: string;
  risk_flags: string;
}

export interface RiskExplanation {
  name: string;
  purpose: string;
  explanation: string;
  sensitive_groups: string;
}

export interface HealthInsight {
  type: 'check' | 'warning' | 'error';
  text: string;
}

export interface LifestyleIndicators {
  vegan: boolean;
  cruelty_free: boolean;
  fragrance_free: boolean;
  pregnancy_safe: string;
  sensitive_skin_suitable: boolean;
}

export interface ScoreFactor {
  factor: string;
  contribution: number;
}

export interface AnalysisResult {
  name: string;
  brand: string;
  category: string;
  variant?: string;
  barcode?: string;
  toxicity_score: number;
  risk_level: string;
  interpretation: string;
  product_history: string;
  ingredients: Ingredient[];
  risk_explanations: RiskExplanation[];
  score_breakdown: ScoreFactor[];
  health_insights: HealthInsight[];
  lifestyle_indicators: LifestyleIndicators;
  alternatives: { name: string; reason: string }[];
}
