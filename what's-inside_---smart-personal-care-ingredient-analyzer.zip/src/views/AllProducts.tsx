import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Trash2, 
  Package, 
  Layout,
  PlusCircle,
  X,
  Database,
  Loader2,
  AlertTriangle
} from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Column {
  id: string;
  title: string;
  items: string[];
}

const AllProducts: React.FC = () => {
  const [columns, setColumns] = useState<Column[]>([]);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState<string | null>(null);
  const [user, setUser] = useState<any>(null);
  
  const [newColumnTitle, setNewColumnTitle] = useState('');
  const [isAddingColumn, setIsAddingColumn] = useState(false);
  const [itemInputs, setItemInputs] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    const checkUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      setUser(user);
      if (user) {
        fetchColumns(user.id);
      } else {
        // Fallback to local storage if not logged in
        const saved = localStorage.getItem('product_lists');
        if (saved) {
          setColumns(JSON.parse(saved));
        } else {
          setColumns([
            { id: '1', title: 'My Bathroom Shelf', items: [] },
            { id: '2', title: 'Dirty Products', items: [] },
            { id: '3', title: 'Clean Products', items: [] },
          ]);
        }
        setLoading(false);
      }
    };

    checkUser();
  }, []);

  const fetchColumns = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('product_lists')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: true });

      if (error) throw error;

      if (data && data.length > 0) {
        setColumns(data.map(d => ({
          id: d.id,
          title: d.title,
          items: d.items || []
        })));
      } else {
        // If no columns in Supabase, create defaults
        const defaults = [
          { user_id: userId, title: 'My Bathroom Shelf', items: [] },
          { user_id: userId, title: 'Dirty Products', items: [] },
          { user_id: userId, title: 'Clean Products', items: [] },
        ];
        
        const { data: insertedData, error: insertError } = await supabase
          .from('product_lists')
          .insert(defaults)
          .select();

        if (insertError) throw insertError;
        
        if (insertedData) {
          setColumns(insertedData.map(d => ({
            id: d.id,
            title: d.title,
            items: d.items || []
          })));
        }
      }
    } catch (err) {
      console.error('Error fetching columns:', err);
    } finally {
      setLoading(false);
    }
  };

  const addColumn = async () => {
    if (!newColumnTitle.trim()) return;
    
    const newCol: Column = {
      id: Date.now().toString(),
      title: newColumnTitle,
      items: []
    };

    if (user) {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from('product_lists')
          .insert([{
            user_id: user.id,
            title: newColumnTitle,
            items: []
          }])
          .select();
        
        if (error) throw error;
        if (data) {
          const savedCol: Column = {
            id: data[0].id,
            title: data[0].title,
            items: data[0].items
          };
          setColumns([...columns, savedCol]);
        }
      } catch (err) {
        console.error('Error adding column:', err);
      } finally {
        setLoading(false);
      }
    } else {
      const updated = [...columns, newCol];
      setColumns(updated);
      localStorage.setItem('product_lists', JSON.stringify(updated));
    }

    setNewColumnTitle('');
    setIsAddingColumn(false);
  };

  const deleteColumn = async (id: string) => {
    if (user) {
      setSyncing(id);
      try {
        const { error } = await supabase
          .from('product_lists')
          .delete()
          .eq('id', id);
        
        if (error) throw error;
        setColumns(columns.filter(col => col.id !== id));
      } catch (err) {
        console.error('Error deleting column:', err);
      } finally {
        setSyncing(null);
      }
    } else {
      const updated = columns.filter(col => col.id !== id);
      setColumns(updated);
      localStorage.setItem('product_lists', JSON.stringify(updated));
    }
  };

  const addItem = async (columnId: string) => {
    const text = itemInputs[columnId];
    if (!text?.trim()) return;
    
    const column = columns.find(c => c.id === columnId);
    if (!column) return;

    const newItems = [...column.items, text];

    if (user) {
      setSyncing(columnId);
      try {
        const { error } = await supabase
          .from('product_lists')
          .update({ items: newItems })
          .eq('id', columnId);
        
        if (error) throw error;
        
        setColumns(columns.map(col => {
          if (col.id === columnId) {
            return { ...col, items: newItems };
          }
          return col;
        }));
      } catch (err) {
        console.error('Error adding item:', err);
      } finally {
        setSyncing(null);
      }
    } else {
      const updated = columns.map(col => {
        if (col.id === columnId) {
          return { ...col, items: newItems };
        }
        return col;
      });
      setColumns(updated);
      localStorage.setItem('product_lists', JSON.stringify(updated));
    }
    
    setItemInputs({ ...itemInputs, [columnId]: '' });
  };

  const deleteItem = async (columnId: string, itemIndex: number) => {
    const column = columns.find(c => c.id === columnId);
    if (!column) return;

    const newItems = [...column.items];
    newItems.splice(itemIndex, 1);

    if (user) {
      setSyncing(columnId);
      try {
        const { error } = await supabase
          .from('product_lists')
          .update({ items: newItems })
          .eq('id', columnId);
        
        if (error) throw error;

        setColumns(columns.map(col => {
          if (col.id === columnId) {
            return { ...col, items: newItems };
          }
          return col;
        }));
      } catch (err) {
        console.error('Error deleting item:', err);
      } finally {
        setSyncing(null);
      }
    } else {
      const updated = columns.map(col => {
        if (col.id === columnId) {
          return { ...col, items: newItems };
        }
        return col;
      });
      setColumns(updated);
      localStorage.setItem('product_lists', JSON.stringify(updated));
    }
  };

  const getHeaderStyle = (title: string) => {
    if (title.toLowerCase().includes('clean')) return 'border-emerald-500 text-emerald-600 bg-emerald-50';
    if (title.toLowerCase().includes('dirty')) return 'border-rose-500 text-rose-600 bg-rose-50';
    return 'border-blue-500 text-blue-600 bg-blue-50';
  };

  return (
    <div className="max-w-[1600px] mx-auto px-4 py-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
        <div>
          <h1 className="text-5xl font-black text-slate-900 dark:text-white tracking-tighter mb-2">
            Product <span className="text-blue-600">Lists</span>
          </h1>
          <p className="text-slate-500 font-medium">Organize your audited products into forensic categories.</p>
          {!user && (
            <div className="mt-2 flex items-center gap-2 text-amber-600 dark:text-amber-400 text-xs font-bold">
              <AlertTriangle size={14} />
              Sign in to sync your lists across devices.
            </div>
          )}
        </div>

        <button 
          onClick={() => setIsAddingColumn(true)}
          className="flex items-center gap-2 bg-slate-900 dark:bg-white dark:text-slate-900 text-white px-6 py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-black dark:hover:bg-slate-100 transition-all shadow-xl"
        >
          <PlusCircle size={18} /> Add Column
        </button>
      </div>

      {isAddingColumn && (
        <div className="mb-12 p-8 bg-white dark:bg-slate-900 rounded-[2.5rem] border-2 border-dashed border-slate-200 dark:border-slate-800 animate-in fade-in slide-in-from-top-4">
          <div className="flex flex-col md:flex-row gap-4">
            <input 
              autoFocus
              value={newColumnTitle}
              onChange={(e) => setNewColumnTitle(e.target.value)}
              placeholder="Enter column title..."
              className="flex-grow p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 outline-none focus:border-blue-500 font-bold dark:text-white"
              onKeyDown={(e) => e.key === 'Enter' && addColumn()}
            />
            <div className="flex gap-2">
              <button onClick={addColumn} className="bg-blue-600 text-white px-8 py-4 rounded-2xl font-black uppercase text-xs">Add Column</button>
              <button onClick={() => setIsAddingColumn(false)} className="bg-slate-100 dark:bg-slate-800 text-slate-400 px-6 py-4 rounded-2xl font-black uppercase text-xs hover:bg-slate-200 dark:hover:bg-slate-700"><X size={18} /></button>
            </div>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
          <Loader2 className="animate-spin text-blue-600" size={48} />
          <p className="font-black uppercase tracking-widest text-xs text-slate-400">Syncing with Registry...</p>
        </div>
      ) : (
        <div className="flex gap-8 overflow-x-auto pb-8 snap-x no-scrollbar">
          {columns.map((column) => (
            <div key={column.id} className="min-w-[340px] md:min-w-[400px] flex-shrink-0 snap-center">
              <div className="bg-white dark:bg-slate-900 rounded-[3rem] border border-slate-100 dark:border-slate-800 shadow-xl overflow-hidden flex flex-col h-full min-h-[500px]">
                {/* Column Header */}
                <div className={`px-8 py-6 border-b-4 flex items-center justify-between ${getHeaderStyle(column.title)}`}>
                  <div className="flex items-center gap-3">
                    <h3 className="font-black uppercase tracking-widest text-sm truncate">{column.title}</h3>
                    {syncing === column.id && <Loader2 size={14} className="animate-spin opacity-50" />}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="bg-white/50 px-3 py-1 rounded-full text-[10px] font-black">{column.items.length}</span>
                    <button onClick={() => deleteColumn(column.id)} className="p-2 hover:bg-white/30 rounded-lg transition-colors">
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>

                {/* Items List */}
                <div className="p-6 flex-grow space-y-3">
                  {column.items.map((item, idx) => (
                    <div key={idx} className="group flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800/50 rounded-[1.5rem] border border-slate-100 dark:border-slate-800 hover:border-blue-200 dark:hover:border-blue-900 transition-all hover:shadow-md animate-in fade-in slide-in-from-bottom-2">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-white dark:bg-slate-800 rounded-xl shadow-sm text-slate-400">
                          <Package size={14} />
                        </div>
                        <span className="font-bold text-slate-700 dark:text-slate-300 text-sm">{item}</span>
                      </div>
                      <button 
                        onClick={() => deleteItem(column.id, idx)}
                        className="opacity-0 group-hover:opacity-100 p-2 text-slate-300 hover:text-rose-500 transition-all"
                      >
                        <X size={16} />
                      </button>
                    </div>
                  ))}

                  {column.items.length === 0 && (
                    <div className="py-12 flex flex-col items-center text-center opacity-30">
                      <Layout size={40} className="mb-2 dark:text-white" />
                      <p className="text-[10px] font-black uppercase tracking-widest dark:text-white">Empty Category</p>
                    </div>
                  )}
                </div>

                {/* Add Item Footer */}
                <div className="p-6 border-t border-slate-50 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/20">
                  <div className="flex gap-2">
                    <input 
                      value={itemInputs[column.id] || ''}
                      onChange={(e) => setItemInputs({ ...itemInputs, [column.id]: e.target.value })}
                      placeholder="Add product name..."
                      className="flex-grow p-3 text-sm bg-white dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-700 outline-none focus:border-blue-500 font-medium dark:text-white"
                      onKeyDown={(e) => e.key === 'Enter' && addItem(column.id)}
                    />
                    <button 
                      onClick={() => addItem(column.id)}
                      className="p-3 bg-slate-900 dark:bg-blue-600 text-white rounded-xl hover:bg-blue-600 dark:hover:bg-blue-700 transition-colors shadow-lg shadow-slate-200 dark:shadow-none"
                    >
                      <Plus size={18} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}

          <button 
            onClick={() => setIsAddingColumn(true)}
            className="min-w-[340px] flex-shrink-0 flex flex-col items-center justify-center border-4 border-dashed border-slate-200 dark:border-slate-800 rounded-[3rem] text-slate-300 hover:text-blue-500 hover:border-blue-300 hover:bg-blue-50/20 transition-all group"
          >
            <Plus size={48} className="mb-4 group-hover:scale-110 transition-transform" />
            <span className="font-black uppercase tracking-widest text-sm">Add Column</span>
          </button>
        </div>
      )}

      {/* Database Context Footer */}
      <div className="mt-16 p-10 bg-slate-950 text-white rounded-[4rem] relative overflow-hidden shadow-2xl">
         <div className="absolute right-0 bottom-0 translate-x-1/4 translate-y-1/4 opacity-10 pointer-events-none">
            <Database size={400} />
         </div>
         <div className="relative z-10 max-w-3xl">
            <div className="flex items-center gap-3 mb-6">
               <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
               <span className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-500">Academic Transparency Standard</span>
            </div>
            <h3 className="text-3xl font-black mb-6">Project Metadata</h3>
            <p className="text-slate-400 text-lg leading-relaxed mb-10 font-medium">
               This database serves as an academic registry for chemical transparency. Every entry is cross-referenced with global chemical hazard databases and verified through automated AI auditing.
            </p>
            <div className="flex flex-wrap gap-10">
               <div>
                  <span className="text-[10px] font-black text-blue-400 uppercase tracking-widest block mb-2">Registry Version</span>
                  <span className="text-xl font-black">Forensic_v3.2</span>
               </div>
               <div className="h-12 w-px bg-white/10 hidden md:block" />
               <div>
                  <span className="text-[10px] font-black text-blue-400 uppercase tracking-widest block mb-2">Confidence Level</span>
                  <span className="text-xl font-black">99.8% Data Accuracy</span>
               </div>
               <div className="h-12 w-px bg-white/10 hidden md:block" />
               <div>
                  <span className="text-[10px] font-black text-blue-400 uppercase tracking-widest block mb-2">Sync Node</span>
                  <span className="text-xl font-black text-emerald-400">Stable_Active</span>
               </div>
            </div>
         </div>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        .no-scrollbar::-webkit-scrollbar {
          display: none;
        }
        .no-scrollbar {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}} />
    </div>
  );
};

export default AllProducts;
