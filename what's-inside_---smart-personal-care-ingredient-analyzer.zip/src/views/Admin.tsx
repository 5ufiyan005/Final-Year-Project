
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ChevronLeft, 
  Database, 
  Upload, 
  Trash2, 
  Plus, 
  Save, 
  Image as ImageIcon, 
  FileJson, 
  FileText, 
  Loader2, 
  CheckCircle2, 
  AlertTriangle,
  Search,
  Settings,
  ArrowRight
} from 'lucide-react';
import { supabase, supabaseAdmin } from '@/lib/supabase';
import { addNotification } from '@/lib/notifications';
import { GoogleGenAI } from "@google/genai";

const Admin: React.FC = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'create' | 'manage' | 'health'>('create');
  const [loading, setLoading] = useState(false);
  const [inputData, setInputData] = useState('');
  const [detectedType, setDetectedType] = useState<'json' | 'text' | null>(null);
  const [image, setImage] = useState<string | null>(null);
  const [products, setProducts] = useState<any[]>([]);
  const [status, setStatus] = useState<{ type: 'success' | 'error' | null, message: string }>({ type: null, message: '' });
  const [searchQuery, setSearchQuery] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    const { data, error } = await supabaseAdmin
      .from('products')
      .select('*')
      .order('created_at', { ascending: false });
    if (!error) setProducts(data || []);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;
    setInputData(value);
    
    if (value.trim()) {
      try {
        JSON.parse(value);
        setDetectedType('json');
      } catch {
        setDetectedType('text');
      }
    } else {
      setDetectedType(null);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setImage(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const processAndSave = async () => {
    if (!inputData.trim()) return;
    setLoading(true);
    setStatus({ type: null, message: '' });

    try {
      let finalData: any;

      if (detectedType === 'json') {
        finalData = JSON.parse(inputData);
      } else {
        // Use Gemini to convert text to our schema
        let apiKey = process.env.GEMINI_API_KEY || process.env.API_KEY;
        
        if (!apiKey && typeof window !== 'undefined' && (window as any).aistudio) {
          try {
            const hasKey = await (window as any).aistudio.hasSelectedApiKey();
            if (!hasKey) {
              await (window as any).aistudio.openSelectKey();
            }
            apiKey = process.env.API_KEY || (window as any).process?.env?.API_KEY;
          } catch (err) {
            console.warn("Key selection error:", err);
          }
        }

        if (!apiKey) {
          throw new Error("Gemini API Key is missing. Please check your environment configuration.");
        }

        const ai = new GoogleGenAI({ apiKey });
        const response = await ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: `Convert this product description into our database JSON format. 
          Fields required: name, brand, manufacturer, category, toxicity_score (0-100), safety_level (Low, Moderate, High), summary, product_history, usage_instructions, database_description, expert_rating (1-5), expert_comment, is_vegan, is_cruelty_free, is_pregnancy_safe, is_fragrance_free, ingredients_json, alternatives_json, health_insights_json, score_breakdown_json.
          Description: "${inputData}"`
        });
        
        const cleanJson = response.text?.replace(/```json|```/g, '').trim();
        finalData = JSON.parse(cleanJson);
      }

      // Add image if exists (storing as base64 for simplicity in project, or you could use Supabase Storage)
      const payload = {
        ...finalData,
        // Ensure keys match what the Analyze view expects
        ingredients_json: Array.isArray(finalData.ingredients_json || finalData.ingredients) ? (finalData.ingredients_json || finalData.ingredients) : [],
        alternatives_json: Array.isArray(finalData.alternatives_json || finalData.alternatives) ? (finalData.alternatives_json || finalData.alternatives) : [],
        health_insights_json: Array.isArray(finalData.health_insights_json || finalData.health_insights) ? (finalData.health_insights_json || finalData.health_insights) : [],
        score_breakdown_json: Array.isArray(finalData.score_breakdown_json || finalData.score_breakdown) ? (finalData.score_breakdown_json || finalData.score_breakdown) : [],
        expert_rating: finalData.expert_rating || 0,
        expert_comment: finalData.expert_comment || '',
        // Add custom image field if your schema supports it, otherwise it's metadata
        product_image: image 
      };

      let { error } = await supabaseAdmin.from('products').upsert(payload, { onConflict: 'name' });
      
      // Resilient Save: If columns are missing, retry without them
      if (error?.code === 'PGRST204') {
        console.warn("Schema mismatch. Retrying without expert columns...");
        const { expert_rating, expert_comment, product_image, ...safePayload } = payload;
        const { error: retryError } = await supabaseAdmin.from('products').upsert(safePayload, { onConflict: 'name' });
        error = retryError;
      }
      
      if (error) {
        console.error("DB Error:", error);
        throw new Error(`Database Error: ${error.message}. Hint: Please run the SQL migration to add missing columns.`);
      }

      addNotification(
        'New Product Added',
        `${payload.name} has been manually added to the registry by an administrator.`,
        'success'
      );

      setStatus({ type: 'success', message: 'Product successfully archived in Registry.' });
      setInputData('');
      setImage(null);
      fetchProducts();
    } catch (err: any) {
      setStatus({ type: 'error', message: err.message || 'Failed to process product data.' });
    } finally {
      setLoading(false);
    }
  };

  const deleteProduct = async (id: string) => {
    if (!confirm('Permanently delete this product from the registry?')) return;
    
    const { error } = await supabaseAdmin.from('products').delete().match({ id });
    if (!error) {
      setProducts(prev => prev.filter(p => p.id !== id));
    }
  };

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    p.brand.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 font-['Inter'] transition-colors">
      <header className="sticky top-0 z-50 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-all">
            <ChevronLeft size={24} />
          </button>
          <div className="flex items-center gap-3">
            <div className="bg-amber-500 p-2 rounded-xl text-white">
              <Settings size={20} />
            </div>
            <h1 className="text-xl font-black text-slate-900 dark:text-white tracking-tighter">
              Admin <span className="text-amber-500">Control</span> Center
            </h1>
          </div>
          <div className="flex items-center gap-2 px-3 py-1 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 rounded-full text-[10px] font-black uppercase tracking-widest border border-emerald-100 dark:border-emerald-900/30">
            <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
            Live Sync
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-12">
        {/* Tab Switcher */}
        <div className="flex gap-4 p-1.5 bg-slate-100 dark:bg-slate-900 rounded-[2rem] w-fit mx-auto mb-12 border border-slate-200 dark:border-slate-800">
          <button 
            onClick={() => setActiveTab('create')}
            className={`px-8 py-4 rounded-[1.5rem] font-black text-xs uppercase tracking-widest transition-all ${activeTab === 'create' ? 'bg-white dark:bg-slate-800 text-amber-600 shadow-xl' : 'text-slate-500'}`}
          >
            Create Entry
          </button>
          <button 
            onClick={() => setActiveTab('manage')}
            className={`px-8 py-4 rounded-[1.5rem] font-black text-xs uppercase tracking-widest transition-all ${activeTab === 'manage' ? 'bg-white dark:bg-slate-800 text-amber-600 shadow-xl' : 'text-slate-500'}`}
          >
            Manage Registry
          </button>
          <button 
            onClick={() => setActiveTab('health')}
            className={`px-8 py-4 rounded-[1.5rem] font-black text-xs uppercase tracking-widest transition-all ${activeTab === 'health' ? 'bg-white dark:bg-slate-800 text-amber-600 shadow-xl' : 'text-slate-500'}`}
          >
            Database Health
          </button>
        </div>

        {activeTab === 'health' ? (
          <div className="max-w-2xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4">
            <div className="bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-2xl">
              <h3 className="text-xl font-black text-slate-900 dark:text-white mb-6 flex items-center gap-2">
                <Database className="text-blue-500" />
                Schema Verification
              </h3>
              
              <p className="text-slate-500 dark:text-slate-400 text-sm mb-8 leading-relaxed">
                If users are reporting that their profile information (DOB, Gender, Phone) is not saving, it's likely because the database columns are missing.
              </p>

              <div className="bg-slate-900 p-6 rounded-2xl mb-8">
                <h4 className="text-[10px] font-black uppercase tracking-widest text-amber-500 mb-4">Required SQL Migration</h4>
                <pre className="text-xs text-slate-300 font-mono overflow-x-auto p-4 bg-black/40 rounded-xl">
{`-- 1. Update Profiles
ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS dob DATE,
ADD COLUMN IF NOT EXISTS gender TEXT,
ADD COLUMN IF NOT EXISTS phone TEXT,
ADD COLUMN IF NOT EXISTS bio TEXT;

-- 2. Search History
CREATE TABLE IF NOT EXISTS search_history (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  search_term TEXT NOT NULL,
  is_scan BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 3. Product Likes
CREATE TABLE IF NOT EXISTS product_likes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  product_name TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, product_name)
);

-- 4. Watchlist/Lists
CREATE TABLE IF NOT EXISTS watchlist (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  product_name TEXT NOT NULL,
  list_id TEXT NOT NULL,
  list_title TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 5. Reviews
CREATE TABLE IF NOT EXISTS reviews (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  product_name TEXT NOT NULL,
  rating INTEGER CHECK (rating >= 1 AND rating <= 5),
  comment TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 6. Chemical Watchlist
CREATE TABLE IF NOT EXISTS chemical_watchlist (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  chemical_name TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, chemical_name)
);

-- 7. Product Lists (Custom Columns)
CREATE TABLE IF NOT EXISTS product_lists (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  items JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 8. Enable RLS and Add Policies
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE search_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE product_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE watchlist ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE chemical_watchlist ENABLE ROW LEVEL SECURITY;
ALTER TABLE product_lists ENABLE ROW LEVEL SECURITY;

-- 9. Enable Realtime for Tables
-- IMPORTANT: Run these in your Supabase SQL Editor to enable live updates!
ALTER PUBLICATION supabase_realtime ADD TABLE search_history;
ALTER PUBLICATION supabase_realtime ADD TABLE watchlist;
ALTER PUBLICATION supabase_realtime ADD TABLE chemical_watchlist;
ALTER PUBLICATION supabase_realtime ADD TABLE product_lists;
ALTER PUBLICATION supabase_realtime ADD TABLE product_likes;
ALTER PUBLICATION supabase_realtime ADD TABLE reviews;

-- Profiles Policies
DROP POLICY IF EXISTS "Users can read own profile" ON profiles;
CREATE POLICY "Users can read own profile" ON profiles FOR SELECT USING (auth.uid() = id);
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
CREATE POLICY "Users can update own profile" ON profiles FOR UPDATE USING (auth.uid() = id);

-- Search History Policies
DROP POLICY IF EXISTS "Users can manage own search history" ON search_history;
CREATE POLICY "Users can manage own search history" ON search_history FOR ALL USING (auth.uid() = user_id);

-- Product Likes Policies
DROP POLICY IF EXISTS "Anyone can read likes" ON product_likes;
CREATE POLICY "Anyone can read likes" ON product_likes FOR SELECT USING (true);
DROP POLICY IF EXISTS "Users can manage own likes" ON product_likes;
CREATE POLICY "Users can manage own likes" ON product_likes FOR ALL USING (auth.uid() = user_id);

-- Watchlist Policies
DROP POLICY IF EXISTS "Users can manage own watchlist" ON watchlist;
CREATE POLICY "Users can manage own watchlist" ON watchlist FOR ALL USING (auth.uid() = user_id);

-- Reviews Policies
DROP POLICY IF EXISTS "Anyone can read reviews" ON reviews;
CREATE POLICY "Anyone can read reviews" ON reviews FOR SELECT USING (true);
DROP POLICY IF EXISTS "Users can manage own reviews" ON reviews;
CREATE POLICY "Users can manage own reviews" ON reviews FOR ALL USING (auth.uid() = user_id);

-- Chemical Watchlist Policies
DROP POLICY IF EXISTS "Users can manage own chemical watchlist" ON chemical_watchlist;
CREATE POLICY "Users can manage own chemical watchlist" ON chemical_watchlist FOR ALL USING (auth.uid() = user_id);

-- Product Lists Policies
DROP POLICY IF EXISTS "Users can manage own product lists" ON product_lists;
CREATE POLICY "Users can manage own product lists" ON product_lists FOR ALL USING (auth.uid() = user_id);`}
                </pre>
                <button 
                  onClick={() => {
                    const sql = `-- 1. Update Profiles\nALTER TABLE profiles \nADD COLUMN IF NOT EXISTS dob DATE,\nADD COLUMN IF NOT EXISTS gender TEXT,\nADD COLUMN IF NOT EXISTS phone TEXT,\nADD COLUMN IF NOT EXISTS bio TEXT;\n\n-- 2. Search History\nCREATE TABLE IF NOT EXISTS search_history (\n  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),\n  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,\n  search_term TEXT NOT NULL,\n  is_scan BOOLEAN DEFAULT false,\n  created_at TIMESTAMPTZ DEFAULT now()\n);\n\n-- 3. Product Likes\nCREATE TABLE IF NOT EXISTS product_likes (\n  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),\n  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,\n  product_name TEXT NOT NULL,\n  created_at TIMESTAMPTZ DEFAULT now(),\n  UNIQUE(user_id, product_name)\n);\n\n-- 4. Watchlist/Lists\nCREATE TABLE IF NOT EXISTS watchlist (\n  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),\n  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,\n  product_name TEXT NOT NULL,\n  list_id TEXT NOT NULL,\n  list_title TEXT NOT NULL,\n  created_at TIMESTAMPTZ DEFAULT now()\n);\n\n-- 5. Reviews\nCREATE TABLE IF NOT EXISTS reviews (\n  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),\n  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,\n  product_name TEXT NOT NULL,\n  rating INTEGER CHECK (rating >= 1 AND rating <= 5),\n  comment TEXT,\n  created_at TIMESTAMPTZ DEFAULT now()\n);\n\n-- 6. Chemical Watchlist\nCREATE TABLE IF NOT EXISTS chemical_watchlist (\n  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),\n  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,\n  chemical_name TEXT NOT NULL,\n  created_at TIMESTAMPTZ DEFAULT now(),\n  UNIQUE(user_id, chemical_name)\n);\n\n-- 7. Product Lists (Custom Columns)\nCREATE TABLE IF NOT EXISTS product_lists (\n  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),\n  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,\n  title TEXT NOT NULL,\n  items JSONB DEFAULT '[]'::jsonb,\n  created_at TIMESTAMPTZ DEFAULT now()\n);\n\n-- 8. Enable RLS and Add Policies\nALTER TABLE profiles ENABLE ROW LEVEL SECURITY;\nALTER TABLE search_history ENABLE ROW LEVEL SECURITY;\nALTER TABLE product_likes ENABLE ROW LEVEL SECURITY;\nALTER TABLE watchlist ENABLE ROW LEVEL SECURITY;\nALTER TABLE reviews ENABLE ROW LEVEL SECURITY;\nALTER TABLE chemical_watchlist ENABLE ROW LEVEL SECURITY;\nALTER TABLE product_lists ENABLE ROW LEVEL SECURITY;\n\n-- 9. Enable Realtime for Tables\n-- Note: This might fail if the publication already exists or tables are already added.\n-- It's safer to run these individually in the SQL editor.\n-- ALTER PUBLICATION supabase_realtime ADD TABLE search_history;\n-- ALTER PUBLICATION supabase_realtime ADD TABLE watchlist;\n-- ALTER PUBLICATION supabase_realtime ADD TABLE chemical_watchlist;\n-- ALTER PUBLICATION supabase_realtime ADD TABLE product_lists;\n\n-- Profiles Policies\nDROP POLICY IF EXISTS "Users can read own profile" ON profiles;\nCREATE POLICY "Users can read own profile" ON profiles FOR SELECT USING (auth.uid() = id);\nDROP POLICY IF EXISTS "Users can update own profile" ON profiles;\nCREATE POLICY "Users can update own profile" ON profiles FOR UPDATE USING (auth.uid() = id);\n\n-- Search History Policies\nDROP POLICY IF EXISTS "Users can manage own search history" ON search_history;\nCREATE POLICY "Users can manage own search history" ON search_history FOR ALL USING (auth.uid() = user_id);\n\n-- Product Likes Policies\nDROP POLICY IF EXISTS "Anyone can read likes" ON product_likes;\nCREATE POLICY "Anyone can read likes" ON product_likes FOR SELECT USING (true);\nDROP POLICY IF EXISTS "Users can manage own likes" ON product_likes;\nCREATE POLICY "Users can manage own likes" ON product_likes FOR ALL USING (auth.uid() = user_id);\n\n-- Watchlist Policies\nDROP POLICY IF EXISTS "Users can manage own watchlist" ON watchlist;\nCREATE POLICY "Users can manage own watchlist" ON watchlist FOR ALL USING (auth.uid() = user_id);\n\n-- Reviews Policies\nDROP POLICY IF EXISTS "Anyone can read reviews" ON reviews;\nCREATE POLICY "Anyone can read reviews" ON reviews FOR SELECT USING (true);\nDROP POLICY IF EXISTS "Users can manage own reviews" ON reviews;\nCREATE POLICY "Users can manage own reviews" ON reviews FOR ALL USING (auth.uid() = user_id);\n\n-- Chemical Watchlist Policies\nDROP POLICY IF EXISTS "Users can manage own chemical watchlist" ON chemical_watchlist;\nCREATE POLICY "Users can manage own chemical watchlist" ON chemical_watchlist FOR ALL USING (auth.uid() = user_id);\n\n-- Product Lists Policies\nDROP POLICY IF EXISTS "Users can manage own product lists" ON product_lists;\nCREATE POLICY "Users can manage own product lists" ON product_lists FOR ALL USING (auth.uid() = user_id);`;
                    navigator.clipboard.writeText(sql);
                    alert("SQL copied to clipboard! Please run this in your Supabase SQL Editor.");
                  }}
                  className="mt-4 text-[10px] font-black uppercase tracking-widest text-blue-400 hover:text-blue-300 transition-colors"
                >
                  Copy SQL to Clipboard
                </button>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-700">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full" />
                    <span className="text-sm font-bold">Profiles Table</span>
                  </div>
                  <span className="text-[10px] font-black uppercase tracking-widest text-emerald-500">Active</span>
                </div>
                
                <div className="p-4 bg-amber-50 dark:bg-amber-900/10 rounded-xl border border-amber-100 dark:border-amber-900/30">
                  <p className="text-xs text-amber-700 dark:text-amber-400 font-medium">
                    Note: If you haven't run the migration above, the new profile fields will be ignored by the database.
                  </p>
                </div>
              </div>
            </div>
          </div>
        ) : activeTab === 'create' ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 animate-in fade-in slide-in-from-bottom-4">
            <div className="space-y-8">
              <div className="bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-2xl">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                    {detectedType === 'json' ? <FileJson className="text-blue-500" /> : <FileText className="text-amber-500" />}
                    Product Intelligence Input
                  </h3>
                  {detectedType && (
                    <span className="px-3 py-1 bg-slate-100 dark:bg-slate-800 text-[10px] font-black uppercase tracking-widest rounded-full opacity-60">
                      {detectedType} detected
                    </span>
                  )}
                </div>
                
                <textarea 
                  value={inputData}
                  onChange={handleInputChange}
                  placeholder="Paste JSON structure or raw product description here. Our AI will identify the chemical details automatically."
                  className="w-full h-80 p-6 bg-slate-50 dark:bg-slate-950 rounded-[2rem] border-2 border-slate-100 dark:border-slate-800 focus:border-amber-500 outline-none font-medium transition-all resize-none"
                />

                <div className="mt-8 flex items-center gap-4">
                  <button 
                    onClick={processAndSave}
                    disabled={loading || !inputData.trim()}
                    className="flex-grow py-5 bg-amber-500 text-white rounded-[1.5rem] font-black text-sm uppercase tracking-widest hover:bg-amber-600 transition-all shadow-xl shadow-amber-100 dark:shadow-none disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {loading ? <Loader2 className="animate-spin" /> : <Save size={18} />}
                    Identify & Archive Product
                  </button>
                </div>
              </div>

              {status.type && (
                <div className={`p-6 rounded-[2rem] border animate-in slide-in-from-top-2 flex items-center gap-4 ${status.type === 'success' ? 'bg-emerald-50 border-emerald-100 text-emerald-700 dark:bg-emerald-900/20' : 'bg-rose-50 border-rose-100 text-rose-700 dark:bg-rose-900/20'}`}>
                  {status.type === 'success' ? <CheckCircle2 size={24} /> : <AlertTriangle size={24} />}
                  <span className="font-bold text-sm">{status.message}</span>
                </div>
              )}
            </div>

            <div className="space-y-8">
              <div className="bg-white dark:bg-slate-900 p-8 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-2xl">
                <h3 className="text-lg font-black text-slate-900 dark:text-white mb-6 flex items-center gap-2">
                  <ImageIcon className="text-rose-500" />
                  Product Visual Assets
                </h3>
                
                <div className="aspect-square bg-slate-50 dark:bg-slate-950 rounded-[2rem] border-4 border-dashed border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center relative overflow-hidden group">
                  {image ? (
                    <>
                      <img src={image} alt="Preview" className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <button onClick={removeImage} className="p-4 bg-rose-500 text-white rounded-full hover:bg-rose-600 transition-all">
                          <Trash2 size={24} />
                        </button>
                      </div>
                    </>
                  ) : (
                    <div className="text-center p-8">
                      <div className="w-20 h-20 bg-slate-100 dark:bg-slate-800 rounded-3xl flex items-center justify-center text-slate-400 mx-auto mb-4">
                        <Upload size={32} />
                      </div>
                      <p className="text-slate-500 dark:text-slate-400 font-bold mb-6">Drop high-res image here</p>
                      <button 
                        onClick={() => fileInputRef.current?.click()}
                        className="px-6 py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-slate-50 transition-all"
                      >
                        Select Media File
                      </button>
                      <input type="file" hidden ref={fileInputRef} accept="image/*" onChange={handleImageUpload} />
                    </div>
                  )}
                </div>
              </div>

              <div className="bg-slate-900 p-8 rounded-[3rem] text-white">
                <h4 className="text-xs font-black uppercase tracking-[0.2em] text-amber-500 mb-4">Admin Tip</h4>
                <p className="text-slate-400 text-sm leading-relaxed">
                  You can paste a plain paragraph like "Dove soap is a white bar made by Unilever with stearic acid and sodium laurate..." and our AI will automatically parse the score and ingredients for the registry.
                </p>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4">
            <div className="relative max-w-2xl mx-auto mb-12">
              <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
              <input 
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search registry by name or brand..."
                className="w-full pl-16 pr-6 py-5 bg-white dark:bg-slate-900 rounded-[2rem] border-2 border-slate-100 dark:border-slate-800 focus:border-amber-500 outline-none font-bold shadow-xl transition-all"
              />
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-[3rem] border border-slate-200 dark:border-slate-800 overflow-hidden shadow-2xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-slate-50 dark:bg-slate-950 border-b border-slate-100 dark:border-slate-800">
                      <th className="px-8 py-6 text-[10px] font-black uppercase tracking-widest text-slate-400">Product Entry</th>
                      <th className="px-8 py-6 text-[10px] font-black uppercase tracking-widest text-slate-400">Category</th>
                      <th className="px-8 py-6 text-[10px] font-black uppercase tracking-widest text-slate-400">Score</th>
                      <th className="px-8 py-6 text-[10px] font-black uppercase tracking-widest text-slate-400">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {filteredProducts.map((p) => (
                      <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                        <td className="px-8 py-6">
                          <div>
                            <p className="font-black text-slate-900 dark:text-white">{p.name}</p>
                            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{p.brand}</p>
                          </div>
                        </td>
                        <td className="px-8 py-6">
                          <span className="px-3 py-1 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-full text-[10px] font-black uppercase tracking-widest">
                            {p.category}
                          </span>
                        </td>
                        <td className="px-8 py-6">
                          <span className={`font-black ${p.toxicity_score > 60 ? 'text-rose-500' : p.toxicity_score > 30 ? 'text-amber-500' : 'text-emerald-500'}`}>
                            {p.toxicity_score}
                          </span>
                        </td>
                        <td className="px-8 py-6">
                          <div className="flex items-center gap-3">
                            <button onClick={() => deleteProduct(p.id)} className="p-3 text-slate-300 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded-xl transition-all">
                              <Trash2 size={18} />
                            </button>
                            <button onClick={() => { setInputData(JSON.stringify(p, null, 2)); setActiveTab('create'); }} className="p-3 text-slate-300 hover:text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-xl transition-all">
                              <FileJson size={18} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {filteredProducts.length === 0 && (
                <div className="p-20 text-center">
                  <Database size={48} className="mx-auto text-slate-200 mb-4" />
                  <p className="text-slate-400 font-bold">No matching records found in registry.</p>
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      <footer className="max-w-7xl mx-auto px-4 py-20 text-center opacity-30">
        <p className="text-xs font-black uppercase tracking-[0.4em]">Forensic Registry System • Secure_Admin_Node</p>
      </footer>
    </div>
  );
};

export default Admin;
