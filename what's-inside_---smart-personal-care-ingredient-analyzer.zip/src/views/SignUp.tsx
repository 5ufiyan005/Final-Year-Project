
import React, { useState } from 'react';
import { Mail, Lock, ArrowRight, ShieldCheck, Loader2, AlertCircle, User, ChevronRight } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { migrateGuestData } from '../lib/migration';

interface SignUpProps {
  onComplete: () => void;
  onSkip: () => void;
  onSignIn: () => void;
}

const SignUp: React.FC<SignUpProps> = ({ onComplete, onSkip, onSignIn }) => {
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const { data: { user }, error: signUpError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName,
          }
        }
      });

      if (signUpError) throw signUpError;

      if (user) {
        await migrateGuestData(user.id);
        const { error: profileError } = await supabase
          .from('profiles')
          .upsert({
            id: user.id,
            full_name: fullName,
            email: email,
            updated_at: new Date().toISOString(),
          });
        if (profileError) throw profileError;
      }

      alert('Registration successful! Please check your email for verification.');
      onComplete();
    } catch (err: any) {
      setError(err.message || 'An error occurred during registration.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[110] bg-slate-50 dark:bg-slate-950 flex items-center justify-center px-4 overflow-y-auto py-10">
      <div className="max-w-md w-full">
        <div className="bg-white dark:bg-slate-900 rounded-[3rem] p-8 md:p-10 shadow-2xl shadow-blue-100 dark:shadow-none border border-slate-100 dark:border-slate-800 relative overflow-hidden">
          <div className="absolute -top-10 -right-10 w-40 h-40 bg-blue-50 dark:bg-blue-900/20 rounded-full blur-3xl opacity-50" />
          
          <div className="text-center mb-8 relative">
            <div className="bg-blue-600 w-16 h-16 rounded-2xl flex items-center justify-center text-white mx-auto mb-6 shadow-lg shadow-blue-200 dark:shadow-blue-900/40">
              <ShieldCheck size={32} />
            </div>
            <h1 className="text-3xl font-black text-slate-900 dark:text-white mb-2">
              Join the Movement
            </h1>
            <p className="text-slate-500 dark:text-slate-400 text-sm">
              Start analyzing your household products today for a toxin-free life.
            </p>
          </div>

          {error && (
            <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-900/30 rounded-2xl text-red-600 dark:text-red-400 text-sm flex items-center gap-2">
              <AlertCircle size={18} />
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="relative">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
              <input 
                type="text" 
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Full Name"
                className="w-full pl-12 pr-4 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 focus:border-blue-500 transition-all outline-none text-slate-900 dark:text-white"
              />
            </div>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
              <input 
                type="email" 
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email Address"
                className="w-full pl-12 pr-4 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 focus:border-blue-500 transition-all outline-none text-slate-900 dark:text-white"
              />
            </div>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
              <input 
                type="password" 
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
                className="w-full pl-12 pr-4 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 focus:border-blue-500 transition-all outline-none text-slate-900 dark:text-white"
              />
            </div>

            <button 
              type="submit"
              disabled={loading}
              className="w-full py-4 bg-blue-600 text-white rounded-2xl font-bold flex items-center justify-center gap-3 hover:bg-blue-700 transition-all shadow-lg shadow-blue-100 dark:shadow-blue-900/20 mt-6 active:scale-95"
            >
              {loading ? <Loader2 className="animate-spin" /> : (
                <>
                  Create Account
                  <ArrowRight size={20} />
                </>
              )}
            </button>
          </form>

          <div className="mt-8 flex flex-col gap-4">
            <button 
              onClick={onSkip}
              className="w-full py-4 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-slate-200 dark:hover:bg-slate-700 transition-all active:scale-95"
            >
              Sign Up Later
              <ChevronRight size={18} />
            </button>
            
            <div className="text-center">
              <button 
                onClick={onSignIn}
                className="text-sm font-semibold text-blue-600 hover:text-blue-700 underline-offset-4 hover:underline"
              >
                Already have an account? Sign In
              </button>
            </div>

            <p className="text-center text-xs text-slate-400 dark:text-slate-500">
              By signing up, you agree to our Terms of Service and Privacy Policy.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignUp;
