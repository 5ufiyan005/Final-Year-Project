
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Loader2, ChevronLeft, Camera, User, Mail, Lock, Phone, Calendar, AlignLeft, ChevronDown } from 'lucide-react';
import { supabase } from '../lib/supabase';

const EditProfile: React.FC = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  // Profile fields
  const [fullName, setFullName] = useState('');
  const [bio, setBio] = useState('');
  const [gender, setGender] = useState('');
  const [dob, setDob] = useState('');
  const [phone, setPhone] = useState('');
  
  // Auth fields
  const [email, setEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');

  useEffect(() => {
    const fetchProfile = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      const user = session?.user;
      
      if (!user) {
        navigate('/login');
        return;
      }

      setEmail(user.email || '');
      
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      if (profileData) {
        setFullName(profileData.full_name || '');
        setBio(profileData.bio || '');
        setGender(profileData.gender || '');
        setDob(profileData.dob || '');
        setPhone(profileData.phone || '');
      }
      
      setLoading(false);
    };

    fetchProfile();
  }, [navigate]);

  const handleSave = async () => {
    setSaving(true);
    setError(null);
    setSuccess(false);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      const user = session?.user;
      if (!user) throw new Error("No user found");

      // 1. Update Profile Data in Supabase
      const { error: profileError } = await supabase
        .from('profiles')
        .update({
          full_name: fullName,
          bio: bio,
          gender: gender,
          dob: dob,
          phone: phone,
          updated_at: new Date().toISOString(),
        })
        .eq('id', user.id);

      if (profileError) throw profileError;

      // 2. Update Auth Data (Password) if changed
      if (newPassword) {
        const { error: passwordError } = await supabase.auth.updateUser({
          password: newPassword
        });
        if (passwordError) throw passwordError;
      }

      setSuccess(true);
      setTimeout(() => navigate('/profile'), 1500);
    } catch (err: any) {
      setError(err.message || "Failed to update profile");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950">
        <Loader2 className="animate-spin text-blue-600" size={48} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col items-center px-6 pt-12 pb-24 transition-colors duration-300">
      <div className="w-full max-w-md flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between mb-12">
          <div className="flex items-center">
            <button onClick={() => navigate(-1)} className="p-2 -ml-2 text-slate-900 dark:text-white hover:text-blue-600 transition-colors">
              <ChevronLeft size={28} />
            </button>
            <h1 className="text-2xl font-black tracking-tight ml-2">Edit Profile</h1>
          </div>
          {success && (
            <span className="text-emerald-500 font-bold text-sm animate-pulse">Saved Successfully!</span>
          )}
        </div>

        {/* Form Sections */}
        <div className="space-y-8">
          {/* Section: Basic Info */}
          <div>
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4 ml-4">Basic Information</h3>
            <div className="bg-slate-50 dark:bg-slate-900 rounded-[2rem] border border-slate-100 dark:border-slate-800 overflow-hidden shadow-sm">
              <div className="border-b border-slate-200 dark:border-slate-800 px-8 py-5 flex items-center gap-4">
                <User size={20} className="text-slate-400" />
                <div className="flex-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-0.5">Full Name</label>
                  <input 
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Enter your name"
                    className="w-full bg-transparent outline-none text-slate-700 dark:text-slate-200 text-lg font-medium placeholder-slate-300"
                  />
                </div>
              </div>

              <div className="px-8 py-5 flex items-start gap-4">
                <AlignLeft size={20} className="text-slate-400 mt-1" />
                <div className="flex-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-0.5">Bio</label>
                  <textarea 
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    placeholder="Tell us about yourself..."
                    rows={3}
                    className="w-full bg-transparent outline-none text-slate-700 dark:text-slate-200 text-lg font-medium placeholder-slate-300 resize-none"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Section: Personal Details */}
          <div>
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4 ml-4">Personal Details</h3>
            <div className="bg-slate-50 dark:bg-slate-900 rounded-[2rem] border border-slate-100 dark:border-slate-800 overflow-hidden shadow-sm">
              <div className="border-b border-slate-200 dark:border-slate-800 px-8 py-5 flex items-center gap-4">
                <Calendar size={20} className="text-slate-400" />
                <div className="flex-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-0.5">Date of Birth</label>
                  <input 
                    type="date"
                    value={dob}
                    onChange={(e) => setDob(e.target.value)}
                    className="w-full bg-transparent outline-none text-slate-700 dark:text-slate-200 text-lg font-medium appearance-none"
                  />
                </div>
              </div>

              <div className="border-b border-slate-200 dark:border-slate-800 px-8 py-5 flex items-center gap-4">
                <User size={20} className="text-slate-400" />
                <div className="flex-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-0.5">Gender</label>
                  <div className="relative">
                    <select 
                      value={gender}
                      onChange={(e) => setGender(e.target.value)}
                      className="w-full bg-transparent outline-none text-slate-700 dark:text-slate-200 text-lg font-medium appearance-none cursor-pointer pr-10"
                    >
                      <option value="" disabled>Select Gender</option>
                      <option value="Female">Female</option>
                      <option value="Male">Male</option>
                      <option value="Non-binary">Non-binary</option>
                      <option value="Prefer not to say">Prefer not to say</option>
                    </select>
                    <ChevronDown className="absolute right-0 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size={20} />
                  </div>
                </div>
              </div>

              <div className="px-8 py-5 flex items-center gap-4">
                <Phone size={20} className="text-slate-400" />
                <div className="flex-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-0.5">Phone Number</label>
                  <input 
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="Enter your phone number"
                    className="w-full bg-transparent outline-none text-slate-700 dark:text-slate-200 text-lg font-medium placeholder-slate-300"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Section: Account Security */}
          <div>
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4 ml-4">Account Security</h3>
            <div className="bg-slate-50 dark:bg-slate-900 rounded-[2rem] border border-slate-100 dark:border-slate-800 overflow-hidden shadow-sm">
              <div className="border-b border-slate-200 dark:border-slate-800 px-8 py-5 flex items-center gap-4 opacity-60">
                <Mail size={20} className="text-slate-400" />
                <div className="flex-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-0.5">Email Address</label>
                  <input 
                    type="email"
                    value={email}
                    disabled
                    className="w-full bg-transparent outline-none text-slate-700 dark:text-slate-200 text-lg font-medium cursor-not-allowed"
                  />
                </div>
              </div>

              <div className="px-8 py-5 flex items-center gap-4">
                <Lock size={20} className="text-slate-400" />
                <div className="flex-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-0.5">New Password</label>
                  <input 
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-transparent outline-none text-slate-700 dark:text-slate-200 text-lg font-medium placeholder-slate-300"
                  />
                </div>
              </div>
            </div>
            <p className="text-[10px] text-slate-400 mt-3 ml-4">Leave password blank if you don't want to change it.</p>
          </div>
        </div>

        {error && (
          <div className="mt-8 p-4 bg-rose-50 dark:bg-rose-900/20 rounded-2xl border border-rose-100 dark:border-rose-800">
            <p className="text-rose-500 text-sm text-center font-bold">{error}</p>
          </div>
        )}

        {/* Action Button */}
        <div className="mt-12 pb-12">
          <button 
            onClick={handleSave}
            disabled={saving}
            className="w-full py-5 bg-blue-600 text-white rounded-2xl font-black text-xl uppercase tracking-widest hover:bg-blue-700 transition-all flex items-center justify-center shadow-xl shadow-blue-100 dark:shadow-none disabled:opacity-50"
          >
            {saving ? <Loader2 className="animate-spin" /> : 'Save Changes'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default EditProfile;
