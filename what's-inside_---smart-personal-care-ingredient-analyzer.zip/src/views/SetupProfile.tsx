
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Loader2, ChevronLeft, ChevronDown } from 'lucide-react';
import { supabase } from '../lib/supabase';

const SetupProfile: React.FC = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [dob, setDob] = useState('');
  const [gender, setGender] = useState('');
  const [phone, setPhone] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const checkUser = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) {
        navigate('/login');
      }
    };
    checkUser();
  }, [navigate]);

  const handleSave = async () => {
    setLoading(true);
    setError(null);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const user = session?.user;
      if (!user) throw new Error("No user found");

      const { error } = await supabase
        .from('profiles')
        .update({
          dob,
          gender,
          phone,
          updated_at: new Date().toISOString(),
        })
        .eq('id', user.id);
      
      if (error) throw error;

      navigate('/profile');
    } catch (err: any) {
      setError(err.message || "Failed to update profile");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col items-center px-6 pt-12 transition-colors duration-300">
      <div className="w-full max-w-md flex flex-col h-full min-h-[85vh]">
        {/* Header */}
        <div className="flex items-center mb-16">
          <button onClick={() => navigate(-1)} className="p-2 -ml-2 text-slate-900 hover:text-blue-600 transition-colors">
            <ChevronLeft size={28} />
          </button>
          <h1 className="text-2xl font-black tracking-tight ml-2">Profile</h1>
        </div>

        {/* Title */}
        <div className="text-center mb-12">
          <h2 className="text-2xl font-black tracking-wider leading-tight uppercase">
            Let's set up your<br />What's Inside Profile
          </h2>
        </div>

        {/* Form */}
        <div className="space-y-0 bg-slate-50 rounded-[2rem] overflow-hidden border border-slate-100 shadow-sm">
          <div className="border-b border-slate-200 px-8 py-4">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Date of Birth</label>
            <input 
              type="date"
              max={new Date().toISOString().split('T')[0]}
              value={dob}
              onChange={(e) => setDob(e.target.value)}
              className="w-full bg-transparent outline-none text-slate-700 text-lg font-medium appearance-none"
            />
          </div>
          <div className="border-b border-slate-200 px-8 py-4">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Gender</label>
            <div className="relative">
              <select 
                value={gender}
                onChange={(e) => setGender(e.target.value)}
                className="w-full bg-transparent outline-none text-slate-700 text-lg font-medium appearance-none cursor-pointer pr-10"
              >
                <option value="" disabled>Select Gender</option>
                <option value="Female">Female</option>
                <option value="Male">Male</option>
                <option value="Non-binary">Non-binary</option>
                <option value="Prefer not to say">Prefer not to say</option>
              </select>
              <ChevronDown className="absolute right-0 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size={20} />
            </div>
          </div>
          <div className="px-8 py-4">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Phone Number</label>
            <input 
              type="text"
              placeholder="Enter your phone number"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full bg-transparent outline-none text-slate-700 placeholder-slate-400 text-lg font-medium"
            />
          </div>
        </div>

        {error && (
          <p className="text-rose-500 text-sm mt-4 text-center font-bold">{error}</p>
        )}

        {/* Buttons */}
        <div className="mt-auto flex flex-col gap-8 pb-12">
          <button 
            onClick={handleSave}
            disabled={loading}
            className="w-full py-5 bg-slate-900 text-white rounded-2xl font-black text-xl uppercase tracking-widest hover:bg-slate-800 transition-all flex items-center justify-center shadow-xl shadow-slate-200"
          >
            {loading ? <Loader2 className="animate-spin" /> : 'Save'}
          </button>
          
          <button 
            onClick={() => navigate('/profile')}
            className="w-full text-slate-400 font-black text-lg uppercase tracking-widest hover:text-slate-600 transition-all"
          >
            Not Now
          </button>
        </div>
      </div>
    </div>
  );
};

export default SetupProfile;
