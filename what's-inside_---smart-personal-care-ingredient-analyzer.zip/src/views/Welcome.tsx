import React, { useEffect, useCallback } from 'react';
import { ShieldCheck, ArrowRight, Sparkles, Heart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface WelcomeProps {
  onEnter: () => void;
}

const CuteLabBuddy = () => (
  <div className="relative mb-8 animate-bounce" style={{ animationDuration: '3s' }}>
    <div className="relative w-32 h-32 mx-auto">
      {/* Floating Bubbles */}
      <div className="absolute -top-4 -right-2 w-4 h-4 bg-white/60 rounded-full animate-ping delay-100" />
      <div className="absolute -top-8 left-4 w-3 h-3 bg-blue-400/40 rounded-full animate-pulse delay-300" />
      <div className="absolute top-0 -left-4 w-2 h-2 bg-pink-400/40 rounded-full animate-bounce delay-500" />
      
      {/* The Beaker Character */}
      <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-2xl">
        <path 
          d="M30 20 L35 20 L35 40 Q35 45 30 50 L20 80 Q15 90 25 90 L75 90 Q85 90 80 80 L70 50 Q65 45 65 40 L65 20 L70 20" 
          fill="white" 
          stroke="#3B82F6" 
          strokeWidth="3" 
        />
        {/* Liquid inside */}
        <path 
          d="M23 75 Q18 85 25 85 L75 85 Q82 85 77 75 L70 55 Q65 50 65 45 L65 40 L35 40 Q35 45 30 50 Z" 
          fill="#DBEAFE" 
        />
        {/* Cute Face */}
        <circle cx="42" cy="65" r="3" fill="#1E293B" />
        <circle cx="58" cy="65" r="3" fill="#1E293B" />
        <path d="M46 75 Q50 80 54 75" fill="none" stroke="#1E293B" strokeWidth="2" strokeLinecap="round" />
        {/* Blush */}
        <circle cx="38" cy="70" r="2" fill="#FDA4AF" opacity="0.6" />
        <circle cx="62" cy="70" r="2" fill="#FDA4AF" opacity="0.6" />
      </svg>
      
      <div className="absolute -bottom-2 -right-2 bg-white p-2 rounded-full shadow-lg animate-pulse">
        <Heart size={16} className="text-pink-500 fill-pink-500" />
      </div>
    </div>
  </div>
);

const Welcome: React.FC<WelcomeProps> = ({ onEnter }) => {
  const navigate = useNavigate();

  const handleStart = useCallback(() => {
    navigate('/');
    onEnter();
  }, [navigate, onEnter]);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === ' ' || event.code === 'Space') {
        event.preventDefault(); // Prevent page scrolling
        handleStart();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleStart]);

  return (
    <div className="fixed inset-0 z-[100] bg-[#FADADD] overflow-hidden flex flex-col items-center justify-center font-['Inter']">
      <div className="absolute top-0 left-0 w-full h-full -z-10">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-blue-400/20 rounded-full blur-[120px] animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-pink-400/20 rounded-full blur-[120px] animate-pulse delay-700" />
      </div>

      <div className="max-w-4xl w-full px-6 text-center relative z-10 pt-20">
        {/* Cute Character - Added mt-12 to shift it slightly lower within the content block */}
        <div className="animate-pop-in mt-12 mb-10" style={{ animationDelay: '200ms' }}>
          <CuteLabBuddy />
        </div>

        {/* Branding Block */}
        <div className="flex items-center justify-center mb-10 animate-pop-in">
          <div className="bg-white/40 border border-pink-200/50 p-8 md:p-10 rounded-[2.5rem] backdrop-blur-md shadow-2xl flex items-center gap-6 md:gap-8 hover:scale-105 transition-transform cursor-default">
            <div className="relative">
              <div className="absolute inset-0 bg-blue-500 blur-2xl opacity-20 animate-pulse" />
              <div className="bg-gradient-to-br from-blue-600 to-indigo-500 p-5 rounded-[1.5rem] text-white relative shadow-xl">
                <ShieldCheck size={56} strokeWidth={1.5} />
              </div>
            </div>
            <div className="text-left">
              <span className="text-4xl md:text-6xl font-black text-slate-900 tracking-tighter leading-none">
                What's <br />
                Inside<span className="text-blue-600">?</span>
              </span>
            </div>
          </div>
        </div>

        {/* Headline */}
        <h1 
          className="text-4xl md:text-7xl font-black text-slate-900 tracking-tighter mb-6 leading-[0.9] animate-pop-in"
          style={{ animationDelay: '500ms' }}
        >
          Your Essentials <br />
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-600 via-indigo-600 to-pink-600">
            Decoded.
          </span>
        </h1>

        {/* Description */}
        <p 
          className="text-slate-700 text-lg md:text-2xl max-w-2xl mx-auto mb-12 leading-relaxed font-medium animate-pop-in"
          style={{ animationDelay: '1000ms' }}
        >
          Uncover the hidden toxins in your daily essentials and find safer, cleaner alternatives instantly.
        </p>

        {/* Button */}
        <button 
          onClick={handleStart}
          className="group relative inline-flex items-center gap-3 bg-blue-600 text-white px-10 py-5 rounded-[2.5rem] font-bold text-xl hover:bg-blue-500 transition-all shadow-[0_10px_40px_-10px_rgba(37,99,235,0.4)] animate-pop-in active:scale-95"
          style={{ animationDelay: '1500ms' }}
        >
          Start Smart Living
          <ArrowRight className="group-hover:translate-x-1 transition-transform" />
          <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 text-[10px] text-slate-500 opacity-50 font-bold uppercase tracking-widest hidden md:block">Press Space to begin</span>
        </button>

        <div className="mt-20 flex flex-col items-center gap-2 opacity-70 animate-in fade-in duration-1000 delay-[2000ms]">
          <span className="text-slate-600 text-xs font-semibold uppercase tracking-[0.3em]">
            Developed by Sufiyan Malik • Roll #24
          </span>
        </div>
      </div>
    </div>
  );
};

export default Welcome;