import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { 
  ShieldCheck, 
  AlertTriangle, 
  ShieldAlert, 
  Loader2, 
  Package, 
  Search,
  ChevronRight,
  Database
} from 'lucide-react';
import { Link } from 'react-router-dom';

interface Product {
  id: string;
  name: string;
  brand: string;
  toxicity_score: number;
  safety_level: string;
  category: string;
}

const RegistryColumn: React.FC<{ 
  title: string; 
  products: Product[]; 
  variant: 'safe' | 'moderate' | 'high';
}> = ({ title, products, variant }) => {
  const styles = {
    safe: {
      header: 'bg-emerald-50 border-emerald-500 text-emerald-600',
      badge: 'bg-emerald-100 text-emerald-700',
      icon: <ShieldCheck size={18} />
    },
    moderate: {
      header: 'bg-amber-50 border-amber-500 text-amber-600',
      badge: 'bg-amber-100 text-amber-700',
      icon: <AlertTriangle size={18} />
    },
    high: {
      header: 'bg-rose-50 border-rose-500 text-rose-600',
      badge: 'bg-rose-100 text-rose-700',
      icon: <ShieldAlert size={18} />
    }
  }[variant];

  return (
    <div className="min-w-[340px] md:min-w-[400px] flex-shrink-0 snap-center">
      <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-xl overflow-hidden flex flex-col h-full min-h-[600px]">
        {/* Column Header */}
        <div className={`px-8 py-6 border-b-4 flex items-center justify-between sticky top-0 z-10 ${styles.header}`}>
          <div className="flex items-center gap-3">
            {styles.icon}
            <h3 className="font-black uppercase tracking-widest text-sm">{title}</h3>
          </div>
          <span className="bg-white/50 px-3 py-1 rounded-full text-[10px] font-black">{products.length}</span>
        </div>

        {/* Product Cards */}
        <div className="p-6 space-y-4 flex-grow overflow-y-auto max-h-[70vh]">
          {products.length === 0 ? (
            <div className="py-20 flex flex-col items-center justify-center text-slate-300">
               <Package size={48} className="mb-4 opacity-20" />
               <p className="text-[10px] font-black uppercase tracking-widest">No entries found</p>
            </div>
          ) : (
            products.map((product) => (
              <div key={product.id} className="group p-5 bg-slate-50 rounded-[2rem] border border-slate-100 hover:border-blue-200 transition-all hover:shadow-lg animate-in fade-in slide-in-from-bottom-2">
                <div className="flex justify-between items-start mb-3">
                   <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{product.category}</span>
                   <span className={`px-2 py-0.5 rounded-full text-[9px] font-black ${styles.badge}`}>
                     {product.toxicity_score} Score
                   </span>
                </div>
                <h4 className="font-black text-slate-900 leading-tight mb-4 group-hover:text-blue-600 transition-colors line-clamp-2">
                  {product.name}
                </h4>
                <div className="flex items-center justify-between pt-4 border-t border-slate-200/50">
                  <span className="text-xs font-bold text-slate-500">{product.brand}</span>
                  <Link 
                    to={`/analyze`} 
                    state={{ prefill: product.name }}
                    className="flex items-center gap-1 text-[10px] font-black text-blue-600 uppercase tracking-widest hover:gap-2 transition-all"
                  >
                    Details <ChevronRight size={14} />
                  </Link>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

const Registry: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const { data, error } = await supabase
          .from('products')
          .select('*')
          .order('name', { ascending: true });
        
        if (error) throw error;
        setProducts(data as Product[] || []);
      } catch (err) {
        console.error("Registry fetch error:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  const safeProducts = products.filter(p => p.toxicity_score <= 30);
  const moderateProducts = products.filter(p => p.toxicity_score > 30 && p.toxicity_score <= 60);
  const highRiskProducts = products.filter(p => p.toxicity_score > 60);

  return (
    <div className="max-w-[1600px] mx-auto px-4 py-12 overflow-hidden">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
        <div>
          <h1 className="text-5xl font-black text-slate-900 tracking-tighter mb-2">
            Forensic <span className="text-blue-600">Registry</span>
          </h1>
          <p className="text-slate-500 font-medium">Categorized archive of all audited chemical profiles.</p>
        </div>

        <div className="flex items-center gap-4 bg-white p-2 rounded-2xl shadow-sm border border-slate-100">
           <div className="bg-blue-600 p-2.5 rounded-xl text-white">
              <Database size={20} />
           </div>
           <div>
              <p className="text-[10px] font-black text-slate-400 uppercase leading-none mb-1">Database Sync</p>
              <p className="text-xs font-bold text-slate-900 uppercase">Live_Supabase_Cloud</p>
           </div>
        </div>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-40">
           <Loader2 className="animate-spin text-blue-600 mb-4" size={48} />
           <p className="text-sm font-black text-slate-400 uppercase tracking-widest">Accessing Persistence Layer...</p>
        </div>
      ) : (
        <div className="flex gap-8 overflow-x-auto pb-12 snap-x">
          <RegistryColumn 
            title="Low Risk / Safe" 
            products={safeProducts} 
            variant="safe" 
          />
          <RegistryColumn 
            title="Moderate Hazard" 
            products={moderateProducts} 
            variant="moderate" 
          />
          <RegistryColumn 
            title="High Risk / Toxic" 
            products={highRiskProducts} 
            variant="high" 
          />
        </div>
      )}

      {/* Footer Info */}
      <div className="mt-12 p-8 bg-slate-900 text-white rounded-[3rem] relative overflow-hidden">
         <div className="absolute right-0 bottom-0 translate-x-1/4 translate-y-1/4 opacity-5">
            <Search size={300} />
         </div>
         <div className="relative z-10 max-w-2xl">
            <h3 className="text-xl font-black mb-4">Chemical Intelligence Engine</h3>
            <p className="text-slate-400 text-sm leading-relaxed mb-6">
               This registry represents a growing database of analyzed consumer products. Every entry is independently audited using the Gemini 3.0 Pro Reasoning Engine and matched against global chemical safety standards.
            </p>
            <div className="flex gap-6 items-center">
               <div className="flex flex-col">
                  <span className="text-[10px] font-black text-blue-400 uppercase tracking-widest">Last Updated</span>
                  <span className="text-xs font-bold">Today, {new Date().toLocaleDateString()}</span>
               </div>
               <div className="h-8 w-px bg-white/10" />
               <div className="flex flex-col">
                  <span className="text-[10px] font-black text-blue-400 uppercase tracking-widest">Accuracy Level</span>
                  <span className="text-xs font-bold">99.2% Forensic Confidence</span>
               </div>
            </div>
         </div>
      </div>
    </div>
  );
};

export default Registry;
