import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  Search, Loader2, Beaker, CheckCircle, Dna, History, Landmark, 
  ShieldCheck, XCircle, AlertTriangle, Leaf, HeartPulse,
  Sparkles, ArrowRight, Globe, Camera, X,
  Heart, Plus, Share2, Check, Star, MessageSquare
} from 'lucide-react';
import { analyzeProductWithSearch } from '../services/gemini';
import { addNotification } from '@/lib/notifications';
import { supabase, supabaseAdmin } from '@/lib/supabase';
import { Html5Qrcode } from 'html5-qrcode';

// Synced with Glossary.tsx defaults
const DEFAULT_LISTS = [
  { id: '1', title: 'My Bathroom Shelf', items: [] },
  { id: '2', title: 'Dirty Products', items: [] },
  { id: '3', title: 'Clean Products', items: [] },
];

const Analyze: React.FC = () => {
  const [input, setInput] = useState(localStorage.getItem('last_search_input') || '');
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [step, setStep] = useState<string>('');
  const [result, setResult] = useState<any>(() => {
    const saved = localStorage.getItem('last_search_result');
    return saved ? JSON.parse(saved) : null;
  });
  const [error, setError] = useState<string | null>(null);
  const [user, setUser] = useState<any>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [isHistoryLoading, setIsHistoryLoading] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const fetchHistory = async (userId: string | null) => {
    setIsHistoryLoading(true);
    try {
      if (userId) {
        const { data, error } = await supabase
          .from('search_history')
          .select('*')
          .eq('user_id', userId)
          .order('created_at', { ascending: false })
          .limit(5);
        if (!error) setHistory(data || []);
      } else {
        const guestHistory = JSON.parse(localStorage.getItem('guest_search_history') || '[]');
        setHistory(guestHistory.slice(0, 5));
      }
    } catch (err) {
      console.warn("History fetch error:", err);
    } finally {
      setIsHistoryLoading(false);
    }
  };

  const deleteHistoryItem = async (id: string) => {
    try {
      if (id.startsWith('guest-')) {
        const guestHistory = JSON.parse(localStorage.getItem('guest_search_history') || '[]');
        const updated = guestHistory.filter((h: any) => h.id !== id);
        localStorage.setItem('guest_search_history', JSON.stringify(updated));
        setHistory(updated.slice(0, 5));
      } else {
        const { error } = await supabase.from('search_history').delete().eq('id', id);
        if (!error) {
          setHistory(prev => prev.filter(h => h.id !== id));
        }
      }
    } catch (err) {
      console.error("Delete history error:", err);
    }
  };

  // Persist search state
  useEffect(() => {
    if (result) {
      localStorage.setItem('last_search_result', JSON.stringify(result));
    } else {
      localStorage.removeItem('last_search_result');
    }
  }, [result]);

  useEffect(() => {
    localStorage.setItem('last_search_input', input);
  }, [input]);

  const clearSearch = () => {
    setResult(null);
    setInput('');
    localStorage.removeItem('last_search_result');
    localStorage.removeItem('last_search_input');
  };
  
  // Feature states
  const [isLiked, setIsLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(10);
  const [showListSelector, setShowListSelector] = useState(false);
  const [addedToListMessage, setAddedToListMessage] = useState<string | null>(null);
  const [reviews, setReviews] = useState<any[]>([]);
  const [newReview, setNewReview] = useState({ rating: 5, comment: '' });
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);
  const [showAuthPrompt, setShowAuthPrompt] = useState(false);
  const [authPromptAction, setAuthPromptAction] = useState('');

  // Scanner state
  const [showScanner, setShowScanner] = useState(false);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const scannerId = "barcode-scanner-viewport";
  const suggestionsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      setUser(user);
      fetchHistory(user?.id || null);
    }).catch(() => {
      fetchHistory(null);
    });
    
    if (location.state?.prefill) {
      const prefillTerm = location.state.prefill;
      setInput(prefillTerm);
      performSearch(prefillTerm);
    }

    const handleClickOutside = (event: MouseEvent) => {
      if (suggestionsRef.current && !suggestionsRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      if (scannerRef.current) {
        scannerRef.current.stop().catch(() => {});
      }
    };
  }, [location.state]);

  useEffect(() => {
    const fetchSuggestions = async () => {
      if (input.trim().length < 1) {
        setSuggestions([]);
        return;
      }

      try {
        const { data, error } = await supabaseAdmin
          .from('products')
          .select('name')
          .ilike('name', `%${input}%`)
          .order('name', { ascending: true })
          .limit(10);

        if (!error && data) {
          const names = (data as any[]).map(p => String(p.name));
          
          // Prioritize names that start with the input
          const sortedNames = names.sort((a, b) => {
            const aStarts = a.toLowerCase().startsWith(input.toLowerCase());
            const bStarts = b.toLowerCase().startsWith(input.toLowerCase());
            if (aStarts && !bStarts) return -1;
            if (!aStarts && bStarts) return 1;
            return a.localeCompare(b);
          });

          const uniqueNames = Array.from(new Set(sortedNames))
            .filter(name => name.toLowerCase().includes(input.toLowerCase()));
            
          setSuggestions(uniqueNames);
          setShowSuggestions(uniqueNames.length > 0);
        }
      } catch (err) {
        console.warn("Suggestion fetch error:", err);
      }
    };

    const timeoutId = setTimeout(fetchSuggestions, 300);
    return () => clearTimeout(timeoutId);
  }, [input]);

  useEffect(() => {
    if (result?.name) {
      const savedReviews = localStorage.getItem(`reviews_${result.name}`);
      if (savedReviews) {
        setReviews(JSON.parse(savedReviews));
      } else {
        // Default mock reviews if none exist
        setReviews([
          { id: '1', user: 'Sarah J.', rating: 5, comment: 'Finally a product I can trust for my baby!', date: '2 days ago' },
          { id: '2', user: 'Mike T.', rating: 4, comment: 'Great ingredients, but a bit expensive.', date: '1 week ago' }
        ]);
      }
    } else {
      setReviews([]);
    }
  }, [result?.name]);

  const startScanner = async () => {
    setShowScanner(true);
    setError(null);
    setResult(null);
    setShowSuggestions(false);

    setTimeout(async () => {
      try {
        const html5QrCode = new Html5Qrcode(scannerId);
        scannerRef.current = html5QrCode;
        
        const config = { fps: 10, qrbox: { width: 250, height: 150 } };
        
        await html5QrCode.start(
          { facingMode: "environment" }, 
          config,
          (decodedText) => {
            setInput(decodedText);
            stopScanner();
            performSearch(decodedText, true);
          },
          () => {}
        );
      } catch (err: any) {
        setError("Could not access camera. Please ensure permissions are granted.");
        setShowScanner(false);
      }
    }, 100);
  };

  const stopScanner = async () => {
    if (scannerRef.current) {
      try {
        await scannerRef.current.stop();
      } catch (err) {
        console.warn("Scanner stop error:", err);
      }
      scannerRef.current = null;
    }
    setShowScanner(false);
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    performSearch(input);
  };

  const performSearch = async (searchTerm: string, isScan: boolean = false) => {
    if (!searchTerm.trim()) return;

    setShowSuggestions(false);
    setIsLoading(true);
    setError(null);
    setResult(null);
    setIsLiked(false);
    setLikeCount(0);
    
    // Record search history early so it appears even if analysis fails
    let historyId: string | null = null;
    if (user) {
      try {
        const { data: historyData, error: historyError } = await supabase.from('search_history').insert({ 
          user_id: user.id, 
          search_term: searchTerm,
          is_scan: isScan
        }).select('id').single();
        
        if (historyError) {
          console.error("History recording error:", historyError);
        } else if (historyData) {
          historyId = historyData.id;
        }
      } catch (err) {
        console.warn("History recording exception:", err);
      }
    } else {
      // Guest history in localStorage
      const guestHistory = JSON.parse(localStorage.getItem('guest_search_history') || '[]');
      const newEntry = {
        id: `guest-${Date.now()}`,
        search_term: searchTerm,
        is_scan: isScan,
        created_at: new Date().toISOString()
      };
      localStorage.setItem('guest_search_history', JSON.stringify([newEntry, ...guestHistory].slice(0, 20)));
    }

    try {
      setStep('Consulting Registry...');
      let dbData = null;
      
      let { data: existingData, error: dbError } = await supabaseAdmin
        .from('products')
        .select('*')
        .ilike('name', searchTerm)
        .maybeSingle();
      
      if (!existingData && !dbError) {
        // Fallback to partial match if exact match fails
        const { data: partialData } = await supabaseAdmin
          .from('products')
          .select('*')
          .ilike('name', `%${searchTerm}%`)
          .limit(1)
          .maybeSingle();
        existingData = partialData;
      }
      
      if (dbError) console.warn("Initial DB check failed:", dbError);
      dbData = existingData;
      
      let finalName = '';
      
      const parseJsonArray = (data: any) => {
        if (Array.isArray(data)) return data;
        if (typeof data === 'string') {
          try {
            const parsed = JSON.parse(data);
            return Array.isArray(parsed) ? parsed : [];
          } catch (e) {
            return [];
          }
        }
        return [];
      };
      
      const parsedIngredients = dbData ? parseJsonArray(dbData.ingredients_json) : [];
      
      if (dbData && parsedIngredients.length > 0) {
        setStep('Record Found! Loading profile...');
        finalName = dbData.name;

        setResult({
          name: dbData.name,
          brand: dbData.brand || 'Unknown',
          manufacturer: dbData.manufacturer || 'Unknown',
          category: dbData.category || 'General',
          toxicity_score: dbData.toxicity_score || 0,
          safety_level: dbData.safety_level || 'Unknown',
          summary: dbData.summary || '',
          product_history: dbData.product_history || 'No historical data available.',
          usage_instructions: dbData.usage_instructions || '',
          database_description: dbData.database_description || 'No registry details available.',
          expert_rating: dbData.expert_rating || 0,
          expert_comment: dbData.expert_comment || '',
          lifestyle: {
            is_vegan: !!dbData.is_vegan,
            is_cruelty_free: !!dbData.is_cruelty_free,
            is_pregnancy_safe: !!dbData.is_pregnancy_safe,
            is_fragrance_free: !!dbData.is_fragrance_free
          },
          ingredients: parsedIngredients,
          alternatives: parseJsonArray(dbData.alternatives_json),
          health_insights: parseJsonArray(dbData.health_insights_json),
          score_breakdown: parseJsonArray(dbData.score_breakdown_json),
          sources: [] 
        });
      } else {
        setStep('Analyzing with AI engine...');
        const analysisResponse = await analyzeProductWithSearch(searchTerm);
        const { data, sources } = analysisResponse;
        
        // Normalize AI response to ensure all expected fields are arrays
        const normalizedData = {
          ...data,
          ingredients: parseJsonArray(data.ingredients),
          alternatives: parseJsonArray(data.alternatives),
          health_insights: parseJsonArray(data.health_insights),
          score_breakdown: parseJsonArray(data.score_breakdown),
          product_history: data.product_history || 'No historical data available.',
          database_description: data.database_description || 'No registry details available.',
          expert_rating: data.expert_rating || 0,
          expert_comment: data.expert_comment || '',
          lifestyle: data.lifestyle || {
            is_vegan: false,
            is_cruelty_free: false,
            is_pregnancy_safe: false,
            is_fragrance_free: false
          }
        };
        
        const finalResult = { ...normalizedData, sources };
        finalName = normalizedData.name;
        setResult(finalResult);
        
        // BACKGROUND ARCHIVING - Use supabaseAdmin to bypass RLS
        const archiveInBackground = async () => {
          try {
            console.log("Starting background archive for:", normalizedData.name);
            const payload = {
              name: normalizedData.name,
              brand: normalizedData.brand || 'Unknown',
              manufacturer: normalizedData.manufacturer || 'Unknown',
              category: normalizedData.category || 'General',
              toxicity_score: normalizedData.toxicity_score || 0,
              safety_level: normalizedData.safety_level || 'Unknown',
              summary: normalizedData.summary || '',
              product_history: normalizedData.product_history || 'Registry Archive',
              usage_instructions: normalizedData.usage_instructions || 'Follow package directions.',
              database_description: normalizedData.database_description || 'Auto-generated audit.',
              expert_rating: normalizedData.expert_rating || 0,
              expert_comment: normalizedData.expert_comment || '',
              is_vegan: !!normalizedData.lifestyle?.is_vegan,
              is_cruelty_free: !!normalizedData.lifestyle?.is_cruelty_free,
              is_pregnancy_safe: !!normalizedData.lifestyle?.is_pregnancy_safe,
              is_fragrance_free: !!normalizedData.lifestyle?.is_fragrance_free,
              ingredients_json: JSON.stringify(normalizedData.ingredients || []),
              alternatives_json: JSON.stringify(normalizedData.alternatives || []),
              health_insights_json: JSON.stringify(normalizedData.health_insights || []),
              score_breakdown_json: JSON.stringify(normalizedData.score_breakdown || [])
            };

            let { error: archiveError } = await supabaseAdmin.from('products').upsert(payload, { onConflict: 'name' });

            // Resilient Save: Retry without expert columns if they don't exist in DB
            if (archiveError?.code === 'PGRST204') {
              console.warn("Schema mismatch. Retrying without expert columns...");
              const { expert_rating, expert_comment, ...safePayload } = payload;
              const { error: retryError } = await supabaseAdmin.from('products').upsert(safePayload, { onConflict: 'name' });
              archiveError = retryError;
            }

            if (archiveError) {
              console.error("CRITICAL DB ERROR:", archiveError);
            } else {
              console.log("Successfully stored product in database.");
              addNotification(
                'New Product Added',
                `${normalizedData.name} has been successfully added to the forensic registry.`,
                'success'
              );
            }
          } catch (syncErr) {
            console.error("Background sync fatal error:", syncErr);
          }
        };
        
        archiveInBackground();
      }

      // Update search history with the actual product name found
      if (user && historyId) {
        await supabaseAdmin.from('search_history').update({ 
          search_term: finalName 
        }).eq('id', historyId);
        fetchHistory(user.id);
      } else if (!user) {
        const guestHistory = JSON.parse(localStorage.getItem('guest_search_history') || '[]');
        if (guestHistory.length > 0) {
          guestHistory[0].search_term = finalName;
          localStorage.setItem('guest_search_history', JSON.stringify(guestHistory));
          setHistory(guestHistory.slice(0, 5));
        }
      }

      // Check if liked
      if (user) {
        const { data: likeData } = await supabaseAdmin
          .from('product_likes')
          .select('*')
          .eq('user_id', user.id)
          .eq('product_name', finalName)
          .maybeSingle();
        
        if (likeData) setIsLiked(true);
      } else {
        const guestLikes = JSON.parse(localStorage.getItem('guest_likes') || '[]');
        if (guestLikes.includes(finalName)) setIsLiked(true);
      }

      // Get global like count (Always fetch, even if not logged in)
      const { count } = await supabaseAdmin
        .from('product_likes')
        .select('*', { count: 'exact', head: true })
        .eq('product_name', finalName);
      
      if (count !== null) setLikeCount(count);
    } catch (err: any) {
      console.error("Critical Search Failure:", err);
      
      let errorMessage = err.message || "An unexpected error occurred during analysis.";
      if (errorMessage === "Failed to fetch" || errorMessage.includes("fetch")) {
        errorMessage = "Network error: Failed to connect to the database or AI service. This could be due to an adblocker, VPN, or your Supabase project being paused. Please check your connection and try again.";
      }
      
      setError(errorMessage);
    } finally {
      setIsLoading(false);
      setStep('');
    }
  };

  const handleLike = async () => {
    if (!result) return;
    
    if (!user) {
      setAuthPromptAction('like products');
      setShowAuthPrompt(true);
      return;
    }

    const newLikedState = !isLiked;
    setIsLiked(newLikedState);
    setLikeCount(prev => newLikedState ? prev + 1 : prev - 1);

    try {
      if (newLikedState) {
        await supabaseAdmin.from('product_likes').insert({
          user_id: user.id,
          product_name: result.name
        });
      } else {
        await supabaseAdmin.from('product_likes').delete().match({
          user_id: user.id,
          product_name: result.name
        });
      }
    } catch (err) {
      console.error("Like persistence error:", err);
    }
  };

  const handleAddToList = async (listId: string, listTitle: string) => {
    if (!result) return;

    if (!user) {
      setAuthPromptAction('add products to lists');
      setShowAuthPrompt(true);
      return;
    }

    // Legacy localStorage support (for both guest and user)
    const savedLists = localStorage.getItem('product_lists');
    const columns = savedLists ? JSON.parse(savedLists) : DEFAULT_LISTS;
    
    const updatedColumns = columns.map((col: any) => {
      if (col.id === listId) {
        if (!col.items.includes(result.name)) {
          return { ...col, items: [...col.items, result.name] };
        }
      }
      return col;
    });
    
    localStorage.setItem('product_lists', JSON.stringify(updatedColumns));

    // Persistence
    try {
      await supabaseAdmin.from('watchlist').insert({
        user_id: user.id,
        product_name: result.name,
        list_id: listId,
        list_title: listTitle
      });
    } catch (err) {
      console.error("Watchlist persistence error:", err);
    }

    setAddedToListMessage(`Added to ${listTitle}`);
    setShowListSelector(false);
    setTimeout(() => setAddedToListMessage(null), 3000);
  };

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReview.comment.trim() || !result?.name) return;

    if (!user) {
      setAuthPromptAction('post reviews');
      setShowAuthPrompt(true);
      return;
    }
    
    setIsSubmittingReview(true);
    
    try {
      // Supabase persistence
      await supabaseAdmin.from('reviews').insert({
        user_id: user.id,
        product_name: result.name,
        rating: newReview.rating,
        comment: newReview.comment
      });

      // Legacy localStorage support
      const review = {
        id: Date.now().toString(),
        user: user?.email?.split('@')[0] || 'Anonymous User',
        rating: newReview.rating,
        comment: newReview.comment,
        date: 'Just now'
      };
      
      const updatedReviews = [review, ...reviews];
      setReviews(updatedReviews);
      localStorage.setItem(`reviews_${result.name}`, JSON.stringify(updatedReviews));
      
      setNewReview({ rating: 5, comment: '' });
      
      addNotification(
        'Review Submitted',
        'Your feedback has been added to the community database.',
        'success'
      );
    } catch (err) {
      console.error("Review persistence error:", err);
    } finally {
      setIsSubmittingReview(false);
    }
  };

  const getScoreColor = (score: number) => {
    if (score < 30) return 'text-emerald-600 bg-emerald-50 border-emerald-100 dark:bg-emerald-900/10 dark:border-emerald-900/30 dark:text-emerald-400';
    if (score < 60) return 'text-amber-600 bg-amber-50 border-amber-100 dark:bg-amber-900/10 dark:border-amber-900/30 dark:text-amber-400';
    return 'text-rose-600 bg-rose-50 border-rose-100 dark:bg-rose-900/10 dark:border-rose-900/30 dark:text-rose-400';
  };

  const getLists = () => {
    const saved = localStorage.getItem('product_lists');
    return saved ? JSON.parse(saved) : DEFAULT_LISTS;
  };

  const averageRating = reviews.length > 0 
    ? (reviews.reduce((acc, r) => acc + r.rating, 0) / reviews.length).toFixed(1) 
    : '0.0';

  return (
    <div className="max-w-6xl mx-auto px-4 py-12 font-['Inter']">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-6xl font-black text-slate-900 dark:text-white tracking-tighter mb-4">
          Product <span className="text-blue-600">Search</span>
        </h1>
        <p className="text-slate-500 dark:text-slate-400 max-w-xl mx-auto font-medium">
          Start searching by typing product or brand name e.g. Dove
        </p>
      </div>

      <div className="max-w-3xl mx-auto mb-16 relative">
        <form onSubmit={handleSearch} className="relative group">
          <div className="absolute inset-y-0 left-8 flex items-center pointer-events-none text-slate-400 group-focus-within:text-blue-600 transition-colors">
            <Search size={32} />
          </div>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Search by name, Brand, or manufacturer"
            className="w-full pl-20 pr-40 py-8 bg-white dark:bg-slate-900 rounded-[3rem] border-2 border-slate-100 dark:border-slate-800 focus:border-blue-500 outline-none text-2xl font-black shadow-2xl transition-all placeholder:text-slate-300 dark:placeholder:text-slate-600"
          />
          <div className="absolute inset-y-3 right-3 flex items-center gap-3">
            {input && (
              <button
                type="button"
                onClick={clearSearch}
                className="p-5 text-slate-400 hover:text-rose-500 transition-colors"
                title="Clear Search"
              >
                <X size={28} />
              </button>
            )}
            <button
              type="button"
              onClick={startScanner}
              className="p-5 bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 transition-all"
            >
              <Camera size={28} />
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="px-10 py-5 bg-blue-600 text-white rounded-full font-black text-sm uppercase tracking-widest hover:bg-blue-700 transition-all disabled:opacity-50 shadow-lg shadow-blue-200 dark:shadow-none"
            >
              SEARCH NOW
            </button>
          </div>
        </form>

        {showSuggestions && suggestions.length > 0 && (
          <div ref={suggestionsRef} className="absolute top-full left-0 right-0 mt-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-2xl overflow-hidden z-50">
            {suggestions.map((s, i) => (
              <button
                key={i}
                onClick={() => {
                  setInput(s);
                  setShowSuggestions(false);
                  performSearch(s);
                }}
                className="w-full text-left px-8 py-4 hover:bg-slate-50 dark:hover:bg-slate-800 font-bold text-slate-700 dark:text-slate-300 transition-colors flex items-center gap-3"
              >
                <Search size={16} className="text-slate-300" /> {s}
              </button>
            ))}
          </div>
        )}

        {/* Product History Section */}
        {!showSuggestions && history.length > 0 && !isLoading && !result && (
          <div className="mt-8 animate-in fade-in slide-in-from-top-4 duration-500">
            <div className="flex items-center justify-between mb-4 px-4">
              <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Product History</h3>
              <Link to="/watchlist" className="text-[10px] font-black uppercase tracking-widest text-blue-600 hover:underline">View Product History</Link>
            </div>
            <div className="flex flex-wrap gap-3">
              {history.map((item) => (
                <div 
                  key={item.id} 
                  className="group flex items-center gap-2 pl-5 pr-3 py-2.5 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl shadow-sm hover:border-blue-200 dark:hover:border-blue-900 transition-all"
                >
                  <button 
                    onClick={() => {
                      setInput(item.search_term);
                      performSearch(item.search_term);
                    }}
                    className="flex items-center gap-2 text-sm font-bold text-slate-600 dark:text-slate-400 hover:text-blue-600 transition-colors"
                  >
                    <History size={14} className="text-slate-300" />
                    {item.search_term}
                  </button>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteHistoryItem(item.id);
                    }}
                    className="p-1 text-slate-300 hover:text-rose-500 transition-colors opacity-0 group-hover:opacity-100"
                    title="Remove from history"
                  >
                    <X size={14} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {showScanner && (
        <div className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center">
          <button onClick={stopScanner} className="absolute top-8 right-8 text-white p-4 hover:bg-white/10 rounded-full">
            <X size={32} />
          </button>
          <div id={scannerId} className="w-full max-w-lg aspect-square overflow-hidden rounded-3xl border-4 border-blue-500" />
          <p className="mt-8 text-white font-black uppercase tracking-widest text-sm">Position barcode within the frame</p>
        </div>
      )}

      {isLoading && (
        <div className="flex flex-col items-center justify-center py-20 animate-in fade-in zoom-in duration-500">
          <div className="relative mb-8">
            <Loader2 className="animate-spin text-blue-600" size={80} />
            <Sparkles className="absolute inset-0 m-auto text-blue-400 animate-pulse" size={32} />
          </div>
          <p className="text-xl font-black text-slate-900 dark:text-white uppercase tracking-[0.2em]">{step}</p>
          <p className="mt-2 text-slate-500 dark:text-slate-400 font-medium italic">Connecting to databases...</p>
        </div>
      )}

      {error && (
        <div className="max-w-2xl mx-auto p-12 bg-rose-50 dark:bg-rose-900/10 rounded-[3rem] border border-rose-100 dark:border-rose-900/30 text-center animate-in slide-in-from-bottom-4">
          <XCircle className="mx-auto text-rose-500 mb-6" size={64} />
          <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-4">Analysis Failed</h2>
          <p className="text-rose-600 font-bold mb-8">{error}</p>
          <div className="flex flex-wrap justify-center gap-4">
            <button onClick={() => setError(null)} className="px-10 py-4 bg-slate-900 dark:bg-white dark:text-slate-900 text-white rounded-full font-black text-sm uppercase tracking-widest">Dismiss</button>
            {error.toLowerCase().includes('api key') && typeof window !== 'undefined' && (window as any).aistudio && (
              <button 
                onClick={async () => {
                  try {
                    await (window as any).aistudio.openSelectKey();
                    setError(null);
                    if (input) performSearch(input);
                  } catch (err) {
                    console.error("Failed to open key selector:", err);
                  }
                }} 
                className="px-10 py-4 bg-blue-600 text-white rounded-full font-black text-sm uppercase tracking-widest hover:bg-blue-700 transition-all"
              >
                Select API Key
              </button>
            )}
          </div>
        </div>
      )}

      {result && (
        <div className="space-y-16 animate-in fade-in slide-in-from-bottom-8 duration-700">
          {/* Header Card */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 bg-white dark:bg-slate-900 p-10 rounded-[3.5rem] border border-slate-100 dark:border-slate-800 shadow-xl relative">
              <div className="absolute top-0 right-0 p-12 opacity-[0.03] dark:opacity-[0.15]">
                <ShieldCheck size={300} />
              </div>
              <div className="flex flex-wrap items-center gap-4 mb-6">
                <span className="px-4 py-1.5 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-full text-[10px] font-black uppercase tracking-widest">{result.category}</span>
                <span className="px-4 py-1.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-full text-[10px] font-black uppercase tracking-widest">{result.brand}</span>
              </div>
              <h2 className="text-4xl md:text-5xl font-black text-slate-900 dark:text-white mb-6 leading-tight">{result.name}</h2>
              
              <p className="text-lg text-slate-500 dark:text-slate-400 leading-relaxed max-w-2xl mb-4">{result.summary}</p>
              
              {result.expert_comment && (
                <div className="bg-blue-50 dark:bg-blue-900/20 p-6 rounded-3xl border border-blue-100 dark:border-blue-900/30 mb-8">
                  <div className="flex items-center gap-2 mb-2">
                    <MessageSquare size={16} className="text-blue-600" />
                    <span className="text-[10px] font-black uppercase tracking-widest text-blue-600">Expert Verdict</span>
                  </div>
                  <p className="text-sm font-bold text-slate-700 dark:text-slate-200 italic">"{result.expert_comment}"</p>
                </div>
              )}
              
              <div className="flex flex-wrap gap-4 mb-10">
                {Object.entries(result.lifestyle).map(([key, value]) => (
                  value && (
                    <div key={key} className="flex items-center gap-2 px-4 py-2 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 rounded-2xl border border-emerald-100 dark:border-emerald-900/30 font-bold text-sm">
                      <Leaf size={16} /> {key.replace('is_', '').replace('_', ' ').toUpperCase()}
                    </div>
                  )
                ))}
              </div>

              <div className="flex flex-col gap-4 relative">
                {result.expert_rating > 0 && (
                  <div className="flex gap-1 mb-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star 
                        key={star} 
                        size={18} 
                        fill={star <= result.expert_rating ? "#F59E0B" : "none"} 
                        className={star <= result.expert_rating ? "text-amber-500" : "text-slate-300"} 
                      />
                    ))}
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2 self-center">Expert Rating</span>
                  </div>
                )}
                <div className="flex items-center gap-8 py-2">
                  <button 
                    onClick={handleLike}
                    className={`flex items-center gap-2.5 transition-all active:scale-90 ${isLiked ? 'text-rose-500' : 'text-slate-400 dark:text-slate-500'}`}
                  >
                    <Heart size={28} fill={isLiked ? "currentColor" : "none"} />
                    <span className="text-lg font-bold">{likeCount}</span>
                  </button>

                  <div className="relative">
                    <button 
                      onClick={() => setShowListSelector(!showListSelector)}
                      className="flex items-center gap-2.5 text-slate-400 dark:text-slate-500 hover:text-blue-600 transition-all active:scale-90"
                    >
                      <Plus size={28} className={showListSelector ? 'rotate-45 transition-transform' : 'transition-transform'} />
                      <span className="text-lg font-bold">1</span>
                    </button>

                    {showListSelector && (
                      <div className="absolute top-full left-0 mt-4 bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 rounded-3xl shadow-2xl z-[60] w-64 p-4 animate-in slide-in-from-top-2">
                        <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-4 px-2">Select a List</h4>
                        <div className="space-y-1">
                          {getLists().length > 0 ? getLists().map((list: any) => (
                            <button 
                              key={list.id} 
                              onClick={() => handleAddToList(list.id, list.title)}
                              className="w-full text-left p-3 hover:bg-slate-50 dark:hover:bg-slate-700 rounded-xl font-bold text-sm transition-colors text-slate-700 dark:text-slate-200"
                            >
                              {list.title}
                            </button>
                          )) : (
                            <Link to="/glossary" className="block p-3 text-blue-600 font-bold text-sm underline">Create a list first</Link>
                          )}
                        </div>
                      </div>
                    )}
                  </div>

                  <button className="flex items-center gap-2.5 text-slate-400 dark:text-slate-500 hover:text-blue-600 transition-all active:scale-90">
                    <Share2 size={28} />
                    <span className="text-lg font-bold">Share</span>
                  </button>
                </div>

                {addedToListMessage && (
                  <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-slate-900 text-white px-6 py-2 rounded-full text-xs font-black uppercase tracking-widest flex items-center gap-2 animate-in slide-in-from-bottom-2 fade-in">
                    <Check size={14} className="text-emerald-500" /> {addedToListMessage}
                  </div>
                )}
              </div>
            </div>

            <div className={`p-10 rounded-[3.5rem] border flex flex-col items-center justify-center text-center shadow-xl ${getScoreColor(result.toxicity_score)}`}>
              <span className="text-[10px] font-black uppercase tracking-[0.3em] mb-4 opacity-70">Forensic Safety Score</span>
              <div className="text-8xl font-black mb-4 tracking-tighter">{result.toxicity_score}</div>
              <div className="px-6 py-2 rounded-full bg-white/20 backdrop-blur-md font-black uppercase tracking-widest text-sm mb-4">
                {result.safety_level} Risk
              </div>
              <p className="text-xs font-bold opacity-70 max-w-[150px]">0 = Pure, 100 = Hazardous</p>
            </div>
          </div>

          <div className="space-y-16">
            <div className="space-y-8">
              <h3 className="text-2xl font-black flex items-center gap-4">
                <Beaker className="text-blue-600" /> Chemical Ingredients
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {result.ingredients && result.ingredients.length > 0 ? result.ingredients.map((ing: any, i: number) => {
                  const isString = typeof ing === 'string';
                  const name = isString ? ing : (ing.name || 'Unknown Ingredient');
                  const purpose = isString ? 'General ingredient' : (ing.purpose || 'General ingredient');
                  const toxicityLevel = isString ? 'Unknown' : (ing.toxicity_level || 'Unknown');
                  const riskFlags = isString ? null : ing.risk_flags;
                  
                  return (
                    <div key={i} className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 group hover:border-blue-200 transition-all">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-black text-slate-900 dark:text-white">{name}</h4>
                        <span className={`text-[10px] font-black px-3 py-1 rounded-full uppercase ${
                          toxicityLevel === 'Low' ? 'bg-emerald-100 text-emerald-600' : 
                          toxicityLevel === 'Moderate' ? 'bg-amber-100 text-amber-600' : 
                          toxicityLevel === 'High' ? 'bg-rose-100 text-rose-600' :
                          'bg-slate-100 text-slate-600'
                        }`}>{toxicityLevel}</span>
                      </div>
                      <p className="text-sm text-slate-500 dark:text-slate-400 font-medium mb-3">{purpose}</p>
                      {riskFlags && (
                        <div className="flex items-center gap-2 text-rose-500 text-[10px] font-black uppercase tracking-widest">
                          <AlertTriangle size={12} /> {riskFlags}
                        </div>
                      )}
                    </div>
                  );
                }) : (
                  <div className="col-span-full p-6 rounded-3xl border bg-slate-50 border-slate-100 dark:bg-slate-900/10 dark:border-slate-800 text-slate-500">
                    <p className="font-bold leading-relaxed">No ingredient information available for this product.</p>
                  </div>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 pt-8 border-t border-slate-100 dark:border-slate-800">
              <div className="space-y-8">
                <h3 className="text-2xl font-black flex items-center gap-4">
                  <HeartPulse className="text-rose-500" /> Health Insights
                </h3>
                <div className="space-y-4">
                  {result.health_insights && result.health_insights.length > 0 ? result.health_insights.map((insight: any, i: number) => {
                    const isString = typeof insight === 'string';
                    const text = isString ? insight : (insight.description || insight.text || insight.title || 'Unknown insight');
                    const severity = isString ? 'warning' : (insight.severity || insight.type || 'warning');
                    const isError = severity.toLowerCase() === 'high' || severity === 'error';
                    const isWarning = severity.toLowerCase() === 'moderate' || severity === 'warning';
                    
                    return (
                      <div key={i} className={`p-6 rounded-3xl border flex gap-4 ${
                        isError ? 'bg-rose-50 border-rose-100 dark:bg-rose-900/10 dark:border-rose-900/30 text-rose-600' :
                        isWarning ? 'bg-amber-50 border-amber-100 dark:bg-amber-900/10 dark:border-amber-900/30 text-amber-600' :
                        'bg-emerald-50 border-emerald-100 dark:bg-emerald-900/10 dark:border-emerald-900/30 text-emerald-600'
                      }`}>
                        {isError ? <XCircle size={24} /> : 
                         isWarning ? <AlertTriangle size={24} /> : <CheckCircle size={24} />}
                        <p className="font-bold leading-relaxed">{text}</p>
                      </div>
                    );
                  }) : (
                    <div className="p-6 rounded-3xl border bg-slate-50 border-slate-100 dark:bg-slate-900/10 dark:border-slate-800 text-slate-500">
                      <p className="font-bold leading-relaxed">No specific health insights available for this product.</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="space-y-8">
                <h3 className="text-2xl font-black flex items-center gap-4">
                  <Sparkles className="text-amber-500" /> Cleaner Alternatives
                </h3>
                <div className="space-y-4">
                  {result.alternatives && result.alternatives.length > 0 ? result.alternatives.map((alt: any, i: number) => {
                    const isString = typeof alt === 'string';
                    const name = isString ? alt : (alt.name || 'Unknown Alternative');
                    const reason = isString ? 'Cleaner option' : (alt.reason || alt.description || 'Cleaner alternative');
                    
                    return (
                      <button 
                        key={i} 
                        onClick={() => {
                          setInput(name);
                          performSearch(name);
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }}
                        className="w-full text-left p-6 bg-slate-900 text-white rounded-3xl border border-white/5 relative overflow-hidden group hover:bg-slate-800 transition-all active:scale-[0.98]"
                      >
                        <div className="relative z-10 flex justify-between items-center">
                          <div>
                            <h4 className="font-black text-xl mb-1">{name}</h4>
                            <p className="text-slate-400 text-sm font-medium">{reason}</p>
                          </div>
                          <ArrowRight className="text-blue-400 group-hover:translate-x-2 transition-transform" />
                        </div>
                      </button>
                    );
                  }) : (
                    <div className="p-6 rounded-3xl border bg-slate-50 border-slate-100 dark:bg-slate-900/10 dark:border-slate-800 text-slate-500">
                      <p className="font-bold leading-relaxed">No specific alternatives found.</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {result.sources && result.sources.length > 0 && (
            <div className="pt-12 border-t border-slate-100 dark:border-slate-800">
               <h3 className="text-xl font-black mb-6 flex items-center gap-2">
                 <Globe size={20} className="text-blue-500" /> Verification Sources
               </h3>
               <div className="flex flex-wrap gap-4">
                 {result.sources.map((chunk: any, i: number) => (
                   chunk.web && (
                     <a 
                       key={i} 
                       href={chunk.web.uri} 
                       target="_blank" 
                       rel="noopener noreferrer"
                       className="px-6 py-3 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl text-xs font-bold text-slate-500 hover:text-blue-600 hover:border-blue-200 transition-all shadow-sm"
                     >
                       {chunk.web.title || 'Source Reference'}
                     </a>
                   )
                 ))}
               </div>
            </div>
          )}

          <div className="p-10 bg-slate-50 dark:bg-slate-900/30 rounded-[3.5rem] border border-slate-100 dark:border-slate-800 mb-16">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-10">
              <div>
                <h3 className="text-2xl font-black flex items-center gap-3 mb-2">
                  <Star className="text-amber-500" fill="#F59E0B" /> Community Reviews
                </h3>
                <p className="text-slate-500 font-medium">Real feedback from verified users.</p>
              </div>
              
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <div className="text-2xl font-black text-slate-900 dark:text-white">{averageRating} / 5</div>
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Average Rating</div>
                </div>
                <div className="h-10 w-px bg-slate-200 dark:bg-slate-800" />
                <div className="text-right">
                  <div className="text-2xl font-black text-slate-900 dark:text-white">{reviews.length}</div>
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Total Reviews</div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
              <div className="lg:col-span-2 space-y-6">
                {reviews.length > 0 ? reviews.map((review) => (
                  <div key={review.id} className="p-8 bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm">
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center text-blue-600 font-black text-sm">
                          {review.user.charAt(0)}
                        </div>
                        <div>
                          <h4 className="font-bold text-slate-900 dark:text-white">{review.user}</h4>
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{review.date}</p>
                        </div>
                      </div>
                      <div className="flex gap-0.5">
                        {[1, 2, 3, 4, 5].map((s) => (
                          <Star key={s} size={12} fill={s <= review.rating ? "#F59E0B" : "none"} className={s <= review.rating ? "text-amber-500" : "text-slate-200"} />
                        ))}
                      </div>
                    </div>
                    <p className="text-slate-600 dark:text-slate-400 font-medium leading-relaxed">{review.comment}</p>
                  </div>
                )) : (
                  <div className="py-20 text-center bg-white dark:bg-slate-900 rounded-3xl border border-dashed border-slate-200 dark:border-slate-800">
                    <MessageSquare className="mx-auto text-slate-200 mb-4" size={48} />
                    <p className="text-slate-400 font-bold">No reviews yet. Be the first to share your thoughts!</p>
                  </div>
                )}
              </div>

              <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm h-fit sticky top-24">
                <h4 className="font-black text-slate-900 dark:text-white mb-6 uppercase tracking-widest text-xs">Write a Review</h4>
                <form onSubmit={handleSubmitReview} className="space-y-6">
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Your Rating</label>
                    <div className="flex gap-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setNewReview({ ...newReview, rating: star })}
                          className="transition-transform active:scale-90"
                        >
                          <Star 
                            size={28} 
                            fill={star <= newReview.rating ? "#F59E0B" : "none"} 
                            className={star <= newReview.rating ? "text-amber-500" : "text-slate-200"} 
                          />
                        </button>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Your Comment</label>
                    <textarea
                      value={newReview.comment}
                      onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
                      placeholder="Share your experience with this product..."
                      className="w-full p-4 bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 rounded-2xl text-sm font-medium focus:ring-2 focus:ring-blue-500 outline-none transition-all min-h-[120px]"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmittingReview}
                    className="w-full py-4 bg-blue-600 text-white rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-blue-700 transition-all active:scale-[0.98] disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isSubmittingReview ? (
                      <Loader2 className="animate-spin" size={18} />
                    ) : (
                      <>Post Review <ArrowRight size={18} /></>
                    )}
                  </button>
                </form>
              </div>
            </div>
          </div>

          <div className="p-10 bg-slate-50 dark:bg-slate-900/30 rounded-[3.5rem] border border-slate-100 dark:border-slate-800">
            <h3 className="text-xl font-black mb-6 flex items-center gap-3">
              <Landmark className="text-slate-400" /> Database Record
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Product History</p>
                <p className="text-sm font-medium leading-relaxed text-slate-600 dark:text-slate-400">{result.product_history}</p>
              </div>
              <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Registry Details</p>
                <p className="text-xs font-mono text-slate-400 leading-relaxed bg-white dark:bg-slate-900 p-4 rounded-2xl">{result.database_description}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {!isLoading && !result && (
        <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { icon: <Dna className="text-blue-600" />, title: "Chemical Registry", text: "Verified against 40+ global toxicity databases." },
            { icon: <ShieldCheck className="text-emerald-500" />, title: "Health First", text: "Prioritizing endocrine and respiratory safety." },
            { icon: <Landmark className="text-amber-500" />, title: "Transparent Data", text: "Citing primary sources for every audit." }
          ].map((item, i) => (
            <div key={i} className="p-8 bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-50 dark:border-slate-800 shadow-sm text-center">
              <div className="mb-4 flex justify-center">{item.icon}</div>
              <h4 className="font-black text-slate-900 dark:text-white mb-2 uppercase tracking-widest text-xs">{item.title}</h4>
              <p className="text-slate-500 dark:text-slate-400 text-xs font-medium">{item.text}</p>
            </div>
          ))}
        </div>
      )}
      {/* Auth Prompt Modal */}
      {showAuthPrompt && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 rounded-[3rem] p-10 w-full max-w-md shadow-2xl animate-in zoom-in-95 duration-200 border border-slate-200 dark:border-slate-800 text-center">
            <div className="bg-blue-600 w-16 h-16 rounded-2xl flex items-center justify-center text-white mx-auto mb-6 shadow-lg shadow-blue-200 dark:shadow-blue-900/40">
              <ShieldCheck size={32} />
            </div>
            <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-2">Sign Up Required</h3>
            <p className="text-slate-500 dark:text-slate-400 text-sm mb-8">
              Please sign up or sign in to {authPromptAction}. Join our community to track your product safety journey.
            </p>
            
            <div className="flex flex-col gap-4">
              <button 
                onClick={() => navigate('/signup')}
                className="w-full py-4 bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-blue-700 transition-colors shadow-lg shadow-blue-200 dark:shadow-blue-900/20"
              >
                Create Account
              </button>
              <button 
                onClick={() => setShowAuthPrompt(false)}
                className="w-full py-4 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
              >
                Maybe Later
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Analyze;