import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ChevronLeft, 
  Sparkles, 
  ArrowRight, 
  Check, 
  Brain, 
  Zap, 
  Heart, 
  Shield,
  AlertCircle, 
  Clock, 
  Droplets, 
  Leaf, 
  Wind,
  Loader2
} from 'lucide-react';
import { supabase } from '../lib/supabase';

interface QuizStep {
  id: string;
  question: string;
  options: { id: string; label: string; icon: React.ReactNode }[];
}

const QUIZ_STEPS: QuizStep[] = [
  {
    id: 'skin_type',
    question: 'What is your primary skin type?',
    options: [
      { id: 'dry', label: 'Dry', icon: <Heart size={20} /> },
      { id: 'oily', label: 'Oily', icon: <Zap size={20} /> },
      { id: 'combination', label: 'Combination', icon: <Sparkles size={20} /> },
      { id: 'sensitive', label: 'Sensitive', icon: <Shield size={20} /> },
    ]
  },
  {
    id: 'hair_type',
    question: 'What is your hair texture?',
    options: [
      { id: 'straight', label: 'Straight', icon: <div className="w-5 h-0.5 bg-current rounded-full" /> },
      { id: 'wavy', label: 'Wavy', icon: <div className="w-5 h-2 border-b-2 border-current rounded-full" /> },
      { id: 'curly', label: 'Curly', icon: <div className="w-5 h-5 border-2 border-current rounded-full" /> },
      { id: 'coily', label: 'Coily', icon: <div className="w-5 h-5 border-4 border-current rounded-full" /> },
    ]
  },
  {
    id: 'concern',
    question: 'What is your main concern?',
    options: [
      { id: 'acne', label: 'Acne & Blemishes', icon: <AlertCircle size={20} /> },
      { id: 'aging', label: 'Aging & Wrinkles', icon: <Clock size={20} /> },
      { id: 'dryness', label: 'Dryness & Flaking', icon: <Droplets size={20} /> },
      { id: 'sensitivity', label: 'Redness & Irritation', icon: <Shield size={20} /> },
    ]
  },
  {
    id: 'preference',
    question: 'Any product preferences?',
    options: [
      { id: 'vegan', label: 'Vegan Only', icon: <Leaf size={20} /> },
      { id: 'cruelty_free', label: 'Cruelty Free', icon: <Heart size={20} /> },
      { id: 'fragrance_free', label: 'Fragrance Free', icon: <Wind size={20} /> },
      { id: 'all', label: 'No Preference', icon: <Sparkles size={20} /> },
    ]
  }
];

const Quiz: React.FC = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);

  const handleSelect = (optionId: string) => {
    const stepId = QUIZ_STEPS[currentStep].id;
    setAnswers(prev => ({ ...prev, [stepId]: optionId }));
    
    if (currentStep < QUIZ_STEPS.length - 1) {
      setTimeout(() => setCurrentStep(prev => prev + 1), 300);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    } else {
      navigate(-1);
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const user = session?.user;
      if (user) {
        const { error } = await supabase
          .from('profiles')
          .update({
            skin_type: answers.skin_type,
            hair_type: answers.hair_type,
            main_concern: answers.concern,
            preferences: answers.preference,
            updated_at: new Date().toISOString(),
          })
          .eq('id', user.id);
        
        if (error) throw error;
      }
      
      // Also save to local storage for persistence
      localStorage.setItem('user_traits', JSON.stringify(answers));
      setIsCompleted(true);
    } catch (err) {
      console.error("Failed to save quiz results:", err);
      // Still show completed state even if DB save fails
      setIsCompleted(true);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isCompleted) {
    return (
      <div className="min-h-screen bg-white text-slate-900 flex flex-col items-center px-6 pt-12 animate-in fade-in duration-500">
        <div className="w-full max-w-md flex flex-col h-full min-h-[85vh] text-center">
          <div className="mb-12 flex justify-center">
            <div className="w-24 h-24 bg-emerald-100 text-emerald-600 rounded-[2.5rem] flex items-center justify-center shadow-xl shadow-emerald-50">
              <Check size={48} strokeWidth={3} />
            </div>
          </div>
          
          <h2 className="text-4xl font-black tracking-tighter mb-6 leading-none">
            Profile <span className="text-blue-600">Updated</span>
          </h2>
          
          <p className="text-slate-500 text-lg font-medium mb-12 leading-relaxed">
            Your beauty traits have been analyzed. We'll now prioritize products that match your profile in search results.
          </p>

          <div className="space-y-4 mb-12">
            {Object.entries(answers).map(([key, value]) => (
              <div key={key} className="flex items-center justify-between p-5 bg-slate-50 rounded-2xl border border-slate-100">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                  {key.replace('_', ' ')}
                </span>
                <span className="font-black text-slate-900 uppercase text-sm tracking-tight">
                  {value}
                </span>
              </div>
            ))}
          </div>

          <button 
            onClick={() => navigate('/profile')}
            className="w-full py-5 bg-slate-900 text-white rounded-2xl font-black text-xl uppercase tracking-widest hover:bg-slate-800 transition-all shadow-xl shadow-slate-200"
          >
            Go to Profile
          </button>
        </div>
      </div>
    );
  }

  const step = QUIZ_STEPS[currentStep];
  const progress = ((currentStep + 1) / QUIZ_STEPS.length) * 100;

  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col items-center px-6 pt-12 transition-colors duration-300">
      <div className="w-full max-w-md flex flex-col h-full min-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between mb-12">
          <button onClick={handleBack} className="p-2 -ml-2 text-slate-900 hover:text-blue-600 transition-colors">
            <ChevronLeft size={28} />
          </button>
          <div className="flex-grow mx-8">
            <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
              <div 
                className="h-full bg-blue-600 transition-all duration-500 ease-out"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
            {currentStep + 1}/{QUIZ_STEPS.length}
          </span>
        </div>

        {/* Question */}
        <div className="mb-12">
          <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mb-6">
            <Brain size={24} />
          </div>
          <h2 className="text-3xl font-black tracking-tight leading-tight">
            {step.question}
          </h2>
        </div>

        {/* Options */}
        <div className="grid grid-cols-1 gap-4 mb-12">
          {step.options.map((option) => (
            <button
              key={option.id}
              onClick={() => handleSelect(option.id)}
              className={`flex items-center justify-between p-6 rounded-[2rem] border-2 transition-all text-left group ${
                answers[step.id] === option.id 
                  ? 'bg-blue-600 border-blue-600 text-white shadow-xl shadow-blue-100' 
                  : 'bg-slate-50 border-slate-100 text-slate-900 hover:border-blue-200 hover:bg-white'
              }`}
            >
              <div className="flex items-center gap-4">
                <div className={`p-3 rounded-xl transition-colors ${
                  answers[step.id] === option.id ? 'bg-white/20' : 'bg-white shadow-sm text-slate-400 group-hover:text-blue-600'
                }`}>
                  {option.icon}
                </div>
                <span className="text-lg font-black tracking-tight">{option.label}</span>
              </div>
              {answers[step.id] === option.id && <Check size={20} strokeWidth={3} />}
            </button>
          ))}
        </div>

        {/* Footer */}
        <div className="mt-auto pb-12">
          {currentStep === QUIZ_STEPS.length - 1 && answers[step.id] && (
            <button 
              onClick={handleSubmit}
              disabled={isSubmitting}
              className="w-full py-5 bg-slate-900 text-white rounded-2xl font-black text-xl uppercase tracking-widest hover:bg-slate-800 transition-all flex items-center justify-center gap-3 shadow-xl shadow-slate-200 animate-in fade-in slide-in-from-bottom-4"
            >
              {isSubmitting ? <Loader2 className="animate-spin" /> : (
                <>
                  Complete Analysis
                  <ArrowRight size={24} />
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default Quiz;
