import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Heart, 
  ShieldCheck, 
  AlertTriangle, 
  Loader2, 
  BarChart3, 
  TrendingDown, 
  Activity, 
  Trash2, 
  Plus, 
  Package
} from 'lucide-react';
import { supabase } from '../lib/supabase';

const Watchlist: React.FC = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [watchlist, setWatchlist] = useState<any[]>([]);
  const [likes, setLikes] = useState<any[]>([]);
  const [chemicals, setChemicals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showChemicalModal, setShowChemicalModal] = useState(false);
  const [showAuthPrompt, setShowAuthPrompt] = useState(false);
  const [newChemical, setNewChemical] = useState('');

  useEffect(() => {
    const initAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      const currentUser = session?.user ?? null;
      setUser(currentUser);
      if (currentUser) {
        fetchData(currentUser.id);
        setupSubscriptions(currentUser.id);
      } else {
        const guestHistory = JSON.parse(localStorage.getItem('guest_search_history') || '[]');
        const guestWatchlist = JSON.parse(localStorage.getItem('guest_watchlist') || '[]');
        const guestLikes = JSON.parse(localStorage.getItem('guest_likes') || '[]');
        const guestChemicals = JSON.parse(localStorage.getItem('guest_chemical_watchlist') || '[]');
        setHistory(guestHistory);
        setWatchlist(guestWatchlist);
        setLikes(guestLikes.map((name: string, index: number) => ({ id: `guest-like-${index}`, product_name: name })));
        setChemicals(guestChemicals.map((name: string, index: number) => ({ id: `guest-${index}`, chemical_name: name })));
        setLoading(false);
      }
    };

    initAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      const currentUser = session?.user ?? null;
      setUser(currentUser);
      if (currentUser) {
        fetchData(currentUser.id);
        setupSubscriptions(currentUser.id);
      } else {
        // Load guest history
        const guestHistory = JSON.parse(localStorage.getItem('guest_search_history') || '[]');
        const guestWatchlist = JSON.parse(localStorage.getItem('guest_watchlist') || '[]');
        const guestLikes = JSON.parse(localStorage.getItem('guest_likes') || '[]');
        const guestChemicals = JSON.parse(localStorage.getItem('guest_chemical_watchlist') || '[]');
        setHistory(guestHistory);
        setWatchlist(guestWatchlist);
        setLikes(guestLikes.map((name: string, index: number) => ({ id: `guest-like-${index}`, product_name: name })));
        setChemicals(guestChemicals.map((name: string, index: number) => ({ id: `guest-${index}`, chemical_name: name })));
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const fetchData = async (userId: string) => {
    setLoading(true);
    try {
      const [historyRes, watchlistRes, likesRes, chemicalsRes] = await Promise.all([
        supabase.from('search_history').select('*').eq('user_id', userId).order('created_at', { ascending: false }),
        supabase.from('watchlist').select('*').eq('user_id', userId).order('created_at', { ascending: false }),
        supabase.from('product_likes').select('*').eq('user_id', userId).order('created_at', { ascending: false }),
        supabase.from('chemical_watchlist').select('*').eq('user_id', userId).order('created_at', { ascending: false })
      ]);

      if (historyRes.error) console.error("History fetch error:", historyRes.error);
      if (watchlistRes.error) console.error("Watchlist fetch error:", watchlistRes.error);
      if (likesRes.error) console.error("Likes fetch error:", likesRes.error);
      if (chemicalsRes.error) console.error("Chemicals fetch error:", chemicalsRes.error);

      setHistory(historyRes.data || []);
      setWatchlist(watchlistRes.data || []);
      setLikes(likesRes.data || []);
      setChemicals(chemicalsRes.data || []);
    } catch (err) {
      console.error("Data fetch error:", err);
    } finally {
      setLoading(false);
    }
  };

  const setupSubscriptions = (userId: string) => {
    const historyChannel = supabase
      .channel('history-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'search_history', filter: `user_id=eq.${userId}` }, 
        payload => {
          if (payload.eventType === 'INSERT') setHistory(prev => [payload.new, ...prev]);
          if (payload.eventType === 'DELETE') setHistory(prev => prev.filter(item => item.id !== payload.old.id));
        }
      )
      .subscribe();

    const watchlistChannel = supabase
      .channel('watchlist-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'watchlist', filter: `user_id=eq.${userId}` }, 
        payload => {
          if (payload.eventType === 'INSERT') setWatchlist(prev => [payload.new, ...prev]);
          if (payload.eventType === 'DELETE') setWatchlist(prev => prev.filter(item => item.id !== payload.old.id));
        }
      )
      .subscribe();

    const chemicalsChannel = supabase
      .channel('chemicals-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'chemical_watchlist', filter: `user_id=eq.${userId}` }, 
        payload => {
          if (payload.eventType === 'INSERT') setChemicals(prev => [payload.new, ...prev]);
          if (payload.eventType === 'DELETE') setChemicals(prev => prev.filter(item => item.id !== payload.old.id));
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(historyChannel);
      supabase.removeChannel(watchlistChannel);
      supabase.removeChannel(chemicalsChannel);
    };
  };

  const handleDeleteHistory = async (id: string) => {
    if (id.startsWith('guest-')) {
      const guestHistory = JSON.parse(localStorage.getItem('guest_search_history') || '[]');
      const updatedHistory = guestHistory.filter((item: any) => item.id !== id);
      localStorage.setItem('guest_search_history', JSON.stringify(updatedHistory));
      setHistory(updatedHistory);
    } else {
      const { error } = await supabase.from('search_history').delete().eq('id', id);
      if (error) console.error("Delete history error:", error);
    }
  };

  const handleDeleteLike = async (id: string, productName: string) => {
    if (id.startsWith('guest-like-')) {
      const guestLikes = JSON.parse(localStorage.getItem('guest_likes') || '[]');
      const updated = guestLikes.filter((name: string) => name !== productName);
      localStorage.setItem('guest_likes', JSON.stringify(updated));
      setLikes(updated.map((name: string, idx: number) => ({ id: `guest-like-${idx}`, product_name: name })));
    } else {
      const { error } = await supabase.from('product_likes').delete().eq('id', id);
      if (error) console.error("Delete like error:", error);
      else setLikes(prev => prev.filter(item => item.id !== id));
    }
  };

  const handleDeleteWatchlist = async (id: string) => {
    if (id.startsWith('guest-')) {
      const guestWatchlist = JSON.parse(localStorage.getItem('guest_watchlist') || '[]');
      const updated = guestWatchlist.filter((item: any) => item.id !== id);
      localStorage.setItem('guest_watchlist', JSON.stringify(updated));
      setWatchlist(updated);
    } else {
      const { error } = await supabase.from('watchlist').delete().eq('id', id);
      if (error) console.error("Delete watchlist error:", error);
    }
  };

  const handleDeleteChemical = async (id: string) => {
    if (id.startsWith('guest-')) {
      const guestChemicals = JSON.parse(localStorage.getItem('guest_chemical_watchlist') || '[]');
      const index = parseInt(id.replace('guest-', ''));
      guestChemicals.splice(index, 1);
      localStorage.setItem('guest_chemical_watchlist', JSON.stringify(guestChemicals));
      setChemicals(guestChemicals.map((name: string, idx: number) => ({ id: `guest-${idx}`, chemical_name: name })));
    } else {
      const { error } = await supabase.from('chemical_watchlist').delete().eq('id', id);
      if (error) console.error("Delete chemical error:", error);
    }
  };

  const handleAddChemical = async () => {
    if (!newChemical.trim()) return;
    
    if (!user) {
      setShowAuthPrompt(true);
      setShowChemicalModal(false);
      return;
    }
    
    const { error } = await supabase.from('chemical_watchlist').insert({
      user_id: user.id,
      chemical_name: newChemical.trim()
    });
    if (error) {
      console.error("Add chemical error:", error);
      alert("Failed to add chemical. It might already be in your list.");
    } else {
      setNewChemical('');
      setShowChemicalModal(false);
    }
  };

  // Scientific Project Mock Calculations
  const toxicReduction = history.length > 0 ? Math.min(history.length * 8, 85) : 0;

  return (
    <div className="max-w-7xl mx-auto px-4 py-12 bg-slate-50 dark:bg-slate-950 transition-colors">
      <div className="flex justify-between items-center mb-12">
        <h1 className="text-4xl font-black text-slate-900 dark:text-white tracking-tighter">Watchlist & Analytics</h1>
      </div>

      <div className="text-center mb-16">
        <h2 className="text-3xl font-black text-slate-900 dark:text-white tracking-tighter mb-4 uppercase">Risk <span className="text-blue-600">Analytics</span></h2>
        <p className="text-slate-500 font-medium">Monitoring your cumulative exposure to industrial chemicals based on search history.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
        {/* STAT 1 */}
        <div className="bg-white dark:bg-slate-900 p-10 rounded-[3rem] border border-slate-100 dark:border-slate-800 shadow-xl relative overflow-hidden group">
           <div className="absolute -right-6 -top-6 text-slate-50 opacity-10 group-hover:opacity-20 transition-opacity">
              <BarChart3 size={180} />
           </div>
           <div className="flex items-center gap-4 mb-8">
              <div className="p-4 bg-blue-600 text-white rounded-2xl shadow-lg">
                 <Activity size={24} />
              </div>
              <h3 className="text-lg font-black text-slate-900 uppercase tracking-widest">Exposure Stats</h3>
           </div>
           <div className="flex items-end gap-3 mb-6">
              <span className="text-6xl font-black text-slate-900">{history.length}</span>
              <span className="text-slate-400 font-bold mb-2">Total Searches</span>
           </div>
           <p className="text-sm text-slate-500 font-medium leading-relaxed">System tracking active in Firebase cloud storage.</p>
        </div>

        {/* STAT 2 */}
        <div className="bg-slate-900 dark:bg-slate-800 text-white p-10 rounded-[3rem] shadow-2xl relative overflow-hidden">
           <div className="absolute -right-6 -bottom-6 text-blue-500 opacity-10">
              <TrendingDown size={180} />
           </div>
           <h3 className="text-lg font-black uppercase tracking-widest text-blue-400 mb-8">Toxicity Reduction</h3>
           <div className="flex items-end gap-3 mb-6">
              <span className="text-6xl font-black">{toxicReduction}%</span>
              <span className="text-blue-300 font-bold mb-2">Efficiency</span>
           </div>
           <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden">
              <div className="bg-blue-400 h-full transition-all duration-1000" style={{ width: `${toxicReduction}%` }} />
           </div>
           <p className="mt-6 text-xs text-slate-400 uppercase tracking-widest font-black">AI Calculated Awareness Score</p>
        </div>

        {/* STAT 3 */}
        <div className="bg-rose-600 dark:bg-rose-700 text-white p-10 rounded-[3rem] shadow-xl relative overflow-hidden">
           <h3 className="text-lg font-black uppercase tracking-widest mb-8 opacity-70">Chemical Watchlist</h3>
           <div className="space-y-4 max-h-[200px] overflow-y-auto pr-2 custom-scrollbar">
              {chemicals.length === 0 ? (
                <div className="py-4 text-center opacity-50 italic text-xs">No chemicals tracked</div>
              ) : (
                chemicals.map((c) => (
                  <div key={c.id} className="flex items-center justify-between p-4 bg-white/10 rounded-2xl border border-white/20 group">
                     <span className="font-bold text-sm">{c.chemical_name}</span>
                     <button 
                      onClick={() => handleDeleteChemical(c.id)}
                      className="opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-white/20 rounded-lg"
                     >
                        <Trash2 size={14} className="text-rose-200" />
                     </button>
                  </div>
                ))
              )}
           </div>
           <button 
            onClick={() => setShowChemicalModal(true)}
            className="w-full mt-6 py-4 bg-white text-rose-600 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-rose-50 transition-colors"
           >
              Configure Watchlist
           </button>
        </div>
      </div>

      {/* Product Watchlist Section */}
      <div className="bg-white dark:bg-slate-900 rounded-[3.5rem] border border-slate-100 dark:border-slate-800 shadow-sm p-10 mb-12">
         <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-8 flex items-center gap-4">
            <Heart className="text-rose-500" fill="currentColor" />
            Liked Products
         </h3>

         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {loading ? (
              <div className="col-span-full flex justify-center py-10"><Loader2 className="animate-spin text-blue-600" size={32} /></div>
            ) : likes.length === 0 ? (
              <div className="col-span-full text-center py-10 bg-slate-50 dark:bg-slate-800/50 rounded-3xl border border-dashed border-slate-200 dark:border-slate-700">
                <p className="text-slate-400 font-bold">No liked products yet.</p>
              </div>
            ) : (
              likes.map((item) => (
                <div key={item.id} className="p-6 bg-slate-50 dark:bg-slate-800/50 rounded-3xl border border-slate-100 dark:border-slate-800 group hover:border-rose-200 dark:hover:border-rose-900 transition-all">
                   <div className="flex justify-between items-start mb-4">
                      <Heart className="text-rose-500" fill="currentColor" size={16} />
                      <button 
                        onClick={() => handleDeleteLike(item.id, item.product_name)}
                        className="p-2 text-slate-300 hover:text-rose-500 transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                   </div>
                   <h4 className="font-black text-slate-900 dark:text-white text-lg mb-4 line-clamp-1">{item.product_name}</h4>
                   <button 
                    onClick={() => navigate('/analyze', { state: { prefill: item.product_name } })}
                    className="w-full py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-[10px] font-black uppercase tracking-widest text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 transition-all"
                   >
                    View Analysis
                   </button>
                </div>
              ))
            )}
         </div>
      </div>

      {/* Product Watchlist Section */}
      <div className="bg-white dark:bg-slate-900 rounded-[3.5rem] border border-slate-100 dark:border-slate-800 shadow-sm p-10 mb-12">
         <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-8 flex items-center gap-4">
            <Heart className="text-rose-500" fill="currentColor" />
            Product Watchlist
         </h3>

         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {loading ? (
              <div className="col-span-full flex justify-center py-10"><Loader2 className="animate-spin text-blue-600" size={32} /></div>
            ) : watchlist.length === 0 ? (
              <div className="col-span-full text-center py-10 bg-slate-50 dark:bg-slate-800/50 rounded-3xl border border-dashed border-slate-200 dark:border-slate-700">
                <p className="text-slate-400 font-bold">No products in your watchlist.</p>
              </div>
            ) : (
              watchlist.map((item) => (
                <div key={item.id} className="p-6 bg-slate-50 dark:bg-slate-800/50 rounded-3xl border border-slate-100 dark:border-slate-800 group hover:border-rose-200 dark:hover:border-rose-900 transition-all">
                   <div className="flex justify-between items-start mb-4">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{item.list_title}</span>
                      <button 
                        onClick={() => handleDeleteWatchlist(item.id)}
                        className="p-2 text-slate-300 hover:text-rose-500 transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                   </div>
                   <h4 className="font-black text-slate-900 dark:text-white text-lg mb-4 line-clamp-1">{item.product_name}</h4>
                   <button 
                    onClick={() => navigate('/analyze', { state: { prefill: item.product_name } })}
                    className="w-full py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-[10px] font-black uppercase tracking-widest text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 transition-all"
                   >
                    View Analysis
                   </button>
                </div>
              ))
            )}
         </div>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-[3.5rem] border border-slate-100 dark:border-slate-800 shadow-sm p-10">
         <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-8 flex items-center gap-4">
            <ShieldCheck className="text-emerald-500" />
            Product History
            <span className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-500 ml-auto">Academic Transparency Standard</span>
         </h3>

         <div className="space-y-4">
            {loading ? (
              <div className="flex justify-center py-20"><Loader2 className="animate-spin text-blue-600" size={40} /></div>
            ) : history.length === 0 ? (
              <div className="text-center py-20 bg-slate-50 rounded-[3rem] border border-dashed border-slate-200">
                <p className="text-slate-400 font-bold">Your database search trail is currently empty.</p>
              </div>
            ) : (
               history.map((item, idx) => (
                <div key={idx} className="flex items-center justify-between p-6 bg-slate-50 dark:bg-slate-800/50 rounded-3xl border border-slate-100 dark:border-slate-800 group hover:border-blue-200 dark:hover:border-blue-900 transition-all">
                   <div className="flex items-center gap-6">
                      <div className="w-14 h-14 bg-white dark:bg-slate-800 rounded-2xl flex items-center justify-center text-blue-600 shadow-sm group-hover:bg-blue-600 group-hover:text-white transition-all">
                         <BarChart3 size={24} />
                      </div>
                      <div>
                         <h4 className="font-black text-slate-900 dark:text-white text-lg">{item.search_term}</h4>
                         <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Search Conducted on {item.created_at ? new Date(item.created_at).toLocaleDateString() : 'Unknown Date'}</p>
                      </div>
                   </div>
                   <button 
                    onClick={() => handleDeleteHistory(item.id)}
                    className="p-4 text-slate-300 hover:text-rose-500 transition-colors"
                   >
                      <Trash2 size={20} />
                   </button>
                </div>
              ))
            )}
         </div>
      </div>

      {/* Chemical Add Modal */}
      {showChemicalModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
           <div className="bg-white dark:bg-slate-900 rounded-[3rem] p-10 w-full max-w-md shadow-2xl animate-in zoom-in-95 duration-200 border border-slate-200 dark:border-slate-800">
              <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-2">Track Chemical</h3>
              <p className="text-slate-500 text-sm mb-8">Add a chemical to your watchlist to monitor exposure risks.</p>
              
              <input 
                type="text"
                value={newChemical}
                onChange={(e) => setNewChemical(e.target.value)}
                placeholder="e.g. Parabens, Sulfates..."
                className="w-full px-6 py-4 bg-slate-50 dark:bg-slate-800 border-2 border-slate-100 dark:border-slate-700 rounded-2xl focus:border-rose-500 outline-none font-bold mb-6 transition-all text-slate-900 dark:text-white"
                onKeyDown={(e) => e.key === 'Enter' && handleAddChemical()}
              />

              <div className="flex gap-4">
                 <button 
                   onClick={() => setShowChemicalModal(false)}
                   className="flex-1 py-4 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                 >
                   Cancel
                 </button>
                 <button 
                   onClick={handleAddChemical}
                   className="flex-1 py-4 bg-rose-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-rose-700 transition-colors shadow-lg shadow-rose-200 dark:shadow-rose-900/20"
                 >
                   Add to Watchlist
                 </button>
              </div>
           </div>
        </div>
      )}
      {/* Auth Prompt Modal */}
      {showAuthPrompt && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 rounded-[3rem] p-10 w-full max-w-md shadow-2xl animate-in zoom-in-95 duration-200 border border-slate-200 dark:border-slate-800 text-center">
            <div className="bg-blue-600 w-16 h-16 rounded-2xl flex items-center justify-center text-white mx-auto mb-6 shadow-lg shadow-blue-200 dark:shadow-blue-900/40">
              <ShieldCheck size={32} />
            </div>
            <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-2">Sign Up Required</h3>
            <p className="text-slate-500 dark:text-slate-400 text-sm mb-8">
              Please sign up or sign in to track chemicals in your watchlist. Join our community to monitor your exposure risks.
            </p>
            
            <div className="flex flex-col gap-4">
              <button 
                onClick={() => navigate('/signup')}
                className="w-full py-4 bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-blue-700 transition-colors shadow-lg shadow-blue-200 dark:shadow-blue-900/20"
              >
                Create Account
              </button>
              <button 
                onClick={() => setShowAuthPrompt(false)}
                className="w-full py-4 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
              >
                Maybe Later
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Watchlist;
