import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { NotificationItem } from '../lib/notifications';
import { 
  ChevronLeft, 
  Settings as SettingsIcon, 
  Bell, 
  Check, 
  Trash2, 
  Info, 
  AlertCircle,
  Clock,
  MoreVertical
} from 'lucide-react';

interface ToggleProps {
  label: string;
  enabled: boolean;
  onToggle: () => void;
}

const NotificationToggle: React.FC<ToggleProps> = ({ label, enabled, onToggle }) => (
  <div className="flex items-center justify-between py-5 border-b border-white/5 px-6 hover:bg-white/5 transition-colors cursor-pointer" onClick={onToggle}>
    <span className="text-[15px] font-medium text-white/80 max-w-[80%] leading-tight">{label}</span>
    <div className={`w-11 h-6 rounded-full relative transition-colors duration-300 ${enabled ? 'bg-emerald-500' : 'bg-zinc-800'}`}>
      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-md transition-transform duration-300 ${enabled ? 'translate-x-6' : 'translate-x-1'}`} />
    </div>
  </div>
);

const MOCK_NOTIFICATIONS: NotificationItem[] = [
  {
    id: '1',
    title: 'New Product Added',
    message: 'Johnson\'s Baby Lotion has been added to the forensic registry.',
    time: '2 hours ago',
    type: 'success',
    read: false
  },
  {
    id: '2',
    title: 'Rating Change Alert',
    message: 'Dove Deep Moisture Body Wash rating updated due to new chemical audit.',
    time: '5 hours ago',
    type: 'warning',
    read: false
  },
  {
    id: '3',
    title: 'System Update',
    message: 'Gemini 3.0 Reasoning Engine is now active for all searches.',
    time: '1 day ago',
    type: 'info',
    read: true
  }
];

const Notifications: React.FC = () => {
  const navigate = useNavigate();
  const [showSettings, setShowSettings] = useState(false);
  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved = localStorage.getItem('notifications_data');
    return saved ? JSON.parse(saved) : MOCK_NOTIFICATIONS;
  });
  
  const [settings, setSettings] = useState(() => {
    const saved = localStorage.getItem('notification_settings');
    return saved ? JSON.parse(saved) : {
      newProduct: true,
      ratingsChange: true,
      submissionsAdded: true,
      scannedProductAdded: true,
      submissionRejected: false,
      reviewSubmitted: false,
      reviewSaved: true,
      reviewLiked: true,
      feedbackGiven: false
    };
  });

  useEffect(() => {
    localStorage.setItem('notification_settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('notifications_data', JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    const handleStorage = () => {
      const saved = localStorage.getItem('notifications_data');
      if (saved) {
        setNotifications(JSON.parse(saved));
      }
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  const toggle = (key: keyof typeof settings) => {
    setSettings((prev: any) => ({ ...prev, [key]: !prev[key] }));
  };

  const markAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const deleteNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const clearAll = () => {
    setNotifications([]);
  };

  const handleBack = () => {
    if (showSettings) {
      setShowSettings(false);
    } else {
      navigate(-1);
    }
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'success': return <Check className="text-emerald-500" size={18} />;
      case 'warning': return <AlertCircle className="text-amber-500" size={18} />;
      default: return <Info className="text-blue-500" size={18} />;
    }
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black text-white font-['Inter'] flex flex-col overflow-hidden">
      <header className="sticky top-0 z-50 bg-black/80 backdrop-blur-xl px-4 py-5 flex items-center justify-between border-b border-white/5">
        <button 
          onClick={handleBack}
          className="p-2 -ml-2 hover:bg-white/10 rounded-full transition-all active:scale-90"
        >
          <ChevronLeft size={28} strokeWidth={2.5} />
        </button>
        <h1 className="text-[17px] font-bold tracking-tight absolute left-1/2 -translate-x-1/2">
          {showSettings ? 'Settings' : 'Notifications'}
        </h1>
        <div className="flex items-center gap-2">
          {!showSettings ? (
            <>
              {notifications.length > 0 && (
                <button 
                  onClick={clearAll}
                  className="p-2 hover:bg-white/10 rounded-full transition-all text-zinc-400 hover:text-white"
                  title="Clear All"
                >
                  <Trash2 size={20} />
                </button>
              )}
              <button 
                onClick={() => setShowSettings(true)}
                className="p-2 hover:bg-white/10 rounded-full transition-all text-zinc-400 hover:text-white"
                title="Settings"
              >
                <SettingsIcon size={22} />
              </button>
            </>
          ) : (
            <button 
              onClick={() => setShowSettings(false)}
              className="text-[13px] font-bold text-emerald-500 hover:text-emerald-400 transition-colors uppercase tracking-widest px-2"
            >
              Done
            </button>
          )}
        </div>
      </header>

      <main className="flex-grow flex flex-col overflow-y-auto">
        {!showSettings ? (
          <div className="flex flex-col">
            {notifications.length > 0 ? (
              <div className="divide-y divide-white/5">
                {notifications.map((n) => (
                  <div 
                    key={n.id} 
                    className={`p-6 flex gap-4 hover:bg-white/5 transition-colors group relative ${!n.read ? 'bg-white/[0.02]' : ''}`}
                    onClick={() => markAsRead(n.id)}
                  >
                    <div className={`mt-1 w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0 ${
                      n.type === 'success' ? 'bg-emerald-500/10' : 
                      n.type === 'warning' ? 'bg-amber-500/10' : 'bg-blue-500/10'
                    }`}>
                      {getIcon(n.type)}
                    </div>
                    <div className="flex-grow pr-8">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className={`font-bold text-[15px] ${!n.read ? 'text-white' : 'text-zinc-400'}`}>{n.title}</h3>
                        {!n.read && <div className="w-2 h-2 bg-blue-500 rounded-full" />}
                      </div>
                      <p className="text-zinc-400 text-sm leading-relaxed mb-2">{n.message}</p>
                      <div className="flex items-center gap-1.5 text-[11px] font-bold text-zinc-500 uppercase tracking-wider">
                        <Clock size={12} />
                        {n.time}
                      </div>
                    </div>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteNotification(n.id);
                      }}
                      className="absolute right-4 top-6 p-2 opacity-0 group-hover:opacity-100 text-zinc-500 hover:text-rose-500 transition-all"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex-grow flex flex-col items-center justify-center p-8 py-32">
                <div className="w-20 h-20 bg-zinc-900 rounded-[2.5rem] flex items-center justify-center mb-6">
                  <Bell size={32} className="text-zinc-700" />
                </div>
                <p className="text-zinc-500 text-lg font-medium text-center max-w-[240px] leading-snug">
                  Oops, we got nothing to let you know yet. Maybe later.
                </p>
              </div>
            )}
          </div>
        ) : (
          <div className="animate-in slide-in-from-right duration-300">
            <section className="mt-4">
              <h2 className="px-6 text-[11px] font-black uppercase tracking-[0.2em] text-zinc-500 mb-2">Updates</h2>
              <div className="bg-zinc-950/20">
                <NotificationToggle 
                  label="When a new product is added" 
                  enabled={settings.newProduct} 
                  onToggle={() => toggle('newProduct')} 
                />
                <NotificationToggle 
                  label="When product ratings change" 
                  enabled={settings.ratingsChange} 
                  onToggle={() => toggle('ratingsChange')} 
                />
                <NotificationToggle 
                  label="When your submissions are in database" 
                  enabled={settings.submissionsAdded} 
                  onToggle={() => toggle('submissionsAdded')} 
                />
                <NotificationToggle 
                  label="When a product you scanned is added to the database." 
                  enabled={settings.scannedProductAdded} 
                  onToggle={() => toggle('scannedProductAdded')} 
                />
                <NotificationToggle 
                  label="When your submission is not accepted" 
                  enabled={settings.submissionRejected} 
                  onToggle={() => toggle('submissionRejected')} 
                />
              </div>
            </section>
            <section className="mt-10 mb-20">
              <h2 className="px-6 text-[11px] font-black uppercase tracking-[0.2em] text-zinc-500 mb-2">Reviews</h2>
              <div className="bg-zinc-950/20">
                <NotificationToggle 
                  label="When a new review is added to a product I submitted" 
                  enabled={settings.reviewSubmitted} 
                  onToggle={() => toggle('reviewSubmitted')} 
                />
                <NotificationToggle 
                  label="When a new review is added to a product I saved" 
                  enabled={settings.reviewSaved} 
                  onToggle={() => toggle('reviewSaved')} 
                />
                <NotificationToggle 
                  label="When a new review is added to a product I liked" 
                  enabled={settings.reviewLiked} 
                  onToggle={() => toggle('reviewLiked')} 
                />
                <NotificationToggle 
                  label="When a new feedback is given to a review I added" 
                  enabled={settings.feedbackGiven} 
                  onToggle={() => toggle('feedbackGiven')} 
                />
              </div>
            </section>
          </div>
        )}
      </main>
      <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full h-1/2 bg-blue-500/5 blur-[120px] -z-10 pointer-events-none" />
    </div>
  );
};

export default Notifications;