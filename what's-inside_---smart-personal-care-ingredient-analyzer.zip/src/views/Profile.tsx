
import React, { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  User, 
  Settings, 
  Camera, 
  Info, 
  Heart,
  Star, 
  MessageSquare, 
  ThumbsUp, 
  Lock,
  Loader2,
  ChevronLeft,
  LogOut,
  Plus
} from 'lucide-react';
import { supabase, supabaseAdmin, isSupabaseConfigured } from '../lib/supabase';

const Profile: React.FC = () => {
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [profile, setProfile] = useState<any>(null);
  const [stats, setStats] = useState({
    likes: 0,
    lists: 0,
    preferred: 0,
    reviews: 0,
    reviewLikes: 0,
    expiring: 0
  });
  const [activities, setActivities] = useState<any[]>([]);
  const [activeFilter, setActiveFilter] = useState('Viewed');
  const [activeTimeframe, setActiveTimeframe] = useState('Week');

  const fetchProfile = async () => {
    if (!isSupabaseConfigured) {
      setLoading(false);
      return;
    }

    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      navigate('/login');
      return;
    }

    setUser(session.user);
    
    // Fetch profile
    const { data: profileData, error: profileError } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', session.user.id)
      .single();

    if (!profileError && profileData) {
      setProfile(profileData);
    }

    // Fetch stats
    const [likesCount, listsCount, reviewsCount, chemicalsCount] = await Promise.all([
      supabase.from('product_likes').select('*', { count: 'exact', head: true }).eq('user_id', session.user.id),
      supabase.from('product_lists').select('*', { count: 'exact', head: true }).eq('user_id', session.user.id),
      supabase.from('reviews').select('*', { count: 'exact', head: true }).eq('user_id', session.user.id),
      supabase.from('chemical_watchlist').select('*', { count: 'exact', head: true }).eq('user_id', session.user.id)
    ]);

    setStats(prev => ({
      ...prev,
      likes: likesCount.count || 0,
      preferred: chemicalsCount.count || 0, // Preferred reflects chemical watchlist
      lists: listsCount.count || 0,
      reviews: reviewsCount.count || 0
    }));
    
    setLoading(false);
  };

  const fetchActivities = async () => {
    if (!user) return;

    let query: any;
    if (activeFilter === 'Liked') {
      query = supabase
        .from('product_likes')
        .select('product_name, created_at')
        .eq('user_id', user.id);
    } else if (activeFilter === 'Scanned') {
      query = supabase
        .from('search_history')
        .select('search_term, created_at')
        .eq('user_id', user.id)
        .eq('is_scan', true);
    } else {
      query = supabase
        .from('search_history')
        .select('search_term, created_at')
        .eq('user_id', user.id)
        .eq('is_scan', false);
    }

    // Apply timeframe filter
    const now = new Date();
    let startDate = new Date();
    if (activeTimeframe === 'Week') startDate.setDate(now.getDate() - 7);
    else if (activeTimeframe === 'Month') startDate.setMonth(now.getMonth() - 1);
    else if (activeTimeframe === 'Year') startDate.setFullYear(now.getFullYear() - 1);

    query = query.gte('created_at', startDate.toISOString()).order('created_at', { ascending: false });

    const { data, error } = await query;
    if (!error && data) {
      setActivities(data.map((item: any) => ({
        name: item.product_name || item.search_term,
        date: new Date(item.created_at).toLocaleDateString(),
        type: activeFilter
      })));
    }
  };

  useEffect(() => {
    fetchProfile();

    // Real-time subscriptions for live updates
    const setupRealtime = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const userId = session.user.id;

      const likesChannel = supabase
        .channel('profile-likes-changes')
        .on('postgres_changes', { 
          event: '*', 
          schema: 'public', 
          table: 'product_likes', 
          filter: `user_id=eq.${userId}` 
        }, () => {
          fetchProfile();
          fetchActivities();
        })
        .subscribe();

      const listsChannel = supabase
        .channel('profile-lists-changes')
        .on('postgres_changes', { 
          event: '*', 
          schema: 'public', 
          table: 'product_lists', 
          filter: `user_id=eq.${userId}` 
        }, () => {
          fetchProfile();
        })
        .subscribe();

      const chemicalsChannel = supabase
        .channel('profile-chemicals-changes')
        .on('postgres_changes', { 
          event: '*', 
          schema: 'public', 
          table: 'chemical_watchlist', 
          filter: `user_id=eq.${userId}` 
        }, () => {
          fetchProfile();
        })
        .subscribe();

      const reviewsChannel = supabase
        .channel('profile-reviews-changes')
        .on('postgres_changes', { 
          event: '*', 
          schema: 'public', 
          table: 'reviews', 
          filter: `user_id=eq.${userId}` 
        }, () => {
          fetchProfile();
        })
        .subscribe();

      return () => {
        supabase.removeChannel(likesChannel);
        supabase.removeChannel(listsChannel);
        supabase.removeChannel(chemicalsChannel);
        supabase.removeChannel(reviewsChannel);
      };
    };

    const cleanupPromise = setupRealtime();
    
    return () => {
      cleanupPromise.then(cleanup => cleanup && cleanup());
    };
  }, [navigate]);

  useEffect(() => {
    fetchActivities();
  }, [user, activeFilter, activeTimeframe]);

  const handleSignOut = async () => {
    if (isSupabaseConfigured) {
      await supabase.auth.signOut();
      navigate('/login');
    }
  };

  const handleCameraClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("No session found");

      // 1. Upload to Supabase Storage (assuming 'avatars' bucket exists)
      // If it doesn't exist, we'll fallback to base64 for this demo or just update the URL
      const fileExt = file.name.split('.').pop();
      const fileName = `${session.user.id}-${Math.random()}.${fileExt}`;
      const filePath = `avatars/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file);

      let avatarUrl = '';
      if (uploadError) {
        console.warn("Storage upload failed, using local preview only:", uploadError.message);
        // Fallback: Create a local URL for preview if storage fails
        avatarUrl = URL.createObjectURL(file);
      } else {
        const { data: { publicUrl } } = supabase.storage
          .from('avatars')
          .getPublicUrl(filePath);
        avatarUrl = publicUrl;
      }

      // 2. Update profile in database
      const { error: updateError } = await supabase
        .from('profiles')
        .update({ avatar_url: avatarUrl })
        .eq('id', session.user.id);

      if (updateError) throw updateError;

      // 3. Refresh profile
      await fetchProfile();
    } catch (error: any) {
      console.error("Error uploading avatar:", error.message);
      alert("Failed to upload image. Please try again.");
    } finally {
      setUploading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black">
        <Loader2 className="animate-spin text-[#4ade80]" size={48} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans pb-24 transition-colors duration-300">
      {/* Hidden File Input */}
      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleFileChange} 
        accept="image/*" 
        className="hidden" 
      />

      {/* Header */}
      <div className="px-6 py-4 flex justify-between items-center sticky top-0 bg-slate-50/80 dark:bg-slate-950/80 backdrop-blur-md z-50 border-b border-slate-200 dark:border-slate-800">
        <h1 className="text-xl font-black tracking-tight">Profile</h1>
        <Settings size={24} className="text-slate-500 hover:text-blue-600 cursor-pointer transition-colors" />
      </div>

      <div className="px-6 max-w-4xl mx-auto">
        {/* User Info Section */}
        <div className="flex items-center gap-8 mt-10">
          <div className="relative">
            <div 
              className={`w-24 h-24 rounded-[2rem] bg-white dark:bg-slate-900 flex items-center justify-center overflow-hidden border-2 border-blue-500 shadow-xl shadow-blue-100 dark:shadow-none transition-all ${uploading ? 'opacity-50' : ''}`}
            >
              {uploading ? (
                <Loader2 className="animate-spin text-blue-600" size={32} />
              ) : profile?.avatar_url ? (
                <img src={profile.avatar_url} alt="Avatar" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center">
                   <User size={40} className="text-white" />
                </div>
              )}
            </div>
            <button 
              onClick={handleCameraClick}
              disabled={uploading}
              className="absolute -bottom-2 -right-2 bg-white dark:bg-slate-800 p-2 rounded-xl shadow-lg border border-slate-100 dark:border-slate-700 text-blue-600 hover:scale-110 active:scale-95 transition-all"
            >
              <Camera size={14} />
            </button>
          </div>

          <div className="flex flex-1 justify-between text-center">
            <div 
              onClick={() => setActiveFilter('Liked')}
              className={`flex flex-col items-center cursor-pointer transition-colors ${activeFilter === 'Liked' ? 'text-blue-600' : 'hover:text-blue-600'}`}
            >
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Likes</span>
              <span className="text-xl font-black">{stats.likes}</span>
            </div>
            <div className="h-8 w-px bg-slate-200 dark:bg-slate-800 self-center" />
            <div 
              onClick={() => navigate('/watchlist')}
              className="flex flex-col items-center cursor-pointer hover:text-blue-600 transition-colors"
            >
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Preferred</span>
              <span className="text-xl font-black">{stats.preferred}</span>
            </div>
            <div className="h-8 w-px bg-slate-200 dark:bg-slate-800 self-center" />
            <div 
              onClick={() => navigate('/all-products')}
              className="flex flex-col items-center cursor-pointer hover:text-blue-600 transition-colors"
            >
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Lists</span>
              <span className="text-xl font-black">{stats.lists}</span>
            </div>
          </div>
        </div>

        {/* Name & Edit */}
        <div className="mt-8 flex flex-col gap-2">
          <div className="flex items-center gap-4">
            <h2 className="text-3xl font-black tracking-tight">{profile?.full_name || 'Sufiyan Malik'}</h2>
            <button 
              onClick={() => navigate('/edit-profile')}
              className="text-blue-600 text-sm font-black uppercase tracking-widest hover:underline"
            >
              Edit profile
            </button>
          </div>
          {profile?.bio && (
            <p className="text-slate-500 dark:text-slate-400 text-sm font-medium leading-relaxed max-w-md">
              {profile.bio}
            </p>
          )}
        </div>

        {/* Personal Info */}
        {(profile?.dob || profile?.gender || profile?.phone) && (
          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4 p-6 bg-white dark:bg-slate-900 rounded-[2rem] border border-slate-100 dark:border-slate-800">
            {profile.dob && (
              <div>
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Date of Birth</span>
                <span className="font-bold">
                  {new Date(profile.dob).toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'short', 
                    day: 'numeric' 
                  })}
                </span>
              </div>
            )}
            {profile.gender && (
              <div>
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Gender</span>
                <span className="font-bold">{profile.gender}</span>
              </div>
            )}
            {profile.phone && (
              <div>
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Phone</span>
                <span className="font-bold">{profile.phone}</span>
              </div>
            )}
          </div>
        )}

        {/* Secondary Stats */}
        <div className="mt-12 grid grid-cols-1 sm:grid-cols-3 gap-6">
          <div className="flex flex-col items-center p-6 bg-white dark:bg-slate-900 rounded-[2rem] border border-slate-100 dark:border-slate-800 shadow-sm">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest text-center mb-2">Your Reviews</span>
            <div className="flex items-center gap-2">
              <span className="text-xl font-black">{stats.reviews}</span>
              <MessageSquare size={18} className="text-blue-500" />
            </div>
          </div>
          <div className="flex flex-col items-center p-6 bg-white dark:bg-slate-900 rounded-[2rem] border border-slate-100 dark:border-slate-800 shadow-sm">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest text-center mb-2">Review Likes</span>
            <div className="flex items-center gap-2">
              <span className="text-xl font-black">{stats.reviewLikes}</span>
              <ThumbsUp size={18} className="text-rose-500" />
            </div>
          </div>
          <div className="flex flex-col items-center p-6 bg-white dark:bg-slate-900 rounded-[2rem] border border-slate-100 dark:border-slate-800 shadow-sm">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest text-center mb-2">Expiring</span>
            <span className="text-xl font-black text-amber-600">{stats.expiring}</span>
          </div>
        </div>

        {/* Activities Section */}
        <div className="mt-16">
          <div className="flex items-center gap-3 mb-8">
            <h3 className="text-2xl font-black tracking-tight">Activities</h3>
            <div className="p-1 bg-slate-100 dark:bg-slate-800 rounded-full">
              <Info size={14} className="text-slate-400" />
            </div>
          </div>

          <div className="flex gap-3 mb-8 overflow-x-auto pb-2 no-scrollbar">
            {['Viewed', 'Scanned', 'Liked'].map((filter) => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={`px-8 py-3 rounded-2xl font-black text-xs uppercase tracking-widest transition-all ${
                  activeFilter === filter 
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-200 dark:shadow-none' 
                    : 'bg-white dark:bg-slate-900 text-slate-500 border border-slate-100 dark:border-slate-800'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>

          <div className="bg-slate-100 dark:bg-slate-900 p-1.5 rounded-[1.5rem] flex gap-1 mb-8">
            {['Week', 'Month', 'Year'].map((time) => (
              <button
                key={time}
                onClick={() => setActiveTimeframe(time)}
                className={`flex-1 py-3 rounded-xl font-black text-xs uppercase tracking-widest transition-all ${
                  activeTimeframe === time 
                    ? 'bg-white dark:bg-slate-800 text-blue-600 shadow-sm' 
                    : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                {time}
              </button>
            ))}
          </div>

          <div className="space-y-4">
            {activities.length > 0 ? activities.map((activity, index) => (
              <div 
                key={index}
                onClick={() => navigate('/analyze', { state: { prefill: activity.name } })}
                className="p-6 bg-white dark:bg-slate-900 rounded-[2rem] border border-slate-100 dark:border-slate-800 flex items-center justify-between group cursor-pointer hover:border-blue-200 transition-all"
              >
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                    activity.type === 'Liked' ? 'bg-rose-50 text-rose-500' : 
                    activity.type === 'Scanned' ? 'bg-blue-50 text-blue-500' : 'bg-slate-50 text-slate-500'
                  }`}>
                    {activity.type === 'Liked' ? <Heart size={20} fill="currentColor" /> : 
                     activity.type === 'Scanned' ? <Camera size={20} /> : <User size={20} />}
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white group-hover:text-blue-600 transition-colors">{activity.name}</h4>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{activity.date}</p>
                  </div>
                </div>
                <ChevronLeft className="rotate-180 text-slate-300 group-hover:text-blue-400 transition-all" size={20} />
              </div>
            )) : (
              <div className="py-20 text-center bg-white dark:bg-slate-900 rounded-[3rem] border border-dashed border-slate-200 dark:border-slate-800">
                <p className="text-slate-400 font-bold italic">No activities found for this period.</p>
              </div>
            )}
          </div>
        </div>

        {/* Sign Out */}
        <div className="mt-24 pt-12 border-t border-slate-200 dark:border-slate-800 flex justify-center">
          <button 
            onClick={handleSignOut}
            className="flex items-center gap-3 px-10 py-4 bg-rose-50 dark:bg-rose-900/10 text-rose-600 dark:text-rose-400 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-rose-100 dark:hover:bg-rose-900/20 transition-all shadow-lg shadow-rose-100 dark:shadow-none"
          >
            <LogOut size={20} />
            Terminate Session
          </button>
        </div>
      </div>
    </div>
  );
};

export default Profile;
