import React, { useRef, useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  ShieldAlert, 
  Zap,
  ShieldCheck,
  Globe,
  Droplets,
  Flower2,
  Wind,
  Sparkles,
  Sun,
  Moon,
  Waves,
  Hand,
  Search,
  ChevronRight,
  ChevronLeft,
  LayoutGrid,
  Rows,
  ListTodo,
  Rabbit,
  Pipette,
  Brush,
  Baby,
  Smile,
  Cloud,
  FlaskConical,
  SprayCan,
  WashingMachine,
  ShowerHead,
  Home as HomeIcon,
  User,
  PawPrint,
  Leaf,
  Flower,
  Check,
  CheckCircle,
  Heart,
  Dna,
  Atom,
  Beaker,
  Star,
  Milk,
  Image as ImageIcon,
  X,
  Info,
  Activity,
  FileText
} from 'lucide-react';
import { supabaseAdmin } from '@/lib/supabase';

const BackgroundAnimation = () => (
  <div className="fixed inset-0 pointer-events-none -z-10 overflow-hidden">
    <div className="absolute top-[15%] left-[10%] opacity-[0.07] dark:opacity-[0.15] animate-drift text-blue-500">
      <Beaker size={120} strokeWidth={1} />
    </div>
    <div className="absolute top-[60%] left-[5%] opacity-[0.05] dark:opacity-[0.1] animate-drift-slow text-emerald-500">
      <Leaf size={180} strokeWidth={1} />
    </div>
    <div className="absolute top-[25%] right-[8%] opacity-[0.08] dark:opacity-[0.15] animate-drift-fast text-indigo-500">
      <Dna size={100} strokeWidth={1} />
    </div>
    <div className="absolute top-[75%] right-[12%] opacity-[0.04] dark:opacity-[0.08] animate-spin-slow text-blue-400">
      <Atom size={200} strokeWidth={0.5} />
    </div>
    <div className="absolute bottom-[10%] left-[40%] opacity-[0.06] dark:opacity-[0.12] animate-drift text-rose-400">
      <ShieldCheck size={140} strokeWidth={1} />
    </div>
    <div className="absolute top-[40%] left-[50%] opacity-[0.03] dark:opacity-[0.06] animate-drift-slow text-amber-500">
      <FlaskConical size={160} strokeWidth={1} />
    </div>
  </div>
);

const Home: React.FC = () => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef2 = useRef<HTMLDivElement>(null);
  const scrollContainerRef3 = useRef<HTMLDivElement>(null);
  const scrollContainerRef4 = useRef<HTMLDivElement>(null);
  const scrollContainerRef5 = useRef<HTMLDivElement>(null);
  const scrollContainerRef6 = useRef<HTMLDivElement>(null);
  const scrollContainerRef7 = useRef<HTMLDivElement>(null);
  
  const [isGridView, setIsGridView] = useState(false);
  const [isGridView2, setIsGridView2] = useState(false);
  const [isGridView3, setIsGridView3] = useState(false);
  const [isGridView4, setIsGridView4] = useState(false);
  const [isGridView5, setIsGridView5] = useState(false);
  const [isGridView6, setIsGridView6] = useState(false);
  const [isGridView7, setIsGridView7] = useState(false);

  const [selectedProduct, setSelectedProduct] = useState<any | null>(null);
  const [isModalLoading, setIsModalLoading] = useState(false);

  const parseJsonArray = (data: any) => {
    if (Array.isArray(data)) return data;
    if (typeof data === 'string') {
      try {
        const parsed = JSON.parse(data);
        return Array.isArray(parsed) ? parsed : [];
      } catch (e) {
        return [];
      }
    }
    return [];
  };

  const fetchFullProductData = async (product: any) => {
    setIsModalLoading(true);
    setSelectedProduct(product); // Show initial data immediately
    
    try {
      const { data, error } = await supabaseAdmin
        .from('products')
        .select('*')
        .ilike('name', product.name)
        .maybeSingle();
      
      if (data && !error) {
        setSelectedProduct({
          ...product,
          ...data,
          score: data.toxicity_score,
          level: data.safety_level,
          category: data.category,
          isVegan: !!data.is_vegan,
          ingredients: parseJsonArray(data.ingredients_json),
          health_insights: parseJsonArray(data.health_insights_json),
          score_breakdown: parseJsonArray(data.score_breakdown_json),
          alternatives: parseJsonArray(data.alternatives_json),
          summary: data.summary || product.summary
        });
      }
    } catch (err) {
      console.warn("Error fetching full product data:", err);
    } finally {
      setIsModalLoading(false);
    }
  };

  const scroll = (ref: React.RefObject<HTMLDivElement>, direction: 'left' | 'right') => {
    if (ref.current) {
      const scrollAmount = 350; 
      ref.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  const handleHashScroll = (e: React.MouseEvent, path: string) => {
    if (path.startsWith('#')) {
      e.preventDefault();
      const id = path.substring(1);
      const element = document.getElementById(id);
      if (element) {
        const offset = 100; 
        const bodyRect = document.body.getBoundingClientRect().top;
        const elementRect = element.getBoundingClientRect().top;
        const elementPosition = elementRect - bodyRect;
        const offsetPosition = elementPosition - offset;

        window.scrollTo({
          top: offsetPosition,
          behavior: 'smooth'
        });
      }
    }
  };

  const categories = [
    { name: "Men", icon: <User size={28} />, color: "bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-200", path: "#mens-essentials" },
    { name: "Women", icon: <User size={28} />, color: "bg-pink-100 text-pink-600 dark:bg-pink-900/30 dark:text-pink-400", path: "#womens-collection" },
    { name: "Baby", icon: <Baby size={28} />, color: "bg-yellow-100 text-yellow-600 dark:bg-yellow-900/30 dark:text-yellow-400", path: "#baby-care" },
    { name: "Vegan", icon: <Leaf size={28} />, color: "bg-emerald-100 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-400", path: "#vegan-collection" },
    { name: "Pet Care", icon: <PawPrint size={28} />, color: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-500", path: "#pet-care" },
    { name: "Vegan Skincare", icon: <Flower size={28} />, color: "bg-emerald-50 text-emerald-500 dark:bg-emerald-900/20 dark:text-emerald-300", path: "/search" },
    { name: "Cruelty-free", icon: <Rabbit size={28} />, color: "bg-indigo-100 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400", path: "/search" },
    { name: "Laundry", icon: <WashingMachine size={28} />, color: "bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400", path: "/search" },
    { name: "Shampoo", icon: <ShowerHead size={28} />, color: "bg-cyan-100 text-cyan-600 dark:bg-cyan-900/30 dark:text-cyan-400", path: "/search" },
    { name: "Lip Balm", icon: <Sparkles size={28} />, color: "bg-rose-100 text-rose-600 dark:bg-rose-900/30 dark:text-rose-400", path: "/search" },
    { name: "Face Oil", icon: <Pipette size={28} />, color: "bg-amber-100 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400", path: "/search" },
    { name: "Dry Skin", icon: <Droplets size={28} />, color: "bg-orange-100 text-orange-600 dark:bg-orange-900/30 dark:text-orange-400", path: "/search" },
    { name: "Household", icon: <HomeIcon size={28} />, color: "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300", path: "/search" },
    { name: "Toothpaste", icon: <Smile size={28} />, color: "bg-teal-100 text-teal-600 dark:bg-teal-900/30 dark:text-teal-400", path: "/search" },
    { name: "Fragrance", icon: <Wind size={28} />, color: "bg-violet-100 text-violet-600 dark:bg-violet-900/30 dark:text-violet-400", path: "/search" },
    { name: "Face Mask", icon: <Smile size={28} />, color: "bg-pink-100 text-pink-500 dark:bg-pink-900/30 dark:text-pink-300", path: "/search" },
    { name: "Hand Cream", icon: <Hand size={28} />, color: "bg-orange-50 text-orange-500 dark:bg-orange-900/20 dark:text-orange-300", path: "/search" },
    { name: "Moisturizer", icon: <Flower2 size={28} />, color: "bg-lime-100 text-lime-700 dark:bg-lime-900/30 dark:text-lime-400", path: "/search" },
    { name: "Cleanser", icon: <Droplets size={28} />, color: "bg-sky-50 text-sky-500 dark:bg-sky-900/20 dark:text-sky-300", path: "/search" },
    { name: "Air Freshener", icon: <Cloud size={28} />, color: "bg-violet-50 text-violet-500 dark:bg-violet-900/20 dark:text-violet-300", path: "/search" },
  ];

  const trendingProducts = [
    {
      name: "Argan Therapy Hair Oil",
      category: "Hair Care",
      score: 28,
      rating: 4.8,
      level: "Low",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1585751119414-ef2636f8aede?auto=format&fit=crop&q=80&w=400",
      icon: <Droplets className="text-emerald-500" />,
      color: "border-emerald-100 bg-emerald-50/50 dark:border-emerald-900/30 dark:bg-emerald-900/10"
    },
    {
      name: "Head & Shoulders Classic Clean Anti-Dandruff Shampoo",
      category: "Hygiene",
      score: 50,
      rating: 3.5,
      level: "Moderate",
      isVegan: false,
      image: "https://cloudinary.images-iherb.com/image/upload/f_auto,q_auto:eco/images/hds/hds94959/y/24.jpg",
      icon: <Wind className="text-amber-500" />,
      color: "border-amber-100 bg-amber-50/50 dark:border-amber-900/30 dark:bg-amber-900/10"
    },
    {
      name: "Organic Aloe Moisturizer",
      category: "Skin Care",
      score: 8,
      rating: 4.9,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?auto=format&fit=crop&q=80&w=400",
      icon: <Flower2 className="text-emerald-500" />,
      color: "border-emerald-100 bg-emerald-50/50 dark:border-emerald-900/30 dark:bg-emerald-900/10"
    },
    {
      name: "Eucalyptus Rescue Balm",
      category: "Lip Care",
      score: 12,
      rating: 4.7,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1611080541599-8c6dbde6ed28?auto=format&fit=crop&q=80&w=400",
      icon: <Sparkles className="text-emerald-500" />,
      color: "border-emerald-100 bg-emerald-50/50 dark:border-emerald-900/30 dark:bg-emerald-900/10"
    },
    {
      name: "Silk Protein Conditioner",
      category: "Hair Care",
      score: 18,
      rating: 4.4,
      level: "Safe",
      isVegan: false,
      image: "https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?auto=format&fit=crop&q=80&w=400",
      icon: <Waves className="text-blue-500" />,
      color: "border-blue-100 bg-blue-50/50 dark:border-blue-900/30 dark:bg-blue-900/10"
    },
    {
      name: "Neem Purifying Face Wash",
      category: "Skin Care",
      score: 5,
      rating: 3.9,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1556229167-73fe6a267046?auto=format&fit=crop&q=80&w=400",
      icon: <Zap className="text-amber-500" />,
      color: "border-amber-100 bg-amber-50/50 dark:border-amber-900/30 dark:bg-amber-900/10"
    },
    {
      name: "Shea Rich Body Butter",
      category: "Body Care",
      score: 4,
      rating: 4.6,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1619451334792-150fd785ee74?auto=format&fit=crop&q=80&w=400",
      icon: <Hand className="text-emerald-500" />,
      color: "border-emerald-100 bg-emerald-50/50 dark:border-emerald-900/30 dark:bg-emerald-900/10"
    },
    {
      name: "Mineral Shield Sunscreen",
      category: "Sun Care",
      score: 11,
      rating: 4.3,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1556228578-0d85b1a4d571?auto=format&fit=crop&q=80&w=400",
      icon: <Sun className="text-amber-400" />,
      color: "border-amber-50 bg-amber-50/30 dark:border-amber-900/20 dark:bg-amber-900/5"
    }
  ];

  const newlyVerifiedProducts = [
    {
      name: "Pure Lavender Soap",
      category: "Body Care",
      score: 4,
      rating: 4.9,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1605264964528-06403738d6dc?auto=format&fit=crop&q=80&w=400",
      icon: <Flower2 className="text-emerald-500" />,
      color: "border-emerald-100 bg-emerald-50/50 dark:border-emerald-900/30 dark:bg-emerald-900/10"
    },
    {
      name: "Botanical Face Mist",
      category: "Skin Care",
      score: 7,
      rating: 4.7,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1570172619664-213fa013e9be?auto=format&fit=crop&q=80&w=400",
      icon: <Sparkles className="text-blue-400" />,
      color: "border-blue-100 bg-blue-50/50 dark:border-blue-900/30 dark:bg-blue-900/10"
    },
    {
      name: "Charcoal Detox Scrub",
      category: "Face Care",
      score: 18,
      rating: 4.2,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1594433030839-22114947ed6f?auto=format&fit=crop&q=80&w=400",
      icon: <Zap className="text-slate-500" />,
      color: "border-slate-200 bg-slate-50/50 dark:border-slate-800 dark:bg-slate-900/40"
    },
    {
      name: "Vitamin C Serum",
      category: "Skin Care",
      score: 11,
      rating: 4.5,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1608248597279-f99d160bfcbc?auto=format&fit=crop&q=80&w=400",
      icon: <Sun className="text-amber-500" />,
      color: "border-amber-100 bg-amber-50/50 dark:border-amber-900/30 dark:bg-amber-900/10"
    },
    {
      name: "Eco Dish Liquid",
      category: "Household",
      score: 9,
      rating: 4.8,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1584622781564-1d9876a13d00?auto=format&fit=crop&q=80&w=400",
      icon: <WashingMachine className="text-emerald-600" />,
      color: "border-emerald-100 bg-emerald-50/50 dark:border-emerald-900/30 dark:bg-emerald-900/10"
    },
    {
      name: "Herbal Toothpaste",
      category: "Oral Care",
      score: 6,
      rating: 4.6,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1559591937-e68fb3305ff4?auto=format&fit=crop&q=80&w=400",
      icon: <Smile className="text-teal-500" />,
      color: "border-teal-100 bg-teal-50/50 dark:border-teal-900/30 dark:bg-teal-900/10"
    },
    {
      name: "Bamboo Hair Mask",
      category: "Hair Care",
      score: 14,
      rating: 4.4,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1527799822344-499045cf0228?auto=format&fit=crop&q=80&w=400",
      icon: <Droplets className="text-emerald-400" />,
      color: "border-emerald-100 bg-emerald-50/50 dark:border-emerald-900/30 dark:bg-emerald-900/10"
    },
    {
      name: "Coconut Hand Cream",
      category: "Body Care",
      score: 3,
      rating: 4.9,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1620917670397-dc7bc43e813e?auto=format&fit=crop&q=80&w=400",
      icon: <Hand className="text-emerald-500" />,
      color: "border-emerald-100 bg-emerald-50/50 dark:border-emerald-900/30 dark:bg-emerald-900/10"
    },
    {
      name: "Rose Water Toner",
      category: "Skin Care",
      score: 5,
      rating: 4.8,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1590156221122-c748e78f2a7a?auto=format&fit=crop&q=80&w=400",
      icon: <Flower className="text-rose-400" />,
      color: "border-indigo-100 bg-rose-50/50 dark:border-indigo-900/30 dark:bg-indigo-900/10"
    },
    {
      name: "Tea Tree Spot Gel",
      category: "Face Care",
      score: 12,
      rating: 4.5,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1617897903246-719242758050?auto=format&fit=crop&q=80&w=400",
      icon: <Pipette className="text-emerald-500" />,
      color: "border-emerald-100 bg-emerald-50/50 dark:border-emerald-900/30 dark:bg-emerald-900/10"
    },
    {
      name: "Shea Butter Foot Cream",
      category: "Body Care",
      score: 8,
      rating: 4.7,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1612817288479-69c66f0826ae?auto=format&fit=crop&q=80&w=400",
      icon: <Hand className="text-amber-500" />,
      color: "border-amber-100 bg-amber-50/50 dark:border-amber-900/30 dark:bg-amber-900/10"
    },
    {
      name: "Magnesium Sleep Lotion",
      category: "Body Care",
      score: 4,
      rating: 4.9,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1612817288484-6f916006741a?auto=format&fit=crop&q=80&w=400",
      icon: <Moon className="text-indigo-400" />,
      color: "border-indigo-100 bg-indigo-50/50 dark:border-indigo-900/30 dark:bg-indigo-900/10"
    },
    {
      name: "Mineral Sunscreen Stick",
      category: "Sun Care",
      score: 15,
      rating: 4.6,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1552046122-03184de85e08?auto=format&fit=crop&q=80&w=400",
      icon: <Sun className="text-amber-500" />,
      color: "border-amber-100 bg-amber-50/50 dark:border-amber-900/30 dark:bg-amber-900/10"
    },
    {
      name: "Probiotic Face Mask",
      category: "Skin Care",
      score: 6,
      rating: 4.8,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1596462502278-27bfdc4033c8?auto=format&fit=crop&q=80&w=400",
      icon: <Smile className="text-emerald-500" />,
      color: "border-emerald-100 bg-emerald-50/50 dark:border-emerald-900/30 dark:bg-emerald-900/10"
    },
    {
      name: "Apple Cider Vinegar Rinse",
      category: "Hair Care",
      score: 10,
      rating: 4.4,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1526947425960-945c6e72858f?auto=format&fit=crop&q=80&w=400",
      icon: <Waves className="text-amber-500" />,
      color: "border-amber-100 bg-amber-50/50 dark:border-amber-900/30 dark:bg-amber-900/10"
    },
    {
      name: "Biotin Lash Balm",
      category: "Eyes",
      score: 5,
      rating: 4.7,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1625506073238-e1f596f23c43?auto=format&fit=crop&q=80&w=400",
      icon: <Sparkles className="text-indigo-400" />,
      color: "border-indigo-100 bg-indigo-50/50 dark:border-indigo-900/30 dark:bg-indigo-900/10"
    },
    {
      name: "Salicylic Acid Cleanser",
      category: "Face Care",
      score: 14,
      rating: 4.3,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1631730359585-38a4935cbec4?auto=format&fit=crop&q=80&w=400",
      icon: <Zap className="text-blue-500" />,
      color: "border-blue-100 bg-blue-50/50 dark:border-blue-900/30 dark:bg-blue-900/10"
    },
    {
      name: "Hyaluronic Acid Mist",
      category: "Skin Care",
      score: 3,
      rating: 5.0,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=400",
      icon: <Droplets className="text-sky-500" />,
      color: "border-sky-100 bg-sky-50/50 dark:border-sky-900/30 dark:bg-sky-900/10"
    },
    {
      name: "Ceramides Daily Moisturizer",
      category: "Skin Care",
      score: 7,
      rating: 4.8,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&q=80&w=400",
      icon: <ShieldCheck className="text-emerald-500" />,
      color: "border-emerald-100 bg-emerald-50/50 dark:border-emerald-900/30 dark:bg-emerald-900/10"
    },
    {
      name: "Witch Hazel Pore Toner",
      category: "Face Care",
      score: 9,
      rating: 4.5,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1614608682850-e0d6ed316d47?auto=format&fit=crop&q=80&w=400",
      icon: <Wind className="text-blue-500" />,
      color: "border-blue-100 bg-blue-50/50 dark:border-blue-900/30 dark:bg-blue-900/10"
    }
  ];

  const menProducts = [
    {
      name: "Cedarwood Beard Oil",
      category: "Men's Grooming",
      score: 6,
      rating: 4.8,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1590159068383-b9c69aacead3?auto=format&fit=crop&q=80&w=400",
      icon: <Droplets className="text-blue-500" />,
      color: "border-blue-100 bg-blue-50/50 dark:border-blue-900/30 dark:bg-blue-900/10"
    },
    {
      name: "Charcoal Face Wash",
      category: "Skin Care",
      score: 14,
      rating: 4.3,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1611080541599-8c6dbde6ed28?auto=format&fit=crop&q=80&w=400",
      icon: <Zap className="text-slate-600" />,
      color: "border-slate-200 bg-slate-50/50 dark:border-slate-800 dark:bg-slate-900/40"
    },
    {
      name: "Sport 3-in-1 Wash",
      category: "Hygiene",
      score: 22,
      rating: 3.8,
      level: "Safe",
      isVegan: false,
      image: "https://images.unsplash.com/photo-1559591937-e68fb3305ff4?auto=format&fit=crop&q=80&w=400",
      icon: <Waves className="text-cyan-500" />,
      color: "border-cyan-100 bg-cyan-50/50 dark:border-cyan-900/30 dark:bg-cyan-900/10"
    },
    {
      name: "Cooling Aftershave",
      category: "Grooming",
      score: 9,
      rating: 4.5,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1624330186448-64661729452a?auto=format&fit=crop&q=80&w=400",
      icon: <Wind className="text-sky-400" />,
      color: "border-sky-100 bg-sky-50/50 dark:border-sky-900/30 dark:bg-sky-900/10"
    },
    {
      name: "Strong Hold Hair Clay",
      category: "Hair Styling",
      score: 15,
      rating: 4.2,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1591699172025-3d4dca815f5d?auto=format&fit=crop&q=80&w=400",
      icon: <Hand className="text-amber-600" />,
      color: "border-amber-100 bg-amber-50/50 dark:border-amber-900/30 dark:bg-amber-900/10"
    },
    {
      name: "Men's Daily SPF 30",
      category: "Sun Care",
      score: 18,
      rating: 4.1,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1556228578-0d85b1a4d571?auto=format&fit=crop&q=80&w=400",
      icon: <Sun className="text-amber-500" />,
      color: "border-amber-50 bg-amber-50/30 dark:border-amber-900/20 dark:bg-amber-900/5"
    }
  ];

  const womenProducts = [
    {
      name: "Retinol Recovery Night Cream",
      category: "Skin Care",
      score: 14,
      rating: 4.6,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1556228578-0d85b1a4d571?auto=format&fit=crop&q=80&w=400",
      icon: <Moon className="text-indigo-400" size={24} />,
      color: "border-indigo-100 bg-indigo-50/50 dark:border-indigo-900/30 dark:bg-indigo-900/10"
    },
    {
      name: "Rosehip Radiance Elixir",
      category: "Face Oil",
      score: 4,
      rating: 4.9,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1608248597279-f99d160bfcbc?auto=format&fit=crop&q=80&w=400",
      icon: <Flower className="text-rose-400" />,
      color: "border-rose-100 bg-rose-50/50 dark:border-rose-900/30 dark:bg-rose-900/10"
    },
    {
      name: "Mineral Glow Blush",
      category: "Cosmetics",
      score: 8,
      rating: 4.5,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1596462502278-27bfdc4033c8?auto=format&fit=crop&q=80&w=400",
      icon: <Sparkles className="text-pink-400" />,
      color: "border-pink-100 bg-pink-50/50 dark:border-pink-900/30 dark:bg-pink-900/10"
    },
    {
      name: "Hydrating Hyaluronic Serum",
      category: "Skin Care",
      score: 2,
      rating: 5.0,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=400",
      icon: <Droplets className="text-sky-500" />,
      color: "border-sky-100 bg-sky-50/50 dark:border-sky-900/30 dark:bg-sky-900/10"
    },
    {
      name: "Jasmine Blossom Shampoo",
      category: "Hair Care",
      score: 11,
      rating: 4.4,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?auto=format&fit=crop&q=80&w=400",
      icon: <Wind className="text-emerald-400" />,
      color: "border-emerald-100 bg-emerald-50/50 dark:border-emerald-900/30 dark:bg-emerald-900/10"
    },
    {
      name: "Ceramide Barrier Balm",
      category: "Skin Care",
      score: 6,
      rating: 4.8,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1611080541599-8c6dbde6ed28?auto=format&fit=crop&q=80&w=400",
      icon: <ShieldCheck className="text-emerald-500" />,
      color: "border-emerald-100 bg-emerald-50/50 dark:border-emerald-900/30 dark:text-emerald-400"
    }
  ];

  const babyProducts = [
    {
      name: "Tear-Free Gentle Wash",
      category: "Baby Care",
      score: 2,
      rating: 5.0,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?auto=format&fit=crop&q=80&w=400",
      icon: <Baby className="text-blue-400" size={24} />,
      color: "border-blue-100 bg-blue-50/50 dark:border-blue-900/30 dark:bg-blue-900/10"
    },
    {
      name: "Hypoallergenic Zinc Cream",
      category: "Diaper Care",
      score: 5,
      rating: 4.9,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1619451334792-150fd785ee74?auto=format&fit=crop&q=80&w=400",
      icon: <ShieldCheck className="text-emerald-500" />,
      color: "border-emerald-100 bg-emerald-50/50 dark:border-emerald-900/30 dark:bg-emerald-900/10"
    },
    {
      name: "Organic Oat Lotion",
      category: "Skin Care",
      score: 4,
      rating: 4.8,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&q=80&w=400",
      icon: <Flower2 className="text-amber-500" />,
      color: "border-amber-100 bg-amber-50/50 dark:border-amber-900/30 dark:bg-amber-900/10"
    },
    {
      name: "Sensitive Fragrance-Free Wipes",
      category: "Hygiene",
      score: 7,
      rating: 4.7,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1584622781564-1d9876a13d00?auto=format&fit=crop&q=80&w=400",
      icon: <Droplets className="text-sky-400" />,
      color: "border-sky-100 bg-sky-50/50 dark:border-sky-900/30 dark:bg-sky-900/10"
    },
    {
      name: "Sleepy Lavender Baby Oil",
      category: "Body Care",
      score: 6,
      rating: 4.6,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1608248597279-f99d160bfcbc?auto=format&fit=crop&q=80&w=400",
      icon: <Sparkles className="text-indigo-400" />,
      color: "border-indigo-100 bg-indigo-50/50 dark:border-indigo-900/30 dark:bg-indigo-900/10"
    },
    {
      name: "Mineral Shield Baby Sunscreen",
      category: "Sun Care",
      score: 11,
      rating: 4.4,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1552046122-03184de85e08?auto=format&fit=crop&q=80&w=400",
      icon: <Sun className="text-yellow-500" />,
      color: "border-yellow-100 bg-yellow-50/50 dark:border-yellow-900/30 dark:bg-yellow-900/10"
    }
  ];

  const veganProducts = [
    {
      name: "Hygienelab Mens Body Wash",
      category: "Men's Grooming",
      score: 12,
      rating: 4.7,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1559591937-e68fb3305ff4?auto=format&fit=crop&q=80&w=400",
      icon: <Droplets className="text-blue-500" />,
      color: "border-blue-100 bg-blue-50/50 dark:border-blue-900/30 dark:bg-blue-900/10"
    },
    {
      name: "Hygienelab Mens Styling Gel",
      category: "Hair Styling",
      score: 15,
      rating: 4.5,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1599351431247-f10bc1334651?auto=format&fit=crop&q=80&w=400",
      icon: <Wind className="text-amber-600" />,
      color: "border-amber-100 bg-amber-50/50 dark:border-amber-900/30 dark:bg-amber-900/10"
    },
    {
      name: "Signature Blend Essential Oil Perfume",
      category: "Fragrance",
      score: 5,
      rating: 4.9,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&q=80&w=400",
      icon: <Flower className="text-rose-400" />,
      color: "border-rose-100 bg-rose-50/50 dark:border-rose-900/30 dark:bg-rose-900/10"
    },
    {
      name: "Sensitive Baby Care Essentials Gift Set",
      category: "Baby Care",
      score: 3,
      rating: 5.0,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&q=80&w=400",
      icon: <Baby className="text-sky-400" />,
      color: "border-sky-100 bg-sky-50/50 dark:border-sky-900/30 dark:bg-sky-900/10"
    },
    {
      name: "Candy Cane Clean Foaming Hand Soap",
      category: "Hygiene",
      score: 8,
      rating: 4.8,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1584622781564-1d9876a13d00?auto=format&fit=crop&q=80&w=400",
      icon: <Hand className="text-emerald-500" />,
      color: "border-emerald-100 bg-emerald-50/50 dark:border-emerald-900/30 dark:bg-emerald-900/10"
    },
    {
      name: "Purple Shampoo",
      category: "Hair Care",
      score: 14,
      rating: 4.6,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?auto=format&fit=crop&q=80&w=400",
      icon: <Waves className="text-indigo-500" />,
      color: "border-indigo-100 bg-indigo-50/50 dark:border-indigo-900/30 dark:bg-indigo-900/10"
    },
    {
      name: "Vita Shield Broad Spectrum SPF 30",
      category: "Sun Care",
      score: 10,
      rating: 4.7,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1552046122-03184de85e08?auto=format&fit=crop&q=80&w=400",
      icon: <Sun className="text-amber-500" />,
      color: "border-amber-50 bg-amber-50/30 dark:border-amber-900/20 dark:bg-amber-900/5"
    },
    {
      name: "Illuminating Cleaning Oil",
      category: "Skin Care",
      score: 6,
      rating: 4.9,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=400",
      icon: <Droplets className="text-sky-500" />,
      color: "border-sky-100 bg-sky-50/50 dark:border-sky-900/30 dark:bg-sky-900/10"
    },
    {
      name: "Peptide Protection SPF 30 Broad Spectrum Sunscreen",
      category: "Sun Care",
      score: 12,
      rating: 4.5,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1556228578-0d85b1a4d571?auto=format&fit=crop&q=80&w=400",
      icon: <Sun className="text-amber-400" />,
      color: "border-amber-50 bg-amber-50/30 dark:border-amber-900/20 dark:bg-amber-900/5"
    },
    {
      name: "Royal Codes Bath Soak",
      category: "Body Care",
      score: 4,
      rating: 4.9,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1605264964528-06403738d6dc?auto=format&fit=crop&q=80&w=400",
      icon: <Waves className="text-emerald-500" />,
      color: "border-emerald-100 bg-emerald-50/50 dark:border-emerald-900/30 dark:bg-emerald-900/10"
    },
    {
      name: "Hair Repair",
      category: "Hair Care",
      score: 11,
      rating: 4.4,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1527799822344-499045cf0228?auto=format&fit=crop&q=80&w=400",
      icon: <Sparkles className="text-emerald-400" />,
      color: "border-emerald-100 bg-emerald-50/50 dark:border-emerald-900/30 dark:bg-emerald-900/10"
    },
    {
      name: "Daily Shampoo",
      category: "Hair Care",
      score: 13,
      rating: 4.6,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?auto=format&fit=crop&q=80&w=400",
      icon: <Wind className="text-emerald-400" />,
      color: "border-emerald-100 bg-emerald-50/50 dark:border-emerald-900/30 dark:bg-emerald-900/10"
    },
    {
      name: "Ultra Moisturising Body Butter",
      category: "Body Care",
      score: 7,
      rating: 4.8,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1619451334792-150fd785ee74?auto=format&fit=crop&q=80&w=400",
      icon: <Hand className="text-emerald-500" />,
      color: "border-emerald-100 bg-emerald-50/50 dark:border-emerald-900/30 dark:bg-emerald-900/10"
    },
    {
      name: "Signature Blend Essential Oil Perfume",
      category: "Fragrance",
      score: 5,
      rating: 4.9,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&q=80&w=400",
      icon: <Flower className="text-rose-400" />,
      color: "border-rose-100 bg-rose-50/50 dark:border-rose-900/30 dark:bg-rose-900/10"
    },
    {
      name: "Heal All Oil",
      category: "Skin Care",
      score: 5,
      rating: 4.9,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1608248597279-f99d160bfcbc?auto=format&fit=crop&q=80&w=400",
      icon: <Pipette className="text-emerald-500" />,
      color: "border-emerald-100 bg-emerald-50/50 dark:border-emerald-900/30 dark:bg-emerald-900/10"
    },
    {
      name: "Laundry Detergent Sheets",
      category: "Household",
      score: 9,
      rating: 4.8,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1584622781564-1d9876a13d00?auto=format&fit=crop&q=80&w=400",
      icon: <WashingMachine className="text-emerald-600" />,
      color: "border-emerald-100 bg-emerald-50/50 dark:border-emerald-900/30 dark:bg-emerald-900/10"
    }
  ];

  const petProducts = [
    {
      name: "Organic Oatmeal Pet Shampoo",
      category: "Pet Grooming",
      score: 3,
      rating: 4.9,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?auto=format&fit=crop&q=80&w=400",
      icon: <ShowerHead className="text-amber-600" />,
      color: "border-amber-100 bg-amber-50/50 dark:border-amber-900/30 dark:bg-amber-900/10"
    },
    {
      name: "Natural Tick & Flea Spray",
      category: "Pet Hygiene",
      score: 12,
      rating: 4.5,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?auto=format&fit=crop&q=80&w=400",
      icon: <SprayCan className="text-emerald-500" />,
      color: "border-emerald-100 bg-emerald-50/50 dark:border-emerald-900/30 dark:bg-emerald-900/10"
    },
    {
      name: "Hypoallergenic Paw Balm",
      category: "Skin Care",
      score: 5,
      rating: 5.0,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1601758124510-52d02ddb7cbd?auto=format&fit=crop&q=80&w=400",
      icon: <Hand className="text-orange-500" />,
      color: "border-orange-100 bg-orange-50/50 dark:border-orange-900/30 dark:bg-orange-900/10"
    },
    {
      name: "Plant-Based Pet Odor Neutralizer",
      category: "Household",
      score: 7,
      rating: 4.6,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1584622781564-1d9876a13d00?auto=format&fit=crop&q=80&w=400",
      icon: <Wind className="text-cyan-500" />,
      color: "border-cyan-100 bg-cyan-50/50 dark:border-cyan-900/30 dark:bg-cyan-900/10"
    },
    {
      name: "Gentle Ear Cleaning Drops",
      category: "Pet Hygiene",
      score: 8,
      rating: 4.4,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?auto=format&fit=crop&q=80&w=400",
      icon: <Pipette className="text-blue-500" />,
      color: "border-blue-100 bg-blue-50/50 dark:border-blue-900/30 dark:bg-blue-900/10"
    },
    {
      name: "Vegan Dog Dental Chews",
      category: "Oral Care",
      score: 4,
      rating: 4.8,
      level: "Safe",
      isVegan: true,
      image: "https://images.unsplash.com/photo-1541364983171-a8ba01e95cfc?auto=format&fit=crop&q=80&w=400",
      icon: <Smile className="text-emerald-600" />,
      color: "border-emerald-100 bg-emerald-50/50 dark:border-emerald-900/30 dark:bg-emerald-900/10"
    }
  ];

  const ProductDetailModal = ({ product, onClose }: { product: any, onClose: () => void }) => {
    useEffect(() => {
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = 'unset';
      };
    }, []);

    const scoreColorClass = product.score < 30 ? 'text-emerald-500' : product.score < 60 ? 'text-amber-500' : 'text-rose-500';
    const bgScoreClass = product.score < 30 ? 'bg-emerald-50 dark:bg-emerald-900/20' : product.score < 60 ? 'bg-amber-50 dark:bg-amber-900/20' : 'bg-rose-50 dark:bg-rose-900/20';

    return (
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300">
        <div className="bg-white dark:bg-slate-900 w-full max-w-4xl max-h-[90vh] rounded-[3rem] shadow-2xl overflow-y-auto relative no-scrollbar animate-in slide-in-from-bottom-8 duration-500 border border-slate-200 dark:border-slate-800">
          {isModalLoading && (
            <div className="absolute inset-0 z-[110] bg-white/50 dark:bg-slate-900/50 backdrop-blur-sm flex items-center justify-center rounded-[3rem]">
              <div className="flex flex-col items-center gap-4">
                <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
                <p className="text-xs font-black uppercase tracking-widest text-slate-500">Loading Forensic Data...</p>
              </div>
            </div>
          )}
          <button 
            onClick={onClose}
            className="absolute top-6 right-6 z-50 p-3 bg-white/80 dark:bg-slate-800/80 backdrop-blur rounded-full text-slate-900 dark:text-white shadow-xl hover:scale-110 active:scale-95 transition-all border border-slate-200 dark:border-slate-700"
          >
            <X size={24} />
          </button>

          <div className="relative h-64 md:h-80 w-full overflow-hidden">
            {product.image ? (
              <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-300">
                <ImageIcon size={64} />
              </div>
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-white dark:from-slate-900 to-transparent" />
            
            <div className="absolute bottom-0 left-0 p-8 md:p-12 w-full">
              <div className="flex flex-wrap items-center gap-3 mb-4">
                <span className="px-4 py-1.5 bg-blue-600 text-white rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg">
                  {product.category}
                </span>
                {product.isVegan && (
                  <span className="px-4 py-1.5 bg-emerald-500 text-white rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg flex items-center gap-1.5">
                    <Leaf size={12} strokeWidth={3} /> Vegan Verified
                  </span>
                )}
              </div>
              <h2 className="text-4xl md:text-5xl font-black text-slate-900 dark:text-white tracking-tighter leading-tight">
                {product.name}
              </h2>
            </div>
          </div>

          <div className="p-8 md:p-12 pt-4 grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="md:col-span-2 space-y-12">
              <section>
                <h3 className="text-xs font-black uppercase tracking-[0.3em] text-slate-400 mb-6 flex items-center gap-2">
                  <FileText size={16} /> Forensic Summary
                </h3>
                <p className="text-xl font-medium text-slate-600 dark:text-slate-400 leading-relaxed">
                  {product.summary || `This product has been audited for its chemical integrity. It features a forensic toxicity profile optimized for ${product.category.toLowerCase()} applications. The overall safety level is categorized as ${product.level.toUpperCase()} based on the detected chemical markers.`}
                </p>
              </section>

              {product.ingredients && product.ingredients.length > 0 && (
                <section>
                  <h3 className="text-xs font-black uppercase tracking-[0.3em] text-slate-400 mb-6 flex items-center gap-2">
                    <Beaker size={16} /> Key Ingredients
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {product.ingredients.map((ing: any, i: number) => (
                      <span key={i} className="px-4 py-2 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                        {typeof ing === 'string' ? ing : ing.name}
                      </span>
                    ))}
                  </div>
                </section>
              )}

              <section className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                 <div className="p-8 rounded-[2rem] bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
                   <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-4 flex items-center gap-2">
                     <Info size={14} /> Usage Status
                   </h4>
                   <p className="text-sm font-bold text-slate-900 dark:text-white leading-relaxed">
                     {product.usage_instructions || "Verified for consumer use under global standard protocols. No immediate hazardous alerts detected."}
                   </p>
                 </div>
                 <div className="p-8 rounded-[2rem] bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
                   <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-4 flex items-center gap-2">
                     <Heart size={14} /> Rating Confidence
                   </h4>
                   <p className="text-sm font-bold text-slate-900 dark:text-white leading-relaxed">
                     Market data confirms a user rating of {product.rating || 4.5}/5 with consistent performance across verified test batches.
                   </p>
                 </div>
              </section>

              <div className="pt-8 border-t border-slate-100 dark:border-slate-800">
                <button 
                  onClick={onClose}
                  className="w-full py-5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-[1.5rem] font-black uppercase text-sm tracking-widest hover:scale-[1.02] transition-transform shadow-xl"
                >
                  Return to Dashboard
                </button>
              </div>
            </div>

            <div className="space-y-8">
              <div className={`p-10 rounded-[3rem] border border-slate-100 dark:border-slate-800 flex flex-col items-center justify-center text-center shadow-xl ${bgScoreClass}`}>
                <span className="text-[10px] font-black uppercase tracking-[0.3em] mb-4 opacity-70">Forensic Safety Score</span>
                <div className={`text-8xl font-black mb-4 tracking-tighter ${scoreColorClass}`}>{product.score}</div>
                <div className={`px-6 py-2 rounded-full font-black uppercase tracking-widest text-sm mb-4 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md ${scoreColorClass}`}>
                  {product.level} Risk
                </div>
                <p className="text-[10px] font-bold opacity-60 max-w-[150px] uppercase tracking-widest">Calculated via AI Protocol v3.2</p>
              </div>

              <div className="bg-white dark:bg-slate-800 p-8 rounded-[2.5rem] border border-slate-100 dark:border-slate-700 shadow-lg">
                <h4 className="text-xs font-black uppercase tracking-widest text-slate-400 mb-6 flex items-center gap-2">
                  <Activity size={16} /> Market Stats
                </h4>
                <div className="space-y-6">
                  <div className="flex justify-between items-end">
                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">User Rating</span>
                    <span className="text-lg font-black text-slate-900 dark:text-white">{product.rating}/5</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-100 dark:bg-slate-900 rounded-full overflow-hidden">
                    <div className="bg-amber-400 h-full transition-all" style={{ width: `${(product.rating/5)*100}%` }} />
                  </div>
                  <div className="pt-4 flex items-center gap-2 text-[10px] font-black text-emerald-500 uppercase tracking-[0.2em]">
                    <CheckCircle size={14} strokeWidth={3} /> Certified Authentic
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const StarRating = ({ rating }: { rating: number }) => (
    <div className="flex items-center gap-1 mb-4">
      {[1, 2, 3, 4, 5].map((s) => (
        <Star 
          key={s} 
          size={14} 
          className={s <= Math.floor(rating) ? "text-amber-500 fill-amber-500" : "text-slate-200 dark:text-slate-700"} 
        />
      ))}
      <span className="text-[10px] font-black text-slate-500 ml-1">{rating}</span>
    </div>
  );

  const ProductCard = ({ product, isGridView }: { product: any, isGridView: boolean, key?: any }) => (
    <div 
      className={`
        flex-shrink-0 snap-center p-8 rounded-[2.5rem] border ${product.color} transition-all hover:shadow-xl group relative overflow-hidden bg-white dark:bg-slate-900 shadow-sm
        ${isGridView ? 'w-full' : 'w-[280px] md:w-[350px]'}
      `}
    >
      {product.isVegan && (
        <div className="absolute top-6 left-6 z-20 flex items-center gap-1.5 bg-emerald-500 text-white px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest shadow-md">
          <Leaf size={10} strokeWidth={3} /> Vegan
        </div>
      )}

      <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:rotate-12 transition-transform z-10">
        <Sparkles size={60} className="dark:text-white" />
      </div>

      <div 
        onClick={() => fetchFullProductData(product)}
        className="aspect-[4/3] -mx-8 -mt-8 mb-6 overflow-hidden rounded-t-[2.5rem] bg-slate-100 dark:bg-slate-800 relative cursor-pointer"
      >
        {product.image ? (
          <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-slate-300 dark:text-slate-700">
            <ImageIcon size={48} />
          </div>
        )}
        <div className="absolute bottom-4 right-4 w-12 h-12 bg-white/90 dark:bg-slate-800/90 backdrop-blur rounded-2xl flex items-center justify-center shadow-lg border border-white/50 dark:border-slate-700">
          {product.icon}
        </div>
      </div>

      <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 block">{product.category}</span>
      <h3 className="text-xl font-black text-slate-900 dark:text-white mb-2 line-clamp-1">{product.name}</h3>
      <StarRating rating={product.rating} />
      
      <div className="flex items-center justify-between pt-6 border-t border-slate-200/50 dark:border-slate-800">
        <div className="flex flex-col">
          <span className="text-[10px] font-black text-slate-400 uppercase">Score</span>
          <span className="text-2xl font-black text-slate-900 dark:text-white">{product.score}</span>
        </div>
        <div className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest ${
          product.level === 'Safe' ? 'bg-emerald-100 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-400' : 'bg-amber-100 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400'
        }`}>
          {product.level}
        </div>
      </div>

      <button 
        onClick={() => fetchFullProductData(product)}
        className="mt-6 flex items-center justify-center w-full py-3 bg-slate-900 dark:bg-white dark:text-slate-900 rounded-xl text-[10px] font-black uppercase tracking-widest text-white hover:bg-black dark:hover:bg-slate-200 transition-all gap-2"
      >
        SEARCH NOW <ChevronRight size={12} />
      </button>
    </div>
  );

  return (
    <div className="relative overflow-hidden bg-slate-50 dark:bg-slate-950 transition-colors">
      <BackgroundAnimation />
      
      <section className="relative pt-20 pb-20 px-4">
        <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/4 w-[600px] h-[600px] bg-blue-100 dark:bg-blue-900/10 rounded-full blur-[120px] opacity-30 -z-10" />
        <div className="absolute bottom-0 left-0 translate-y-1/2 -translate-x-1/4 w-[400px] h-[400px] bg-emerald-100 dark:bg-emerald-900/10 rounded-full blur-[100px] opacity-30 -z-10" />

        <div className="max-w-7xl mx-auto text-center relative z-10">
          <div className="inline-flex items-center gap-2 bg-slate-900 dark:bg-slate-800 text-white px-5 py-2 rounded-full text-[10px] font-black uppercase tracking-widest mb-8 border border-slate-800 shadow-xl">
            <Globe size={14} className="text-blue-400" />
            Live Product Intelligence
          </div>
          <h1 className="text-6xl md:text-8xl font-black tracking-tight text-slate-900 dark:text-white mb-6 leading-[0.95]">
            See Through <br />
            The <span className="text-blue-600 dark:text-blue-500">Chemical</span> Fog.
          </h1>
          <p className="max-w-3xl mx-auto text-xl md:text-2xl text-slate-500 dark:text-slate-400 mb-12 leading-relaxed">
            Uncover hidden ingredients using our forensic analysis and AI-powered chemical audit.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
            <Link 
              to="/search" 
              className="group w-full sm:w-auto px-12 py-6 bg-slate-900 dark:bg-white dark:text-slate-900 text-white rounded-[2.5rem] font-black text-xl hover:bg-black dark:hover:bg-slate-100 shadow-2xl flex items-center justify-center gap-3 transition-all hover:-translate-y-1"
            >
              Search Product <Search size={24} className="group-hover:scale-110 transition-transform" />
            </Link>
            <Link 
              to="/all-products" 
              className="w-full sm:w-auto px-12 py-6 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-2 border-slate-200 dark:border-slate-800 rounded-[2.5rem] font-black text-xl hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center justify-center gap-3 transition-all shadow-lg hover:-translate-y-1"
            >
              Product Lists <ListTodo size={24} className="text-blue-600" />
            </Link>
          </div>
        </div>
      </section>

      <section className="pb-16 px-4 relative z-10">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-8 overflow-x-auto no-scrollbar pb-6 -mx-4 px-4 md:mx-0 md:px-0 scroll-smooth">
            {categories.map((cat, idx) => {
              const isHash = cat.path.startsWith('#');
              const Component = (isHash ? 'button' : Link) as any;
              const props = isHash 
                ? { onClick: (e: React.MouseEvent) => handleHashScroll(e, cat.path) } 
                : { to: cat.path };

              return (
                <Component 
                  key={idx} 
                  {...props}
                  className="flex flex-col items-center gap-3 group flex-shrink-0 animate-in fade-in zoom-in duration-500 outline-none"
                  style={{ animationDelay: `${idx * 40}ms` }}
                >
                  <div className={`w-20 h-20 md:w-24 md:h-24 rounded-full flex items-center justify-center ${cat.color} transition-all group-hover:scale-110 group-hover:rotate-6 shadow-lg border-4 border-white dark:border-slate-900`}>
                    {cat.icon}
                  </div>
                  <span className="text-[10px] md:text-xs font-black text-slate-900 dark:text-slate-300 uppercase tracking-widest whitespace-nowrap">{cat.name}</span>
                </Component>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-24 px-4 bg-slate-50/50 dark:bg-slate-900/20 overflow-hidden relative border-t border-slate-100 dark:border-slate-900 z-10">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
            <div>
              <h2 className="text-4xl font-black text-slate-900 dark:text-white mb-1 tracking-tight">Trending Now</h2>
              <p className="text-slate-400 dark:text-slate-500 text-[10px] font-black uppercase tracking-[0.2em] ml-1">sponsored</p>
            </div>
            
            <button 
              onClick={() => setIsGridView(!isGridView)}
              className="flex items-center gap-2 text-blue-600 dark:text-blue-400 font-black uppercase text-xs tracking-widest hover:bg-blue-50 dark:hover:bg-blue-900/20 px-6 py-3 rounded-2xl transition-all"
            >
              {isGridView ? (
                <><Rows size={16} /> Show Slider</>
              ) : (
                <><LayoutGrid size={16} /> View All in Columns</>
              )}
            </button>
          </div>

          <div className="relative group/slider">
            {!isGridView && (
              <>
                <button 
                  onClick={() => scroll(scrollContainerRef, 'left')}
                  className="absolute left-4 top-1/2 -translate-y-1/2 z-20 p-4 bg-white/90 dark:bg-slate-900/90 backdrop-blur border border-slate-200 dark:border-slate-800 rounded-full text-slate-900 dark:text-white shadow-xl opacity-0 group-hover/slider:opacity-100 hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all active:scale-90"
                  aria-label="Slide Left"
                >
                  <ChevronLeft size={24} />
                </button>
                <button 
                  onClick={() => scroll(scrollContainerRef, 'right')}
                  className="absolute right-4 top-1/2 -translate-y-1/2 z-20 p-4 bg-white/90 dark:bg-slate-900/90 backdrop-blur border border-slate-200 dark:border-slate-800 rounded-full text-slate-900 dark:text-white shadow-xl opacity-0 group-hover/slider:opacity-100 hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all active:scale-90"
                  aria-label="Slide Right"
                >
                  <ChevronRight size={24} />
                </button>
              </>
            )}

            <div 
              ref={scrollContainerRef}
              className={`
                ${isGridView 
                  ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8' 
                  : 'flex gap-6 overflow-x-auto pb-12 snap-x snap-mandatory no-scrollbar -mx-4 px-4 md:mx-0 md:px-0 scroll-smooth'}
              `}
            >
              {trendingProducts.map((product, idx) => (
                <ProductCard key={idx} product={product} isGridView={isGridView} />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 px-4 bg-white dark:bg-slate-950 overflow-hidden relative border-t border-slate-100 dark:border-slate-900 z-10">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
            <div className="flex items-center gap-4">
              <h2 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight">Newly Verified Products</h2>
              <div className="bg-emerald-500 text-white p-1 rounded-md shadow-lg shadow-emerald-500/20">
                <Check size={28} strokeWidth={4} />
              </div>
            </div>
            
            <button 
              onClick={() => setIsGridView2(!isGridView2)}
              className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-black uppercase text-xs tracking-widest hover:bg-emerald-50 dark:hover:bg-emerald-900/20 px-6 py-3 rounded-2xl transition-all"
            >
              {isGridView2 ? (
                <><Rows size={16} /> Show Slider</>
              ) : (
                <><LayoutGrid size={16} /> View All in Columns</>
              )}
            </button>
          </div>

          <div className="relative group/slider">
            {!isGridView2 && (
              <>
                <button 
                  onClick={() => scroll(scrollContainerRef2, 'left')}
                  className="absolute left-4 top-1/2 -translate-y-1/2 z-20 p-4 bg-white/90 dark:bg-slate-900/90 backdrop-blur border border-slate-200 dark:border-slate-800 rounded-full text-slate-900 dark:text-white shadow-xl opacity-0 group-hover/slider:opacity-100 hover:bg-emerald-600 hover:text-white hover:border-emerald-600 transition-all active:scale-90"
                  aria-label="Slide Left"
                >
                  <ChevronLeft size={24} />
                </button>
                <button 
                  onClick={() => scroll(scrollContainerRef2, 'right')}
                  className="absolute right-4 top-1/2 -translate-y-1/2 z-20 p-4 bg-white/90 dark:bg-slate-900/90 backdrop-blur border border-slate-200 dark:border-slate-800 rounded-full text-slate-900 dark:text-white shadow-xl opacity-0 group-hover/slider:opacity-100 hover:bg-emerald-600 hover:text-white hover:border-emerald-600 transition-all active:scale-90"
                  aria-label="Slide Right"
                >
                  <ChevronRight size={24} />
                </button>
              </>
            )}

            <div 
              ref={scrollContainerRef2}
              className={`
                ${isGridView2 
                  ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8' 
                  : 'flex gap-6 overflow-x-auto pb-12 snap-x snap-mandatory no-scrollbar -mx-4 px-4 md:mx-0 md:px-0 scroll-smooth'}
              `}
            >
              {newlyVerifiedProducts.map((product, idx) => (
                <ProductCard key={idx} product={product} isGridView={isGridView2} />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="mens-essentials" className="py-24 px-4 bg-slate-50 dark:bg-slate-900/30 overflow-hidden relative border-t border-slate-100 dark:border-slate-900 z-10">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
            <div className="flex items-center gap-4">
              <h2 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight">Men's Essentials</h2>
              <div className="bg-slate-700 text-white p-1 rounded-md shadow-lg shadow-slate-500/20">
                <User size={28} strokeWidth={4} />
              </div>
            </div>
            
            <button 
              onClick={() => setIsGridView3(!isGridView3)}
              className="flex items-center gap-2 text-slate-600 dark:text-slate-400 font-black uppercase text-xs tracking-widest hover:bg-slate-100 dark:hover:bg-slate-800 px-6 py-3 rounded-2xl transition-all"
            >
              {isGridView3 ? (
                <><Rows size={16} /> Show Slider</>
              ) : (
                <><LayoutGrid size={16} /> View All in Columns</>
              )}
            </button>
          </div>

          <div className="relative group/slider">
            {!isGridView3 && (
              <>
                <button 
                  onClick={() => scroll(scrollContainerRef3, 'left')}
                  className="absolute left-4 top-1/2 -translate-y-1/2 z-20 p-4 bg-white/90 dark:bg-slate-900/90 backdrop-blur border border-slate-200 dark:border-slate-800 rounded-full text-slate-900 dark:text-white shadow-xl opacity-0 group-hover/slider:opacity-100 hover:bg-slate-800 hover:text-white hover:border-slate-800 transition-all active:scale-90"
                  aria-label="Slide Left"
                >
                  <ChevronLeft size={24} />
                </button>
                <button 
                  onClick={() => scroll(scrollContainerRef3, 'right')}
                  className="absolute right-4 top-1/2 -translate-y-1/2 z-20 p-4 bg-white/90 dark:bg-slate-900/90 backdrop-blur border border-slate-200 dark:border-slate-800 rounded-full text-slate-900 dark:text-white shadow-xl opacity-0 group-hover/slider:opacity-100 hover:bg-slate-800 hover:text-white hover:border-slate-800 transition-all active:scale-90"
                  aria-label="Slide Right"
                >
                  <ChevronRight size={24} />
                </button>
              </>
            )}

            <div 
              ref={scrollContainerRef3}
              className={`
                ${isGridView3 
                  ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8' 
                  : 'flex gap-6 overflow-x-auto pb-12 snap-x snap-mandatory no-scrollbar -mx-4 px-4 md:mx-0 md:px-0 scroll-smooth'}
              `}
            >
              {menProducts.map((product, idx) => (
                <ProductCard key={idx} product={product} isGridView={isGridView3} />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="womens-collection" className="py-24 px-4 bg-white dark:bg-slate-950 overflow-hidden relative border-t border-slate-100 dark:border-slate-900 z-10">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
            <div className="flex items-center gap-4">
              <h2 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight">Women's Collection</h2>
              <div className="bg-pink-500 text-white p-1 rounded-md shadow-lg shadow-pink-500/20">
                <Heart size={28} strokeWidth={4} fill="white" />
              </div>
            </div>
            
            <button 
              onClick={() => setIsGridView4(!isGridView4)}
              className="flex items-center gap-2 text-pink-600 dark:text-pink-400 font-black uppercase text-xs tracking-widest hover:bg-pink-50 dark:hover:bg-pink-900/20 px-6 py-3 rounded-2xl transition-all"
            >
              {isGridView4 ? (
                <><Rows size={16} /> Show Slider</>
              ) : (
                <><LayoutGrid size={16} /> View All in Columns</>
              )}
            </button>
          </div>

          <div className="relative group/slider">
            {!isGridView4 && (
              <>
                <button 
                  onClick={() => scroll(scrollContainerRef4, 'left')}
                  className="absolute left-4 top-1/2 -translate-y-1/2 z-20 p-4 bg-white/90 dark:bg-slate-900/90 backdrop-blur border border-slate-200 dark:border-slate-800 rounded-full text-slate-900 dark:text-white shadow-xl opacity-0 group-hover/slider:opacity-100 hover:bg-pink-600 hover:text-white hover:border-pink-600 transition-all active:scale-90"
                  aria-label="Slide Left"
                >
                  <ChevronLeft size={24} />
                </button>
                <button 
                  onClick={() => scroll(scrollContainerRef4, 'right')}
                  className="absolute right-4 top-1/2 -translate-y-1/2 z-20 p-4 bg-white/90 dark:bg-slate-900/90 backdrop-blur border border-slate-200 dark:border-slate-800 rounded-full text-slate-900 dark:text-white shadow-xl opacity-0 group-hover/slider:opacity-100 hover:bg-pink-600 hover:text-white hover:border-pink-600 transition-all active:scale-90"
                  aria-label="Slide Right"
                >
                  <ChevronRight size={24} />
                </button>
              </>
            )}

            <div 
              ref={scrollContainerRef4}
              className={`
                ${isGridView4 
                  ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8' 
                  : 'flex gap-6 overflow-x-auto pb-12 snap-x snap-mandatory no-scrollbar -mx-4 px-4 md:mx-0 md:px-0 scroll-smooth'}
              `}
            >
              {womenProducts.map((product, idx) => (
                <ProductCard key={idx} product={product} isGridView={isGridView4} />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="baby-care" className="py-24 px-4 bg-slate-50 dark:bg-slate-900/30 overflow-hidden relative border-t border-slate-100 dark:border-slate-900 z-10">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
            <div className="flex items-center gap-4">
              <h2 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight">Baby Care</h2>
              <div className="bg-yellow-500 text-white p-1 rounded-md shadow-lg shadow-yellow-500/20">
                <Baby size={28} strokeWidth={4} />
              </div>
            </div>
            
            <button 
              onClick={() => setIsGridView5(!isGridView5)}
              className="flex items-center gap-2 text-yellow-600 dark:text-yellow-400 font-black uppercase text-xs tracking-widest hover:bg-yellow-50 dark:hover:bg-yellow-900/20 px-6 py-3 rounded-2xl transition-all"
            >
              {isGridView5 ? (
                <><Rows size={16} /> Show Slider</>
              ) : (
                <><LayoutGrid size={16} /> View All in Columns</>
              )}
            </button>
          </div>

          <div className="relative group/slider">
            {!isGridView5 && (
              <>
                <button 
                  onClick={() => scroll(scrollContainerRef5, 'left')}
                  className="absolute left-4 top-1/2 -translate-y-1/2 z-20 p-4 bg-white/90 dark:bg-slate-900/90 backdrop-blur border border-slate-200 dark:border-slate-800 rounded-full text-slate-900 dark:text-white shadow-xl opacity-0 group-hover/slider:opacity-100 hover:bg-yellow-600 hover:text-white hover:border-yellow-600 transition-all active:scale-90"
                  aria-label="Slide Left"
                >
                  <ChevronLeft size={24} />
                </button>
                <button 
                  onClick={() => scroll(scrollContainerRef5, 'right')}
                  className="absolute right-4 top-1/2 -translate-y-1/2 z-20 p-4 bg-white/90 dark:bg-slate-900/90 backdrop-blur border border-slate-200 dark:border-slate-800 rounded-full text-slate-900 dark:text-white shadow-xl opacity-0 group-hover/slider:opacity-100 hover:bg-yellow-600 hover:text-white hover:border-yellow-600 transition-all active:scale-90"
                  aria-label="Slide Right"
                >
                  <ChevronRight size={24} />
                </button>
              </>
            )}

            <div 
              ref={scrollContainerRef5}
              className={`
                ${isGridView5 
                  ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8' 
                  : 'flex gap-6 overflow-x-auto pb-12 snap-x snap-mandatory no-scrollbar -mx-4 px-4 md:mx-0 md:px-0 scroll-smooth'}
              `}
            >
              {babyProducts.map((product, idx) => (
                <ProductCard key={idx} product={product} isGridView={isGridView5} />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="vegan-collection" className="py-24 px-4 bg-white dark:bg-slate-950 overflow-hidden relative border-t border-slate-100 dark:border-slate-900 z-10">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
            <div className="flex items-center gap-4">
              <h2 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight">Vegan Collection</h2>
              <div className="bg-emerald-500 text-white p-1 rounded-md shadow-lg shadow-emerald-500/20">
                <Leaf size={28} strokeWidth={4} />
              </div>
            </div>
            
            <button 
              onClick={() => setIsGridView6(!isGridView6)}
              className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-black uppercase text-xs tracking-widest hover:bg-emerald-50 dark:hover:bg-emerald-900/20 px-6 py-3 rounded-2xl transition-all"
            >
              {isGridView6 ? (
                <><Rows size={16} /> Show Slider</>
              ) : (
                <><LayoutGrid size={16} /> View All in Columns</>
              )}
            </button>
          </div>

          <div className="relative group/slider">
            {!isGridView6 && (
              <>
                <button 
                  onClick={() => scroll(scrollContainerRef6, 'left')}
                  className="absolute left-4 top-1/2 -translate-y-1/2 z-20 p-4 bg-white/90 dark:bg-slate-900/90 backdrop-blur border border-slate-200 dark:border-slate-800 rounded-full text-slate-900 dark:text-white shadow-xl opacity-0 group-hover/slider:opacity-100 hover:bg-emerald-600 hover:text-white hover:border-emerald-600 transition-all active:scale-90"
                  aria-label="Slide Left"
                >
                  <ChevronLeft size={24} />
                </button>
                <button 
                  onClick={() => scroll(scrollContainerRef6, 'right')}
                  className="absolute right-4 top-1/2 -translate-y-1/2 z-20 p-4 bg-white/90 dark:bg-slate-900/90 backdrop-blur border border-slate-200 dark:border-slate-800 rounded-full text-slate-900 dark:text-white shadow-xl opacity-0 group-hover/slider:opacity-100 hover:bg-emerald-600 hover:text-white hover:border-emerald-600 transition-all active:scale-90"
                  aria-label="Slide Right"
                >
                  <ChevronRight size={24} />
                </button>
              </>
            )}

            <div 
              ref={scrollContainerRef6}
              className={`
                ${isGridView6 
                  ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8' 
                  : 'flex gap-6 overflow-x-auto pb-12 snap-x snap-mandatory no-scrollbar -mx-4 px-4 md:mx-0 md:px-0 scroll-smooth'}
              `}
            >
              {veganProducts.map((product, idx) => (
                <ProductCard key={idx} product={product} isGridView={isGridView6} />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="pet-care" className="py-24 px-4 bg-slate-50 dark:bg-slate-900/30 overflow-hidden relative border-t border-slate-100 dark:border-slate-900 z-10">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
            <div className="flex items-center gap-4">
              <h2 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight">Pet Care Collection</h2>
              <div className="bg-amber-600 text-white p-1 rounded-md shadow-lg shadow-amber-500/20">
                <PawPrint size={28} strokeWidth={4} />
              </div>
            </div>
            
            <button 
              onClick={() => setIsGridView7(!isGridView7)}
              className="flex items-center gap-2 text-amber-600 dark:text-amber-400 font-black uppercase text-xs tracking-widest hover:bg-amber-50 dark:hover:bg-amber-900/20 px-6 py-3 rounded-2xl transition-all"
            >
              {isGridView7 ? (
                <><Rows size={16} /> Show Slider</>
              ) : (
                <><LayoutGrid size={16} /> View All in Columns</>
              )}
            </button>
          </div>

          <div className="relative group/slider">
            {!isGridView7 && (
              <>
                <button 
                  onClick={() => scroll(scrollContainerRef7, 'left')}
                  className="absolute left-4 top-1/2 -translate-y-1/2 z-20 p-4 bg-white/90 dark:bg-slate-900/90 backdrop-blur border border-slate-200 dark:border-slate-800 rounded-full text-slate-900 dark:text-white shadow-xl opacity-0 group-hover/slider:opacity-100 hover:bg-amber-600 hover:text-white hover:border-amber-600 transition-all active:scale-90"
                  aria-label="Slide Left"
                >
                  <ChevronLeft size={24} />
                </button>
                <button 
                  onClick={() => scroll(scrollContainerRef7, 'right')}
                  className="absolute right-4 top-1/2 -translate-y-1/2 z-20 p-4 bg-white/90 dark:bg-slate-900/90 backdrop-blur border border-slate-200 dark:border-slate-800 rounded-full text-slate-900 dark:text-white shadow-xl opacity-0 group-hover/slider:opacity-100 hover:bg-amber-600 hover:text-white hover:border-amber-600 transition-all active:scale-90"
                  aria-label="Slide Right"
                >
                  <ChevronRight size={24} />
                </button>
              </>
            )}

            <div 
              ref={scrollContainerRef7}
              className={`
                ${isGridView7 
                  ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8' 
                  : 'flex gap-6 overflow-x-auto pb-12 snap-x snap-mandatory no-scrollbar -mx-4 px-4 md:mx-0 md:px-0 scroll-smooth'}
              `}
            >
              {petProducts.map((product, idx) => (
                <ProductCard key={idx} product={product} isGridView={isGridView7} />
              ))}
            </div>
          </div>
        </div>
      </section>

      {selectedProduct && (
        <ProductDetailModal 
          product={selectedProduct} 
          onClose={() => setSelectedProduct(null)} 
        />
      )}

      <style dangerouslySetInnerHTML={{ __html: `
        .no-scrollbar::-webkit-scrollbar {
          display: none;
        }
        .no-scrollbar {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}} />
    </div>
  );
};

export default Home;