import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = process.env.VITE_SUPABASE_ANON_KEY || '';
const supabaseServiceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('Missing Supabase environment variables. Please check your configuration.');
}

// Helper to create a permissive mock object that prevents crashes
const createPermissiveMock = (name: string): any => {
  const mock: any = (...args: any[]) => mock;
  mock.then = undefined; // Promise compatibility
  mock.toJSON = () => ({}); // JSON serialization compatibility
  
  return new Proxy(mock, {
    get: (target, prop) => {
      if (prop === 'then') return undefined;
      if (prop === 'toJSON') return () => ({});
      
      // Return a permissive mock for any property
      return createPermissiveMock(`${name}.${String(prop)}`);
    },
    apply: (target, thisArg, argumentsList) => {
      console.warn(`Supabase ${name} was called but is not implemented. Please configure your .env file.`);
      // Return a promise that resolves to an empty object to prevent crashes
      return Promise.resolve({ data: null, error: null });
    }
  });
};

// Ensure createClient is only called with valid strings to prevent immediate crash
export const supabase = (supabaseUrl && supabaseAnonKey) 
  ? createClient(supabaseUrl, supabaseAnonKey) 
  : createPermissiveMock('supabase');

export const isSupabaseConfigured = !!(supabaseUrl && supabaseAnonKey);

// Admin client for operations that bypass RLS (use with caution)
export const supabaseAdmin = (supabaseUrl && supabaseServiceRoleKey)
  ? createClient(supabaseUrl, supabaseServiceRoleKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    })
  : createPermissiveMock('supabaseAdmin');
