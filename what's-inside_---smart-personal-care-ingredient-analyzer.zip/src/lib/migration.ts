
import { supabase } from './supabase';

export const migrateGuestData = async (userId: string) => {
  try {
    // 1. Migrate Search History
    const guestHistory = JSON.parse(localStorage.getItem('guest_search_history') || '[]');
    if (guestHistory.length > 0) {
      const historyToInsert = guestHistory.map((item: any) => ({
        user_id: userId,
        search_term: item.search_term,
        created_at: item.created_at || new Date().toISOString()
      }));

      const { error: historyError } = await supabase.from('search_history').insert(historyToInsert);
      if (!historyError) {
        localStorage.removeItem('guest_search_history');
      } else {
        console.error('Migration: History error', historyError);
      }
    }

    // 2. Migrate Watchlist (Product Lists)
    const guestWatchlist = JSON.parse(localStorage.getItem('guest_watchlist') || '[]');
    if (guestWatchlist.length > 0) {
      const watchlistToInsert = guestWatchlist.map((item: any) => ({
        user_id: userId,
        product_name: item.product_name,
        list_id: item.list_id,
        list_title: item.list_title,
        created_at: item.created_at || new Date().toISOString()
      }));

      const { error: watchlistError } = await supabase.from('watchlist').insert(watchlistToInsert);
      if (!watchlistError) {
        localStorage.removeItem('guest_watchlist');
      } else {
        console.error('Migration: Watchlist error', watchlistError);
      }
    }

    // 3. Migrate Product Likes
    const guestLikes = JSON.parse(localStorage.getItem('guest_likes') || '[]');
    if (guestLikes.length > 0) {
      const likesToInsert = guestLikes.map((productName: string) => ({
        user_id: userId,
        product_name: productName,
        created_at: new Date().toISOString()
      }));

      const { error: likesError } = await supabase.from('product_likes').insert(likesToInsert);
      if (!likesError) {
        localStorage.removeItem('guest_likes');
      } else {
        console.error('Migration: Likes error', likesError);
      }
    }

    // 4. Migrate Chemical Watchlist
    const guestChemicals = JSON.parse(localStorage.getItem('guest_chemical_watchlist') || '[]');
    if (guestChemicals.length > 0) {
      const chemicalsToInsert = guestChemicals.map((chemicalName: string) => ({
        user_id: userId,
        chemical_name: chemicalName,
        created_at: new Date().toISOString()
      }));

      const { error: chemicalsError } = await supabase.from('chemical_watchlist').insert(chemicalsToInsert);
      if (!chemicalsError) {
        localStorage.removeItem('guest_chemical_watchlist');
      } else {
        console.error('Migration: Chemicals error', chemicalsError);
      }
    }

  } catch (err) {
    console.error('Migration failed:', err);
  }
};
