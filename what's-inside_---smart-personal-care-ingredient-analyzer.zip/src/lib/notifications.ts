
export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  type: 'info' | 'success' | 'warning';
  read: boolean;
}

export const addNotification = (title: string, message: string, type: 'info' | 'success' | 'warning' = 'info') => {
  try {
    const saved = localStorage.getItem('notifications_data');
    const notifications: NotificationItem[] = saved ? JSON.parse(saved) : [];
    
    const newNotification: NotificationItem = {
      id: Date.now().toString(),
      title,
      message,
      time: 'Just now',
      type,
      read: false
    };
    
    const updated = [newNotification, ...notifications].slice(0, 50); // Keep last 50
    localStorage.setItem('notifications_data', JSON.stringify(updated));
    
    // Trigger storage event for other tabs/components
    window.dispatchEvent(new Event('storage'));
  } catch (err) {
    console.error('Failed to add notification:', err);
  }
};
