
import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  Search as SearchIcon, 
  Heart, 
  ShieldCheck, 
  Menu, 
  X,
  Home as HomeIcon,
  User,
  LogOut,
  ListTodo,
  Bell,
  Sun,
  Moon,
  History,
  Clock,
  LayoutList,
  Smile,
  Maximize,
  Settings
} from 'lucide-react';
import Home from './views/Home';
import Analyze from './views/Analyze';
import AllProducts from './views/AllProducts';
import Watchlist from './views/Watchlist';
import Welcome from './views/Welcome';
import SignUp from './views/SignUp';
import Login from './views/Login';
import Notifications from './views/Notifications';
import Admin from './views/Admin';
import Profile from './views/Profile';
import SetupProfile from './views/SetupProfile';
import EditProfile from './views/EditProfile';
import Quiz from './views/Quiz';
import Registry from './views/Registry';
import { supabase } from './lib/supabase';

const BottomNav = ({ user }: { user: any }) => {
  const location = useLocation();
  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white/80 dark:bg-slate-950/80 backdrop-blur-lg border-t border-slate-200 dark:border-slate-800 z-50 flex items-center justify-around h-20 px-2 transition-colors">
      <Link to="/" className={`flex flex-col items-center gap-1 transition-colors ${isActive('/') ? 'text-blue-600' : 'text-slate-400 dark:text-slate-500'}`}>
        <HomeIcon size={24} />
      </Link>
      <Link to="/search" className={`flex flex-col items-center gap-1 transition-colors ${isActive('/search') ? 'text-blue-600' : 'text-slate-400 dark:text-slate-500'}`}>
        <Clock size={24} />
      </Link>
      <Link to="/search" className="relative -top-6">
        <div className="bg-blue-600 p-4 rounded-2xl shadow-lg shadow-blue-200 dark:shadow-blue-900/20 hover:scale-110 transition-transform">
          <div className="relative">
            <Maximize size={28} className="text-white" />
          </div>
        </div>
      </Link>
      <Link to="/all-products" className={`flex flex-col items-center gap-1 transition-colors ${isActive('/all-products') ? 'text-blue-600' : 'text-slate-400 dark:text-slate-500'}`}>
        <LayoutList size={24} />
      </Link>
      <Link to="/profile" className={`flex flex-col items-center gap-1 transition-colors ${isActive('/profile') ? 'text-blue-600' : 'text-slate-400 dark:text-slate-500'}`}>
        <Smile size={24} />
      </Link>
    </div>
  );
};

const Navbar = ({ theme, toggleTheme }: { theme: string, toggleTheme: () => void }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [user, setUser] = useState<any>(null);
  const location = useLocation();

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });
    return () => subscription.unsubscribe();
  }, []);

  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    const checkNotifications = () => {
      const saved = localStorage.getItem('notifications_data');
      if (saved) {
        const notifications = JSON.parse(saved);
        const unread = notifications.filter((n: any) => !n.read).length;
        setUnreadCount(unread);
      } else {
        // Default mock notifications have 2 unread
        setUnreadCount(2);
      }
    };

    checkNotifications();
    // Listen for storage changes (in case user marks as read in another tab or just now)
    window.addEventListener('storage', checkNotifications);
    // Also check periodically or on focus
    const interval = setInterval(checkNotifications, 2000);
    
    return () => {
      window.removeEventListener('storage', checkNotifications);
      clearInterval(interval);
    };
  }, [location.pathname]);

  const navLinks = [
    { name: 'Home', path: '/', icon: <HomeIcon size={18} /> },
    { name: 'Search', path: '/search', icon: <SearchIcon size={18} /> },
    { name: 'Lists', path: '/all-products', icon: <ListTodo size={18} /> },
    { name: 'Watchlist', path: '/watchlist', icon: <Heart size={18} /> },
  ];

  const handleSignOut = async () => {
    await supabase.auth.signOut();
  };

  const scrollToTop = (e: React.MouseEvent) => {
    if (location.pathname === '/') {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
      if (isOpen) setIsOpen(false);
    }
  };

  const isActive = (path: string) => location.pathname === path;

  if (location.pathname === '/notifications' || location.pathname === '/admin') return null;

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass-morphism border-b border-slate-200 dark:border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <Link to="/" onClick={scrollToTop} className="flex items-center gap-2 group">
            <div className="bg-blue-600 p-2 rounded-xl text-white group-hover:bg-blue-700 transition-all shadow-lg shadow-blue-100">
              <ShieldCheck size={28} />
            </div>
            <span className="text-2xl font-black text-slate-900 dark:text-white tracking-tighter">
              Inside<span className="text-blue-600">?</span>
            </span>
          </Link>

          <div className="hidden md:flex items-center gap-4">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                onClick={link.path === '/' ? scrollToTop : undefined}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
                  isActive(link.path) 
                    ? 'text-blue-600 bg-blue-50 dark:bg-blue-900/30' 
                    : 'text-slate-500 hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400'
                }`}
              >
                {link.icon}
                {link.name}
              </Link>
            ))}
            
            <div className="h-6 w-px bg-slate-200 dark:bg-slate-800 mx-2" />

            {/* Theme Toggle */}
            <button 
              onClick={toggleTheme}
              className="p-2.5 text-slate-500 hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400 transition-all hover:scale-110 active:scale-95 bg-slate-100 dark:bg-slate-900 rounded-xl"
            >
              {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
            </button>

            <Link to="/notifications" className="relative p-2 text-slate-500 hover:text-blue-600 dark:text-slate-400 transition-all hover:scale-110 group">
              <Bell size={22} />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-rose-500 border-2 border-white dark:border-slate-950 rounded-full group-hover:animate-ping" />
              )}
            </Link>
            
            {user ? (
              <Link 
                to="/profile"
                className="ml-2 p-2.5 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-xl hover:bg-blue-100 dark:hover:bg-blue-900/40 transition-all group relative"
                title="Profile"
              >
                <User size={20} />
                <span className="absolute -bottom-10 right-0 bg-slate-900 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                  Profile
                </span>
              </Link>
            ) : (
              <Link to="/login" className="ml-2 flex items-center gap-2 bg-slate-900 dark:bg-white dark:text-slate-900 text-white px-5 py-2.5 rounded-xl text-sm font-bold hover:bg-slate-800 dark:hover:bg-slate-100 transition-all">
                <User size={18} /> Sign In
              </Link>
            )}
          </div>

          <div className="md:hidden flex items-center gap-3">
            <button 
              onClick={toggleTheme}
              className="p-2 text-slate-500 dark:text-slate-400"
            >
              {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
            </button>
            <Link to="/notifications" className="relative p-2 text-slate-500 dark:text-slate-400">
              <Bell size={22} />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 border border-white dark:border-slate-950 rounded-full" />
              )}
            </Link>
            <button className="p-2 text-slate-600 dark:text-slate-400" onClick={() => setIsOpen(!isOpen)}>
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden bg-white dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 px-4 py-6 space-y-4 animate-in slide-in-from-top-2">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              onClick={link.path === '/' ? scrollToTop : () => setIsOpen(false)}
              className={`flex items-center gap-3 p-4 rounded-xl text-lg font-bold ${
                isActive(link.path) ? 'text-blue-600 bg-blue-50 dark:bg-blue-900/20' : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              {link.icon} {link.name}
            </Link>
          ))}
          {user ? (
            <Link to="/profile" onClick={() => setIsOpen(false)} className="flex items-center gap-3 p-4 rounded-xl text-lg font-bold text-slate-600 dark:text-slate-400">
              <User size={20} /> Profile
            </Link>
          ) : (
            <Link to="/login" className="flex items-center gap-3 p-4 rounded-xl text-lg font-bold text-slate-900 dark:text-white bg-slate-50 dark:bg-slate-900">
              <User size={20} /> Sign In
            </Link>
          )}
        </div>
      )}
    </nav>
  );
};

const App: React.FC = () => {
  const navigate = useNavigate();
  const [hasEntered, setHasEntered] = useState(false);
  const [showSignUp, setShowSignUp] = useState(false);
  const [theme, setTheme] = useState(() => {
    const saved = localStorage.getItem('theme');
    if (saved === 'dark') return 'dark';
    if (saved === 'light') return 'light';
    // Default to system preference if available, or light
    if (window.matchMedia('(prefers-color-scheme: dark)').matches) return 'dark';
    return 'light';
  });

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });
    return () => subscription.unsubscribe();
  }, []);

  return (
    <>
      {!hasEntered ? (
        <Welcome onEnter={() => {
          setHasEntered(true);
          setShowSignUp(true);
        }} />
      ) : (showSignUp && !user) ? (
        <SignUp 
          onComplete={() => setShowSignUp(false)} 
          onSkip={() => setShowSignUp(false)} 
          onSignIn={() => {
            setShowSignUp(false);
            navigate('/login');
          }}
        />
      ) : (
        <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors duration-300">
          <Navbar theme={theme} toggleTheme={toggleTheme} />
          <main className="flex-grow pt-24 pb-20 md:pb-0">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/search" element={<Analyze />} />
              <Route path="/all-products" element={<AllProducts />} />
              <Route path="/watchlist" element={<Watchlist />} />
              <Route path="/login" element={<Login />} />
              <Route path="/notifications" element={<Notifications />} />
              <Route path="/admin" element={<Admin />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/setup-profile" element={<SetupProfile />} />
              <Route path="/edit-profile" element={<EditProfile />} />
              <Route path="/quiz" element={<Quiz />} />
              <Route path="/registry" element={<Registry />} />
            </Routes>
          </main>
          <BottomNav user={user} />
          <footer className="hidden md:block bg-slate-950 text-slate-500 py-20 px-4 mt-20 border-t border-white/5">
             <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
                <div className="col-span-2">
                   <h3 className="text-white text-2xl font-black mb-4">What's Inside?</h3>
                   <p className="max-w-md text-sm leading-relaxed">
                      Your 2026 Academic Project: A smart utility for chemical transparency in household products.
                   </p>
                </div>
                <div>
                   <h4 className="text-white font-bold mb-4">Modules</h4>
                   <ul className="space-y-2 text-sm">
                      <li>
                        <Link 
                          to="/" 
                          onClick={(e) => {
                            if (window.location.hash === '#/') {
                              e.preventDefault();
                              window.scrollTo({ top: 0, behavior: 'smooth' });
                            }
                          }} 
                          className="hover:text-blue-400 transition-colors"
                        >
                          Home
                        </Link>
                      </li>
                      <li><Link to="/search" className="hover:text-blue-400 transition-colors">Search</Link></li>
                      <li><Link to="/all-products" className="hover:text-blue-400 transition-colors">List</Link></li>
                      <li><Link to="/watchlist" className="hover:text-blue-400 transition-colors">Watchlist</Link></li>
                      <li><Link to="/admin" className="hover:text-amber-400 transition-colors flex items-center gap-1"><Settings size={12}/> Admin Portal</Link></li>
                   </ul>
                </div>
                <div>
                   <h4 className="text-white font-bold mb-4">Student Info</h4>
                   <p className="text-xs">Sufiyan Malik (Roll #24)<br/>B.Sc. IT Semester V<br/>Tolani College of Commerce</p>
                </div>
             </div>
          </footer>
        </div>
      )}
    </>
  );
};

export default App;
