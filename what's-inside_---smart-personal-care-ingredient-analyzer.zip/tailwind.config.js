/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  darkMode: 'class',
  theme: {
    extend: {
      animation: {
        'drift': 'drift 20s infinite linear',
        'drift-slow': 'drift 30s infinite linear',
        'drift-fast': 'drift 15s infinite linear',
        'spin-slow': 'spin 12s infinite linear',
        'pop-in': 'pop-in 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards',
      },
      keyframes: {
        drift: {
          '0%, 100%': { transform: 'translate(0, 0) rotate(0deg)' },
          '25%': { transform: 'translate(10px, 15px) rotate(2deg)' },
          '50%': { transform: 'translate(-5px, 25px) rotate(-1deg)' },
          '75%': { transform: 'translate(-15px, 10px) rotate(1deg)' },
        },
        'pop-in': {
          '0%': { opacity: '0', transform: 'scale(0.9) translateY(10px)' },
          '100%': { opacity: '1', transform: 'scale(1) translateY(0)' },
        },
      },
    },
  },
  plugins: [],
}
